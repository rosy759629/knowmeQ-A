/* ===========================================================
   tests/dom.test.js — 浏览器端冒烟测试（jsdom）
   -----------------------------------------------------------
   真的把 index.html + 9 个脚本跑起来，走一遍
   「创建 → 答题 → 结果 → 管理」全流程。

   依赖：npm i jsdom（可选，装了才有这个测试）
   运行：node tests/dom.test.js
   =========================================================== */

'use strict';

const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { JSDOM } = require('jsdom');

const ROOT = path.join(__dirname, '..');
const SCRIPTS = [
  'js/config.js',
  'js/config.admin.js',
  'js/utils.js',
  'js/editor.js',
  'js/db.js',
  'js/certificate.js',
  'js/router.js',
  'js/home.js',
  'js/quiz.js',
  'js/result.js',
  'js/admin.js',
  'js/super.js'
];

const failures = [];
let passed = 0;
const consoleErrors = [];

function ok(name) {
  passed += 1;
  console.log('  ✓ ' + name);
}

function fail(name, err) {
  failures.push({ name, err });
  console.log('  ✗ ' + name + '\n      ' + (err && err.message));
}

async function test(name, fn) {
  try {
    await fn();
    ok(name);
  } catch (err) {
    fail(name, err);
  }
}

/* ─────────── 假 Canvas 2D 上下文 ─────────── */

function fakeContext() {
  const store = {};
  const noop = function () {};
  return new Proxy(store, {
    get(target, prop) {
      if (prop === 'measureText') {
        return function (text) { return { width: String(text).length * 18 }; };
      }
      if (prop === 'createLinearGradient' || prop === 'createRadialGradient') {
        return function () { return { addColorStop: noop }; };
      }
      if (prop === 'canvas') return null;
      if (prop in target) return target[prop];
      return noop;
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    }
  });
}

/* ─────────── 启动一个"浏览器" ─────────── */

function boot(url) {
  let html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  html = html.replace(/<script[\s\S]*?<\/script>/g, '');

  const dom = new JSDOM(html, {
    url: url || 'http://localhost/',
    runScripts: 'dangerously',
    pretendToBeVisual: true
  });

  const win = dom.window;
  const doc = win.document;

  win.scrollTo = function () {};
  win.Element.prototype.scrollIntoView = function () {};
  win.HTMLCanvasElement.prototype.getContext = function () { return fakeContext(); };
  win.HTMLCanvasElement.prototype.toBlob = function (cb) {
    cb(new win.Blob(['png'], { type: 'image/png' }));
  };
  win.URL.createObjectURL = function () { return 'blob:stub'; };
  win.URL.revokeObjectURL = function () {};
  win.AudioContext = undefined;
  win.webkitAudioContext = undefined;

  win.console.error = function () {
    consoleErrors.push(Array.prototype.slice.call(arguments).join(' '));
  };
  win.addEventListener('error', function (e) {
    consoleErrors.push('window.onerror: ' + (e.message || e.error));
  });

  SCRIPTS.forEach(function (file) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    win.eval(code + '\n//# sourceURL=' + file);
  });

  return { dom, win, doc };
}

const wait = function (ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms); });
};

function click(win, el) {
  assert.ok(el, '要点击的元素不存在');
  el.dispatchEvent(new win.MouseEvent('click', { bubbles: true, cancelable: true }));
}

/* ─────────── 全流程 ─────────── */

(async function run() {
  console.log('\nDOM 冒烟测试（jsdom）\n');

  const { dom, win, doc } = boot();
  const KM = win.KM;

  const navCalls = [];
  KM.nav.quiz = function (code) { navCalls.push(['quiz', code]); };
  KM.nav.result = function (code) { navCalls.push(['result', code]); };
  KM.nav.admin = function (code, key) { navCalls.push(['admin', code, key]); };
  KM.nav.home = function () { navCalls.push(['home']); };

  KM.router.start();
  await wait(30);

  await test('首页渲染：手机模式提示可见，其他视图隐藏', () => {
    assert.strictEqual(doc.getElementById('view-home').hidden, false);
    assert.strictEqual(doc.getElementById('view-quiz').hidden, true);
    assert.strictEqual(doc.getElementById('view-result').hidden, true);
    assert.strictEqual(doc.getElementById('view-admin').hidden, true);
    assert.strictEqual(doc.getElementById('view-super').hidden, true);
    const hint = doc.getElementById('mode-hint');
    assert.strictEqual(hint.hidden, false, '本地模式提示应显示');
    assert.ok(/本地体验模式/.test(hint.textContent), '提示文案不对：' + hint.textContent);
  });

  await test('路由：站点根路径 / 后台路径 / 页脚入口都符合预期', () => {
    assert.strictEqual(KM.basePath, '/', '普通页面的站点根应是 /');
    assert.strictEqual(KM.adminPath, '/manage', '后台路径来自 config.admin.js');
    assert.strictEqual(KM.isAdminPage, false);

    const footerLink = doc.querySelector('#footer-admin a');
    assert.ok(footerLink, 'SHOW_FOOTER_LINK 开启时页脚应有后台入口');
    assert.strictEqual(footerLink.getAttribute('href'), '/manage');
    assert.strictEqual(doc.getElementById('footer-admin').hidden, false);

    // 站内跳转不能被后台目录污染
    assert.strictEqual(KM.nav.quizUrl('AB2C'), 'http://localhost/?code=AB2C');
    assert.strictEqual(KM.nav.adminUrl('AB2C', 'k1'), 'http://localhost/?code=AB2C&admin&key=k1');
  });

  await test('展开创建表单：出现 1 道题、4 个选项、4 个答案单选', () => {
    click(win, doc.getElementById('toggle-create'));
    const form = doc.querySelector('#create-body .create-form');
    assert.ok(form, '表单没生成');
    assert.strictEqual(doc.querySelectorAll('.q-editor').length, 1);
    assert.strictEqual(doc.querySelectorAll('.q-editor .opt-input').length, 4);
    assert.strictEqual(doc.querySelectorAll('.q-editor input[type="radio"]').length, 4);
    assert.strictEqual(doc.querySelectorAll('.q-editor input[type="radio"]:checked').length, 1, '默认应选中 A');
    assert.strictEqual(doc.getElementById('toggle-create').textContent, '收起表单');
  });

  await test('「+ 添加一道题」能加到 2 道题', () => {
    const addBtn = doc.querySelectorAll('.create-actions .btn')[0];
    click(win, addBtn);
    assert.strictEqual(doc.querySelectorAll('.q-editor').length, 2);
    assert.ok(/第 2 题/.test(doc.querySelectorAll('.q-no')[1].textContent));
  });

  const questions = [
    { q: '我最喜欢的颜色是？', options: ['红色', '蓝色', '绿色', '黄色'], answer: 0 },
    { q: '我最常熬夜到几点？', options: ['11 点', '1 点', '3 点', '不睡'], answer: 1 }
  ];
  let createdCode = '';

  await test('填表并提交：校验通过 → 生成 code + 弹窗 + 写入本地', async () => {
    const cards = doc.querySelectorAll('.q-editor');
    cards.forEach(function (card, i) {
      card.querySelector('.q-text').value = questions[i].q;
      card.querySelectorAll('.opt-input').forEach(function (input, j) {
        input.value = questions[i].options[j];
      });
      const radios = card.querySelectorAll('input[type="radio"]');
      radios[questions[i].answer].click();
    });

    const form = doc.querySelector('.create-form');
    form.dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));

    for (let i = 0; i < 40 && !doc.querySelector('.result-code'); i++) await wait(25);

    const codeEl = doc.querySelector('.result-code strong');
    assert.ok(codeEl, '创建成功弹窗没出现');
    createdCode = codeEl.textContent.trim();
    assert.ok(KM.util.CODE_RE.test(createdCode), 'code 格式不对：' + createdCode);

    const quiz = await KM.db.getQuiz(createdCode);
    assert.ok(quiz, '题目没写进本地');
    assert.strictEqual(quiz.questions.length, 2);
    assert.strictEqual(quiz.questions[1].q, questions[1].q);
    assert.strictEqual(quiz.questions[1].answer, 1);

    assert.ok(doc.querySelectorAll('.modal').length >= 1, '弹窗 DOM 缺失');
    const inputs = doc.querySelectorAll('.modal .copy-row input');
    assert.strictEqual(inputs.length, 2, '应该有答题链接和管理链接两行');
    assert.ok(inputs[0].value.indexOf('code=' + createdCode) !== -1, '答题链接不对：' + inputs[0].value);
    assert.ok(/admin/.test(inputs[1].value) && /key=/.test(inputs[1].value), '管理链接不对：' + inputs[1].value);
  });

  await test('创建后「我的题目」列表出现这套题', async () => {
    for (let i = 0; i < 40 && !doc.querySelector('.my-quiz-item'); i++) await wait(25);
    const item = doc.querySelector('.my-quiz-item');
    assert.ok(item, '我的题目列表没渲染');
    assert.ok(/CODE\s+\w{4}/.test(item.textContent), '缺少 code 信息：' + item.textContent);
  });

  await test('空选项 / 重复选项会被拦下（不生成题目）', async () => {
    // 关掉当前弹窗
    doc.querySelectorAll('.modal-overlay').forEach(function (n) { n.remove(); });
    const before = KM.db.getMyCodes().length;
    const card = doc.querySelector('.q-editor');
    card.querySelector('.q-text').value = '重复选项测试';
    card.querySelectorAll('.opt-input').forEach(function (input) { input.value = '一样的'; });
    doc.querySelector('.create-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
    await wait(120);
    assert.strictEqual(KM.db.getMyCodes().length, before, '重复选项不该创建成功');
    const err = doc.querySelector('#create-body .form-error');
    assert.ok(err && err.hidden === false && /一模一样/.test(err.textContent), '应提示选项重复：' + (err && err.textContent));
  });

  /* ─────────── 答题 ─────────── */

  await test('答题页：开始卡显示题名 / 题数，昵称为空时不能开始', async () => {
    KM.ui.show('quiz');
    const container = doc.getElementById('view-quiz');
    await KM.views.quiz.init(container, { code: createdCode });

    const title = doc.querySelector('.quiz-start-title');
    assert.ok(title && /你是不是最懂我/.test(title.textContent), '标题不对');
    assert.ok(/2 道题/.test(doc.querySelector('.quiz-start-by').textContent), '题数不对');

    const startBtn = doc.querySelector('.quiz-start .btn-primary');
    click(win, startBtn);
    assert.strictEqual(doc.querySelector('.quiz-progress'), null, '空昵称不该进入答题');
    assert.ok(/先填个昵称/.test(doc.querySelector('.quiz-start .form-error').textContent));
  });

  await test('答题流程：2 题全对 → 进度条 → 提交 → 跳结果', async () => {
    const nick = doc.getElementById('nick-input');
    nick.value = '测试员小王';

    // 让答题相关的 setTimeout 变快，省测试时间
    const realSetTimeout = win.setTimeout;
    win.setTimeout = function (fn, ms) {
      return realSetTimeout(fn, Math.min(Number(ms) || 0, 5));
    };

    click(win, doc.querySelector('.quiz-start .btn-primary'));

    for (let i = 0; i < 2; i++) {
      let opts = [];
      for (let t = 0; t < 80 && opts.length === 0; t++) {
        opts = doc.querySelectorAll('.quiz-card .opt');
        if (!opts.length) await wait(10);
      }
      assert.strictEqual(opts.length, 4, '第 ' + (i + 1) + ' 题应有 4 个选项');
      assert.ok(/^Q\d/.test(doc.querySelector('.quiz-qno').textContent));
      assert.strictEqual(doc.querySelectorAll('.quiz-card .opt.is-correct').length, 0);

      // 点击后立即断言（class 是同步加的；定时器还没机会跑）
      click(win, opts[questions[i].answer]);
      assert.strictEqual(doc.querySelectorAll('.quiz-card .opt.is-correct').length, 1, '答对后应有绿色高亮');
      assert.strictEqual(doc.querySelectorAll('.quiz-mark.is-correct').length, 1, '应出现 ✓ 标记');
      assert.strictEqual(doc.querySelectorAll('.quiz-card .opt[disabled]').length, 4, '答完后选项应全部锁定');

      await wait(80);
    }

    win.setTimeout = realSetTimeout;
    await wait(300);

    const last = KM.store.get(KM.util.KEYS.lastResultPrefix + createdCode, null);
    assert.ok(last, '没有保存交卷结果');
    assert.strictEqual(last.score, 2);
    assert.strictEqual(last.total, 2);
    assert.strictEqual(last.nickname, '测试员小王');
    assert.deepStrictEqual(Array.from(last.answers), [1, 1]);
    assert.ok(last.duration >= 1, 'duration 应该是正整数：' + last.duration);

    assert.ok(
      navCalls.some(function (c) { return c[0] === 'result' && c[1] === createdCode; }),
      '答完应跳结果页，实际：' + JSON.stringify(navCalls)
    );

    const scores = await KM.db.getAllScores(createdCode);
    assert.strictEqual(scores.length, 1, '成绩应写进本地');
    assert.strictEqual(scores[0].score, 2);
  });

  await test('答错时：红色抖动 + ✗ + 正确答案绿色高亮', async () => {
    // 用另一套题单独测答错，不动上面的数据
    const created = await KM.db.createQuiz({
      title: '答错特效测试',
      creatorName: '出题人',
      questions: [{ q: '答案是 B', options: ['A', 'B', 'C', 'D'], answer: 1 }]
    });
    KM.ui.show('quiz');
    const container = doc.getElementById('view-quiz');
    await KM.views.quiz.init(container, { code: created.code });

    doc.getElementById('nick-input').value = '答错的人';
    const realSetTimeout = win.setTimeout;
    win.setTimeout = function (fn, ms) { return realSetTimeout(fn, Math.min(Number(ms) || 0, 5)); };
    click(win, doc.querySelector('.quiz-start .btn-primary'));
    await wait(40);

    const opts = doc.querySelectorAll('.quiz-card .opt');
    click(win, opts[0]); // 选 A，但答案是 B
    assert.strictEqual(doc.querySelectorAll('.opt.is-wrong').length, 1, '选错的那项应变红');
    assert.strictEqual(doc.querySelectorAll('.opt.is-answer').length, 1, '正确答案应高亮');
    assert.ok(opts[1].classList.contains('is-answer'), '高亮的应该是 B');
    assert.strictEqual(doc.querySelectorAll('.quiz-mark.is-wrong').length, 1, '应出现 ✗ 标记');

    win.setTimeout = realSetTimeout;
    await wait(200);

    const last = KM.store.get(KM.util.KEYS.lastResultPrefix + created.code, null);
    assert.strictEqual(last.score, 0);
    assert.deepStrictEqual(Array.from(last.answers), [0]);
  });

  await test('答过的题再进来：显示「已经答过」并提供两个出口', async () => {
    KM.ui.show('quiz');
    const container = doc.getElementById('view-quiz');
    await KM.views.quiz.init(container, { code: createdCode });
    assert.ok(/已经答过这套题了/.test(container.textContent), '应显示已答过卡片');
    assert.strictEqual(container.querySelectorAll('.state-actions .btn').length, 2);
  });

  /* ─────────── 结果页 ─────────── */

  await test('结果页：得分滚动到 2、排行榜高亮自己、证书 canvas 已绘制', async () => {
    KM.ui.show('result');
    const container = doc.getElementById('view-result');
    await KM.views.result.init(container, { code: createdCode });

    const evalText = doc.querySelector('.result-eval');
    assert.ok(/满分|最懂我/.test(evalText.textContent), '满分文案不对：' + evalText.textContent);

    await wait(1300);
    assert.strictEqual(doc.querySelector('.result-score .num').textContent, '2', '分数应该滚到 2');
    assert.strictEqual(doc.querySelector('.result-score .total').textContent, '2');

    const rows = doc.querySelectorAll('.rank-row');
    assert.strictEqual(rows.length, 1, '排行榜应有 1 行，实际 ' + rows.length);
    assert.ok(rows[0].classList.contains('is-me'), '自己那行应高亮');
    assert.ok(/测试员小王/.test(rows[0].textContent), '排行榜昵称不对');
    assert.ok(/你/.test(rows[0].textContent), '应有「你」标记');

    const canvas = doc.querySelector('.cert-wrap canvas');
    assert.ok(canvas, '证书 canvas 缺失');
    assert.strictEqual(canvas.width, 1200);
    assert.strictEqual(canvas.height, 850);
    assert.ok(/排名|第 1 名/.test(container.textContent), '应显示名次');
  });

  await test('结果页按钮：再答一次会清掉已答标记', async () => {
    const btns = Array.prototype.slice.call(doc.querySelectorAll('.result-actions .btn'));
    const again = btns.find(function (b) { return /再答一次/.test(b.textContent); });
    assert.ok(again, '找不到「再答一次」按钮');
    click(win, again);
    assert.strictEqual(KM.store.get(KM.util.KEYS.submittedPrefix + createdCode, false), false);
    assert.ok(navCalls.some(function (c) { return c[0] === 'quiz' && c[1] === createdCode; }));
    // 还原标记，后面的用例还要用
    KM.store.set(KM.util.KEYS.submittedPrefix + createdCode, true);
  });

  await test('结果页：没有本地记录时给出「去答题」空状态', async () => {
    const other = await KM.db.createQuiz({
      title: '空结果',
      creatorName: '',
      questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }]
    });
    KM.store.del(KM.util.KEYS.lastResultPrefix + other.code);
    KM.ui.show('result');
    const container = doc.getElementById('view-result');
    await KM.views.result.init(container, { code: other.code });
    assert.ok(/没有找到你的作答记录/.test(container.textContent), '空状态没出现');
  });

  /* ─────────── 管理页 ─────────── */

  await test('管理页：key 正确 → 信息卡 + 排行表 + 每题正确率', async () => {
    const quiz = await KM.db.getQuiz(createdCode);
    KM.ui.show('admin');
    const container = doc.getElementById('view-admin');
    await KM.views.admin.init(container, { code: createdCode, key: quiz.adminKey });
    await wait(120);

    assert.ok(/出题人后台/.test(container.textContent), '信息卡没渲染');
    assert.ok(container.querySelector('.stat b'), '统计数字缺失');
    assert.strictEqual(container.querySelectorAll('.table tbody tr').length, 1, '表格应有 1 行');
    assert.ok(/测试员小王/.test(container.querySelector('.table tbody tr').textContent));
    assert.strictEqual(container.querySelectorAll('.acc-row').length, 2, '每题正确率应有 2 行');
    assert.ok(/100%/.test(container.querySelector('.acc-pct').textContent), '两题都答对了，正确率应是 100%');
    assert.ok(container.querySelector('.acc-bar i').style.width !== '', '正确率条宽度没设置');
  });

  await test('管理页：没有记录 + 错 key → 密钥门；输对 key 后放行', async () => {
    const quiz = await KM.db.getQuiz(createdCode);
    // 模拟"换一台设备"：清掉本机放行记录
    win.localStorage.removeItem('km.myCodes');

    KM.ui.show('admin');
    const container = doc.getElementById('view-admin');
    await KM.views.admin.init(container, { code: createdCode, key: 'wrong-key' });
    await wait(80);
    assert.ok(container.querySelector('.key-gate'), '应该出现密钥门');
    assert.ok(/需要管理密钥/.test(container.textContent));

    const input = container.querySelector('.key-gate input');
    input.value = quiz.adminKey;
    click(win, container.querySelector('.key-gate .btn-primary'));
    await wait(150);

    assert.strictEqual(container.querySelector('.key-gate'), null, '密钥正确后应放行');
    assert.ok(container.querySelector('.table'), '放行后应看到表格');
    assert.ok(KM.db.getMyCodes().indexOf(createdCode) !== -1, '放行后应记住这个 code');
  });

  await test('管理页：不存在的 code → 错误页', async () => {
    KM.ui.show('admin');
    const container = doc.getElementById('view-admin');
    await KM.views.admin.init(container, { code: 'ZZZZ' });
    await wait(60);
    assert.ok(/题目不存在/.test(container.textContent), '应提示题目不存在');
  });

  await test('答题页：非法 code → 格式错误页', async () => {
    KM.ui.show('quiz');
    const container = doc.getElementById('view-quiz');
    await KM.views.quiz.init(container, { code: 'ab' });
    await wait(30);
    assert.ok(/答题码看起来不对/.test(container.textContent));
  });

  /* ─────────── 超级管理员后台 ─────────── */

  await test('超级后台：未登录 → 显示口令门 + 默认口令提醒', async () => {
    KM.views.super.init(doc.getElementById('view-super'));
    await wait(50);
    const box = doc.getElementById('view-super');
    assert.ok(box.querySelector('.key-gate'), '应显示口令门');
    assert.ok(/超级管理员/.test(box.textContent));
    assert.ok(/CHANGE-ME-SUPER/.test(box.textContent), '应提示当前是默认口令');
  });

  await test('超级后台：错口令被拦，正确口令放行', async () => {
    const box = doc.getElementById('view-super');
    const input = box.querySelector('.key-gate input');
    input.value = 'wrong-key';
    click(win, box.querySelector('.key-gate .btn-primary'));
    await wait(30);
    assert.ok(box.querySelector('.key-gate'), '错口令不该放行');
    assert.ok(/口令不对/.test(box.textContent), '应提示口令不对');

    input.value = win.KM_CONFIG.SUPER_KEY;
    click(win, box.querySelector('.key-gate .btn-primary'));
    for (let i = 0; i < 80 && !box.querySelector('.table'); i++) await wait(20);
    assert.strictEqual(box.querySelector('.key-gate'), null, '口令正确后应进入后台');
    assert.ok(box.querySelector('.table'), '应渲染表格');
  });

  await test('超级后台：列出全部题目 + 统计 + 本地模式提示', async () => {
    const box = doc.getElementById('view-super');
    const rows = box.querySelectorAll('.table tbody tr');
    assert.ok(rows.length >= 3, '应至少列出 3 套题，实际 ' + rows.length);
    assert.ok(box.querySelector('.super-head'), '头部卡片缺失');
    assert.ok(/本地模式/.test(box.textContent), '应有本地模式提示');
    assert.ok(/默认超级口令/.test(box.textContent), '应有默认口令警告');
    const stats = box.querySelectorAll('.admin-stats .stat b');
    assert.strictEqual(stats.length, 3, '三个统计块');
    assert.ok(Number(stats[0].textContent) >= 3, '题目总数应 ≥3');
  });

  await test('超级后台：搜索能按答题码过滤', async () => {
    const box = doc.getElementById('view-super');
    const search = box.querySelector('.super-search');
    search.value = createdCode;
    search.dispatchEvent(new win.Event('input', { bubbles: true }));
    await wait(20);
    let rows = box.querySelectorAll('.table tbody tr');
    assert.strictEqual(rows.length, 1, '搜答题码应只剩 1 行');
    assert.ok(rows[0].textContent.indexOf(createdCode) !== -1);

    search.value = '不存在的关键词zzz';
    search.dispatchEvent(new win.Event('input', { bubbles: true }));
    await wait(20);
    assert.ok(/没有匹配的题目/.test(box.textContent), '应显示搜索空状态');

    search.value = '';
    search.dispatchEvent(new win.Event('input', { bubbles: true }));
    await wait(20);
    assert.ok(box.querySelectorAll('.table tbody tr').length >= 3, '清空搜索后恢复');
  });

  await test('超级后台：详情弹窗能看到题面和正确答案', async () => {
    const box = doc.getElementById('view-super');
    const rows = Array.prototype.slice.call(box.querySelectorAll('.table tbody tr'));
    const target = rows.filter(function (r) { return r.textContent.indexOf(createdCode) !== -1; })[0];
    const detailBtn = Array.prototype.slice.call(target.querySelectorAll('button'))
      .filter(function (b) { return /详情/.test(b.textContent); })[0];
    click(win, detailBtn);
    await wait(30);

    const modal = doc.querySelector('.modal');
    assert.ok(modal, '详情弹窗没出现');
    assert.ok(modal.textContent.indexOf(questions[0].q) !== -1, '应显示题干');
    assert.ok(modal.textContent.indexOf(questions[1].q) !== -1, '应显示第二题');
    assert.strictEqual(modal.querySelectorAll('.detail-opt.is-answer').length, 2, '两题各标一个正确答案');
    assert.ok(/管理链接/.test(modal.textContent), '应能复制管理链接');

    const closeBtn = Array.prototype.slice.call(modal.querySelectorAll('.btn'))
      .filter(function (b) { return /关闭/.test(b.textContent); })[0];
    click(win, closeBtn);
    await wait(20);
    assert.strictEqual(doc.querySelectorAll('.modal').length, 0, '弹窗应关闭');
  });

  let adoptedCode = '';

  await test('超级后台：代建一套题 → 出现在列表，但不进「我的题目」', async () => {
    const box = doc.getElementById('view-super');
    const myBefore = KM.db.getMyCodes().length;

    const newBtn = Array.prototype.slice.call(box.querySelectorAll('.super-toolbar-actions .btn'))
      .filter(function (b) { return /新建题目/.test(b.textContent); })[0];
    click(win, newBtn);
    await wait(30);

    const panel = box.querySelector('.super-create');
    assert.ok(panel, '代建面板没出现');

    const titleInput = panel.querySelector('.create-form .field .input');
    titleInput.value = '超级后台代建的题目';
    const card = panel.querySelector('.q-editor');
    card.querySelector('.q-text').value = '超级后台代建的题目';
    card.querySelectorAll('.opt-input').forEach(function (input, i) { input.value = '选项' + 'ABCD'[i]; });
    panel.querySelector('.create-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));

    for (let i = 0; i < 80 && !doc.querySelector('.modal'); i++) await wait(20);
    const modal = doc.querySelector('.modal');
    assert.ok(modal, '创建后应弹出详情');

    adoptedCode = modal.querySelector('.super-code').textContent.trim();
    assert.ok(KM.util.CODE_RE.test(adoptedCode), '答题码格式不对：' + adoptedCode);
    assert.strictEqual(KM.db.getMyCodes().length, myBefore, '不该写进「我的题目」');

    const quiz = await KM.db.getQuiz(adoptedCode);
    assert.ok(quiz, '题目应已创建');
    assert.strictEqual(quiz.title, '超级后台代建的题目');
    assert.strictEqual(quiz.questions.length, 1);

    const closeBtn = Array.prototype.slice.call(modal.querySelectorAll('.btn'))
      .filter(function (b) { return /关闭/.test(b.textContent); })[0];
    click(win, closeBtn);
    await wait(20);
  });

  await test('超级后台：删除整套题 → 列表少一行、数据真没了', async () => {
    const box = doc.getElementById('view-super');
    const before = box.querySelectorAll('.table tbody tr').length;

    const rows = Array.prototype.slice.call(box.querySelectorAll('.table tbody tr'));
    const target = rows.filter(function (r) { return r.textContent.indexOf(adoptedCode) !== -1; })[0];
    assert.ok(target, '列表里应能找到刚代建的那套题');

    const delBtn = Array.prototype.slice.call(target.querySelectorAll('button'))
      .filter(function (b) { return /删除/.test(b.textContent); })[0];
    click(win, delBtn);
    await wait(30);

    const confirmBtn = Array.prototype.slice.call(doc.querySelectorAll('.modal .btn'))
      .filter(function (b) { return /永久删除/.test(b.textContent); })[0];
    assert.ok(confirmBtn, '应有二次确认');

    click(win, confirmBtn);
    for (let i = 0; i < 100 && box.querySelectorAll('.table tbody tr').length >= before; i++) await wait(20);

    assert.strictEqual(box.querySelectorAll('.table tbody tr').length, before - 1, '列表应少一行');
    assert.strictEqual(await KM.db.getQuiz(adoptedCode), null, '题目应被真正删除');
    assert.strictEqual(win.localStorage.getItem('km.quiz.' + adoptedCode), null, 'localStorage 里也要没');
  });

  await test('后台登录态：超过 SESSION_MINUTES 后失效，重新要口令', async () => {
    const box = doc.getElementById('view-super');
    // 伪造一个 3 小时前的登录记录（默认 120 分钟）
    win.sessionStorage.setItem('km.super.ok', JSON.stringify({ at: Date.now() - 3 * 60 * 60 * 1000 }));
    KM.views.super.init(box);
    await wait(30);
    assert.ok(box.querySelector('.key-gate'), '过期后应重新要求口令');
    assert.strictEqual(win.sessionStorage.getItem('km.super.ok'), null, '过期记录应被清掉');
  });


  await test('后台目录：/manage 直接进后台，且不影响站内跳转', async () => {
    const second = boot('http://localhost/manage');
    second.win.KM_CONFIG.SHOW_FOOTER_LINK = false;
    second.win.KM.router.start();
    await wait(40);

    assert.strictEqual(second.win.KM.isAdminPage, true, '应识别为后台页');
    assert.strictEqual(second.win.KM.basePath, '/', '站点根应回退到 /');

    const box = second.doc.getElementById('view-super');
    assert.strictEqual(box.hidden, false, 'super 视图应显示');
    assert.ok(box.querySelector('.key-gate'), '应直接出后台口令门');
    assert.strictEqual(second.doc.getElementById('view-home').hidden, true, '不应同时显示首页');
    assert.strictEqual(second.doc.getElementById('footer-admin').hidden, true, 'SHOW_FOOTER_LINK=false 应隐藏入口');
    assert.strictEqual(second.win.KM.nav.quizUrl('AB2C'), 'http://localhost/?code=AB2C', '跳转必须回站点根');
    second.win.close();
  });

  await test('后台目录：/manage/ 带尾斜杠也能进', async () => {
    const third = boot('http://localhost/manage/');
    third.win.KM.router.start();
    await wait(40);
    assert.strictEqual(third.win.KM.isAdminPage, true);
    assert.strictEqual(third.win.KM.basePath, '/');
    assert.ok(third.doc.getElementById('view-super').querySelector('.key-gate'), '带斜杠也应出后台');
    assert.strictEqual(third.win.KM.nav.quizUrl('AB2C'), 'http://localhost/?code=AB2C');
    third.win.close();
  });

  await test('运行过程中没有未捕获的 JS 错误', () => {
    const noise = consoleErrors.filter(function (line) {
      return !/Not implemented|Could not parse CSS/.test(line);
    });
    assert.deepStrictEqual(noise, [], '出现 JS 错误：\n' + noise.join('\n'));
  });

  /* ─────────── 汇总 ─────────── */

  console.log('\n' + '─'.repeat(46));
  if (failures.length) {
    console.log('❌ ' + failures.length + ' 个失败 / ' + passed + ' 个通过\n');
    failures.forEach(function (f) {
      console.log('· ' + f.name);
      if (f.err && f.err.stack) {
        console.log('  ' + f.err.stack.split('\n').slice(0, 4).join('\n  '));
      }
    });
    try { win.close(); } catch (e) { /* noop */ }
    process.exit(1);
  } else {
    console.log('✅ 全部通过：' + passed + ' 个用例\n');
    try { win.close(); } catch (e) { /* noop */ }
    process.exit(0);
  }
})();
