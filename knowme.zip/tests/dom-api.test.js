/* ===========================================================
   tests/dom-api.test.js — 前端 ↔ 真实后端 的端到端测试
   -----------------------------------------------------------
   起一个真的 server.js（json 驱动），把这套前端跑在 jsdom 里，
   STORAGE_MODE = 'api'，走一遍：创建 → 答题（服务端判分）→ 结果 → 管理 → 超级口令。
   运行：node tests/dom-api.test.js
   =========================================================== */

'use strict';

const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { spawn } = require('child_process');
const { JSDOM } = require('jsdom');

const ROOT = path.join(__dirname, '..');
const PORT = Number(process.env.TEST_PORT) || 8903;
const ORIGIN = 'http://127.0.0.1:' + PORT;
const DATA_DIR = path.join(ROOT, '.testdata');
const DATA_FILE = path.join(DATA_DIR, 'dom-api.json');
const SUPER_KEY = 'dom-super-key';

const SCRIPTS = [
  'js/config.js',
  'js/config.admin.js',
  'js/utils.js',
  'js/editor.js',
  'js/db.js',
  'js/certificate.js',
  'js/router.js',
  'js/home.js',
  'js/quiz.js',
  'js/result.js',
  'js/admin.js',
  'js/super.js'
];

let child = null;
let passed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('  ✓ ' + name);
  } catch (err) {
    failures.push({ name, err });
    console.log('  ✗ ' + name + '\n      ' + (err && err.message));
  }
}

const wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

async function waitForServer() {
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(ORIGIN + '/api/health');
      if (res.ok) return true;
    } catch (e) { /* 还没起来 */ }
    await wait(200);
  }
  return false;
}

function fakeContext() {
  const store = {};
  const noop = function () {};
  return new Proxy(store, {
    get(target, prop) {
      if (prop === 'measureText') return function (text) { return { width: String(text).length * 18 }; };
      if (prop === 'createLinearGradient' || prop === 'createRadialGradient') {
        return function () { return { addColorStop: noop }; };
      }
      if (prop === 'canvas') return null;
      if (prop in target) return target[prop];
      return noop;
    },
    set(target, prop, value) { target[prop] = value; return true; }
  });
}

function boot() {
  let html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  html = html.replace(/<script[\s\S]*?<\/script>/g, '');

  const dom = new JSDOM(html, {
    url: ORIGIN + '/',
    runScripts: 'dangerously',
    pretendToBeVisual: true
  });

  const win = dom.window;
  const doc = win.document;

  win.scrollTo = function () {};
  win.Element.prototype.scrollIntoView = function () {};
  win.HTMLCanvasElement.prototype.getContext = function () { return fakeContext(); };
  win.HTMLCanvasElement.prototype.toBlob = function (cb) { cb(new win.Blob(['png'], { type: 'image/png' })); };
  win.URL.createObjectURL = function () { return 'blob:stub'; };
  win.URL.revokeObjectURL = function () {};
  win.AudioContext = undefined;
  win.webkitAudioContext = undefined;

  // 关键：把 Node 的 fetch 借给 jsdom
  win.fetch = function (input, init) {
    return fetch(new URL(String(input), win.location.href), init);
  };

  const errors = [];
  win.console.error = function () { errors.push(Array.prototype.slice.call(arguments).join(' ')); };
  win.addEventListener('error', function (e) { errors.push('window.onerror: ' + (e.message || e.error)); });

  SCRIPTS.forEach(function (file) {
    win.eval(fs.readFileSync(path.join(ROOT, file), 'utf8') + '\n//# sourceURL=' + file);
  });

  return { dom, win, doc, errors };
}

function click(win, el) {
  assert.ok(el, '要点击的元素不存在');
  el.dispatchEvent(new win.MouseEvent('click', { bubbles: true, cancelable: true }));
}

function stopServer() {
  if (!child) return Promise.resolve();
  const proc = child;
  child = null;
  return new Promise(function (resolve) {
    let done = false;
    const finish = function () { if (!done) { done = true; resolve(); } };
    proc.on('exit', finish);
    try { proc.kill(); } catch (e) { /* noop */ }
    setTimeout(function () {
      try { process.kill(proc.pid); } catch (e) { /* noop */ }
      finish();
    }, 2500);
  });
}

(async function run() {
  console.log('\n前端 ↔ 后端 端到端测试（STORAGE_MODE = api）\n');

  fs.rmSync(DATA_DIR, { recursive: true, force: true });
  fs.mkdirSync(DATA_DIR, { recursive: true });

  child = spawn(process.execPath, [path.join(ROOT, 'server.js'), '--no-open'], {
    cwd: ROOT,
    env: Object.assign({}, process.env, {
      PORT: String(PORT),
      KM_DB: 'json',
      KM_DB_FILE: DATA_FILE,
      KM_SUPER_KEY: SUPER_KEY
    }),
    stdio: 'ignore',
    windowsHide: true
  });

  if (!(await waitForServer())) {
    console.error('✗ 后端没起来');
    await stopServer();
    process.exit(1);
  }

  const { win, doc, errors } = boot();
  const KM = win.KM;

  win.KM_CONFIG.STORAGE_MODE = 'api';

  const navCalls = [];
  KM.nav.quiz = function (code) { navCalls.push(['quiz', code]); };
  KM.nav.result = function (code) { navCalls.push(['result', code]); };
  KM.nav.admin = function (code, key) { navCalls.push(['admin', code, key]); };
  KM.nav.home = function () { navCalls.push(['home']); };

  KM.router.start();
  await wait(50);

  await test('前端识别为 api 模式，首页不再提示"本地体验模式"', () => {
    assert.strictEqual(KM.db.mode(), 'api');
    assert.strictEqual(KM.db.isRemote(), true);
    assert.strictEqual(KM.db.isServerAuth(), true);
    assert.strictEqual(doc.getElementById('mode-hint').hidden, true);
  });

  const questions = [
    { q: '我最喜欢的颜色？', options: ['红', '蓝', '绿', '黄'], answer: 1 },
    { q: '我最常熬夜到几点？', options: ['11 点', '1 点', '3 点', '不睡'], answer: 2 }
  ];
  let code = '';

  await test('首页建题：走服务端 POST /api/quizzes，拿到 code 和 adminKey', async () => {
    click(win, doc.getElementById('toggle-create'));
    const cards = doc.querySelectorAll('.q-editor');
    assert.strictEqual(cards.length, 1);

    // 加第二题
    const addBtn = doc.querySelectorAll('.create-actions .btn')[0];
    click(win, addBtn);

    const all = doc.querySelectorAll('.q-editor');
    all.forEach(function (card, i) {
      card.querySelector('.q-text').value = questions[i].q;
      card.querySelectorAll('.opt-input').forEach(function (input, j) {
        input.value = questions[i].options[j];
      });
      card.querySelectorAll('input[type="radio"]')[questions[i].answer].click();
    });

    doc.querySelector('.create-form').dispatchEvent(new win.Event('submit', { bubbles: true, cancelable: true }));
    for (let i = 0; i < 100 && !doc.querySelector('.result-code strong'); i++) await wait(30);

    const strong = doc.querySelector('.result-code strong');
    assert.ok(strong, '创建成功弹窗没出现');
    code = strong.textContent.trim();
    assert.ok(KM.util.CODE_RE.test(code), 'code 格式：' + code);

    const stored = KM.db.storedAdminKey(code);
    assert.strictEqual(stored.length, 16, '本机应记住 adminKey，实际：' + stored);

    const quiz = await KM.db.getQuiz(code);
    assert.ok(quiz, '服务端应能取回题目');
    assert.strictEqual(quiz.questions.length, 2);
    assert.strictEqual(quiz.adminKey, stored, 'getQuiz 应把本机 key 带回来');
  });

  await test('答题：服务端判分（2 题全对 = 2 分）', async () => {
    doc.querySelectorAll('.modal-overlay').forEach(function (n) { n.remove(); });
    KM.ui.show('quiz');
    await KM.views.quiz.init(doc.getElementById('view-quiz'), { code: code });

    doc.getElementById('nick-input').value = '接口测试员';

    const realSetTimeout = win.setTimeout;
    win.setTimeout = function (fn, ms) { return realSetTimeout(fn, Math.min(Number(ms) || 0, 5)); };
    click(win, doc.querySelector('.quiz-start .btn-primary'));

    for (let i = 0; i < 2; i++) {
      let opts = [];
      for (let t = 0; t < 100 && opts.length === 0; t++) {
        opts = doc.querySelectorAll('.quiz-card .opt');
        if (!opts.length) await wait(10);
      }
      assert.strictEqual(opts.length, 4);
      click(win, opts[questions[i].answer]);
      await wait(120);
    }

    win.setTimeout = realSetTimeout;

    for (let i = 0; i < 100 && !navCalls.some(function (c) { return c[0] === 'result'; }); i++) await wait(30);
    assert.ok(navCalls.some(function (c) { return c[0] === 'result' && c[1] === code; }), '答完应跳结果页');

    const last = KM.store.get(KM.util.KEYS.lastResultPrefix + code, null);
    assert.ok(last, '结果应存到本地');
    assert.strictEqual(last.score, 2, '服务端判分应为 2');
    assert.deepStrictEqual(Array.from(last.answers), [1, 1]);
  });

  await test('成绩确实写进了服务端：排行榜 1 人', async () => {
    const ranking = await KM.db.getRanking(code, 20);
    assert.strictEqual(ranking.length, 1);
    assert.strictEqual(ranking[0].nickname, '接口测试员');
    assert.strictEqual(ranking[0].score, 2);
  });

  await test('结果页：分数 / 排行榜 / 证书都能渲染', async () => {
    KM.ui.show('result');
    await KM.views.result.init(doc.getElementById('view-result'), { code: code });
    await wait(1200);

    assert.strictEqual(doc.querySelector('.result-score .num').textContent, '2');
    const rows = doc.querySelectorAll('.rank-row');
    assert.strictEqual(rows.length, 1);
    assert.ok(rows[0].classList.contains('is-me'));
    assert.ok(doc.querySelector('.cert-wrap canvas'), '证书 canvas 应存在');
  });

  await test('管理页：记住的密钥自动放行，错误密钥被拒', async () => {
    assert.strictEqual(await KM.db.verifyAdmin(code, 'wrong-key'), false, '错误密钥应拒绝');
    assert.strictEqual(await KM.db.verifyAdmin(code, ''), true, '本机记住的密钥应能通过');

    KM.ui.show('admin');
    await KM.views.admin.init(doc.getElementById('view-admin'), { code: code });
    await wait(200);

    assert.ok(doc.querySelector('#view-admin .table'), '应直接进管理页');
    assert.strictEqual(doc.querySelectorAll('#view-admin .table tbody tr').length, 1);
    assert.ok(/服务器数据库/.test(doc.querySelector('#view-admin').textContent), '应显示服务器数据库模式');
  });

  await test('超级口令：服务端校验，对/错都符合预期', async () => {
    assert.strictEqual(await KM.db.verifySuper('bad-key'), false);
    assert.strictEqual(await KM.db.verifySuper(SUPER_KEY), true);

    const items = await KM.db.listAllQuizzes();
    assert.ok(items.length >= 1, '超级列表应至少 1 套题');
    assert.ok(items.some(function (q) { return q.code === code; }), '列表里应有刚建的那套');
  });

  await test('运行过程中没有未捕获的 JS 错误', () => {
    const noise = errors.filter(function (line) {
      return !/Not implemented|Could not parse CSS/.test(line);
    });
    assert.deepStrictEqual(noise, [], '出现 JS 错误：\n' + noise.join('\n'));
  });

  try { win.close(); } catch (e) { /* noop */ }
  await stopServer();

  console.log('\n' + '─'.repeat(46));
  if (failures.length) {
    console.log('❌ ' + failures.length + ' 个失败 / ' + passed + ' 个通过\n');
    failures.forEach(function (f) {
      console.log('· ' + f.name);
      if (f.err && f.err.stack) console.log('  ' + f.err.stack.split('\n').slice(0, 4).join('\n  '));
    });
    fs.rmSync(DATA_DIR, { recursive: true, force: true });
    process.exit(1);
  } else {
    console.log('✅ 全部通过：' + passed + ' 个用例\n');
    fs.rmSync(DATA_DIR, { recursive: true, force: true });
    process.exit(0);
  }
})().catch(async function (err) {
  console.error('测试崩溃：', err);
  await stopServer();
  process.exit(1);
});
