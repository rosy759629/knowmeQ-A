/* ===========================================================
   tests/local-db.test.js — 本地数据层逻辑自测
   运行：node tests/local-db.test.js
   （用最小的 window / localStorage 桩件把浏览器脚本跑在 node 里）
   =========================================================== */

'use strict';

const path = require('path');
const assert = require('assert');

/* ─────────── 浏览器环境桩 ─────────── */

class MemoryStorage {
  constructor() { this.map = new Map(); }
  get length() { return this.map.size; }
  key(index) {
    const keys = Array.from(this.map.keys());
    return index >= 0 && index < keys.length ? keys[index] : null;
  }
  getItem(key) { return this.map.has(String(key)) ? this.map.get(String(key)) : null; }
  setItem(key, value) { this.map.set(String(key), String(value)); }
  removeItem(key) { this.map.delete(String(key)); }
  clear() { this.map.clear(); }
}

global.window = global;
global.localStorage = new MemoryStorage();
global.performance = global.performance || { now: () => Date.now() };

const ROOT = path.join(__dirname, '..');
require(path.join(ROOT, 'js/config.js'));
require(path.join(ROOT, 'js/utils.js'));
require(path.join(ROOT, 'js/db.js'));

const KM = global.KM;
const U = KM.util;

/* ─────────── 迷你测试框架 ─────────── */

let passed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('  ✓ ' + name);
  } catch (err) {
    failures.push({ name, err });
    console.log('  ✗ ' + name + '\n      ' + (err && err.message));
  }
}

function reset() {
  global.localStorage.clear();
  global.window.KM_CONFIG.STORAGE_MODE = 'local';
}

/* ─────────── 用例 ─────────── */

(async function run() {
  console.log('\nlocalStorage 模式 · 数据层自测\n');

  await test('随机 code：4 位、合法字符集、不含 I/O/0/1', () => {
    for (let i = 0; i < 300; i++) {
      const code = U.randomCode();
      assert.strictEqual(code.length, 4, '长度应为 4，实际 ' + code);
      assert.ok(U.CODE_RE.test(code), '非法字符：' + code);
    }
  });

  await test('随机 code 不重复（1000 次抽样应有足够多样性）', () => {
    const set = new Set();
    for (let i = 0; i < 1000; i++) set.add(U.randomCode());
    assert.ok(set.size > 950, '重复太多：' + set.size);
  });

  await test('admin_key 是 16 位', () => {
    const key = U.randomKey();
    assert.strictEqual(key.length, 16, '实际：' + key);
  });

  await test('code 校验：大小写 / 空格 / 长度 / 非法字符', () => {
    assert.strictEqual(U.validateCode('a7k2').ok, true, '小写应通过并转大写');
    assert.strictEqual(U.validateCode('a7k2').code, 'A7K2');
    assert.strictEqual(U.validateCode(' A7K2 ').ok, true);
    assert.strictEqual(U.validateCode('A7K').ok, false, '3 位应拒绝');
    assert.strictEqual(U.validateCode('A7K2X9Z').ok, false, '7 位应拒绝');
    assert.strictEqual(U.validateCode('A7O2').ok, false, 'O 应拒绝');
    assert.strictEqual(U.validateCode('A7K0').ok, false, '0 应拒绝');
    assert.strictEqual(U.validateCode('').ok, false);
  });

  await test('创建题目 → 取回 → 字段完整', async () => {
    reset();
    const questions = [
      { q: '我最喜欢的颜色？', options: ['红', '蓝', '绿', '黄'], answer: 1 },
      { q: '我几点睡？', options: ['10 点', '12 点', '2 点', '不睡'], answer: 2 }
    ];
    const created = await KM.db.createQuiz({ title: '你是不是最懂我', creatorName: '小张', questions });

    assert.ok(created.code, '应有 code');
    assert.strictEqual(created.adminKey.length, 16);

    const quiz = await KM.db.getQuiz(created.code);
    assert.ok(quiz, '应能取回题目');
    assert.strictEqual(quiz.title, '你是不是最懂我');
    assert.strictEqual(quiz.creatorName, '小张');
    assert.strictEqual(quiz.adminKey, created.adminKey);
    assert.strictEqual(quiz.questions.length, 2);
    assert.strictEqual(quiz.questions[1].answer, 2);
    assert.ok(quiz.createdAt, '应有创建时间');
  });

  await test('取题码大小写不敏感；不存在的码返回 null', async () => {
    reset();
    const created = await KM.db.createQuiz({
      title: 'T', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }]
    });
    const lower = await KM.db.getQuiz(created.code.toLowerCase());
    assert.ok(lower, '小写 code 应能取回');
    assert.strictEqual(await KM.db.getQuiz('ZZZZ'), null);
    assert.strictEqual(await KM.db.getQuiz(''), null);
  });

  await test('创建的题目会进入「我的题目」列表', async () => {
    reset();
    const a = await KM.db.createQuiz({ title: 'A', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    const b = await KM.db.createQuiz({ title: 'B', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    const codes = KM.db.getMyCodes();
    assert.ok(codes.includes(a.code) && codes.includes(b.code));
    assert.strictEqual(codes[0], b.code, '最新的排最前');
  });

  await test('提交成绩 → 排行榜排序：分数降序、同分用时短优先、再按先提交', async () => {
    reset();
    const created = await KM.db.createQuiz({
      title: '排序测试', creatorName: '',
      questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }]
    });
    const code = created.code;

    await KM.db.submitScore({ code, nickname: '慢满分', score: 1, total: 1, duration: 80, answers: [1] });
    await KM.db.submitScore({ code, nickname: '快满分', score: 1, total: 1, duration: 20, answers: [1] });
    await KM.db.submitScore({ code, nickname: '全错', score: 0, total: 1, duration: 5, answers: [0] });
    await KM.db.submitScore({ code, nickname: '同分同秒先交', score: 1, total: 1, duration: 20, answers: [1] });

    const ranking = await KM.db.getRanking(code, 20);
    assert.strictEqual(ranking.length, 4);
    assert.strictEqual(ranking[0].nickname, '快满分', '同分应该用时短的在前，先提交的优先');
    assert.strictEqual(ranking[1].nickname, '同分同秒先交');
    assert.strictEqual(ranking[2].nickname, '慢满分');
    assert.strictEqual(ranking[3].nickname, '全错', '分数最高的永远在最前');
  });

  await test('排行榜 limit 生效', async () => {
    reset();
    const created = await KM.db.createQuiz({ title: 'L', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    for (let i = 0; i < 25; i++) {
      await KM.db.submitScore({ code: created.code, nickname: 'p' + i, score: i % 3, total: 3, duration: i, answers: [0, 0, 0] });
    }
    const top = await KM.db.getRanking(created.code, 20);
    assert.strictEqual(top.length, 20);
    const top5 = await KM.db.getRanking(created.code, 5);
    assert.strictEqual(top5.length, 5);
  });

  await test('每题正确率聚合正确', async () => {
    reset();
    const created = await KM.db.createQuiz({
      title: '正确率', creatorName: '',
      questions: [
        { q: 'Q1', options: ['a', 'b', 'c', 'd'], answer: 0 },
        { q: 'Q2', options: ['a', 'b', 'c', 'd'], answer: 1 },
        { q: 'Q3', options: ['a', 'b', 'c', 'd'], answer: 2 }
      ]
    });
    // 三个人：Q1 全对；Q2 两人对；Q3 零人对
    await KM.db.submitScore({ code: created.code, nickname: 'a', score: 2, total: 3, duration: 10, answers: [1, 1, 0] });
    await KM.db.submitScore({ code: created.code, nickname: 'b', score: 2, total: 3, duration: 11, answers: [1, 1, 0] });
    await KM.db.submitScore({ code: created.code, nickname: 'c', score: 1, total: 3, duration: 12, answers: [1, 0, 0] });

    const scores = await KM.db.getAllScores(created.code);
    const quiz = await KM.db.getQuiz(created.code);
    const acc = KM.db.accuracyByQuestion(quiz, scores);

    assert.strictEqual(acc[0].correct, 3);
    assert.strictEqual(acc[1].correct, 2);
    assert.strictEqual(acc[2].correct, 0);
    assert.strictEqual(Math.round(acc[1].rate * 100), 67);

    const stats = KM.db.stats(scores);
    assert.strictEqual(stats.count, 3);
    assert.strictEqual(stats.fullCount, 0);
    assert.ok(Math.abs(stats.avgScore - 5 / 3) < 1e-9);
  });

  await test('提交成绩时 answers 归一化为 0/1；duration 取整', async () => {
    reset();
    const created = await KM.db.createQuiz({ title: 'N', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    await KM.db.submitScore({
      code: created.code, nickname: 'n', score: 2, total: 2,
      duration: 12.7, answers: [true, 1, 0, false]
    });
    const scores = await KM.db.getAllScores(created.code);
    assert.deepStrictEqual(scores[0].answers, [1, 1, 0, 0]);
    assert.strictEqual(scores[0].duration, 13);
  });

  await test('昵称缺失时回落到「匿名」，超长截断', async () => {
    reset();
    const created = await KM.db.createQuiz({ title: 'X', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    await KM.db.submitScore({ code: created.code, nickname: '', score: 0, total: 1, duration: 3, answers: [0] });
    const longName = '很长的昵称'.repeat(10);
    await KM.db.submitScore({ code: created.code, nickname: longName, score: 0, total: 1, duration: 3, answers: [0] });
    const scores = await KM.db.getAllScores(created.code);
    assert.strictEqual(scores[0].nickname, '匿名');
    assert.ok(scores[1].nickname.length <= 24, '应截断到 24 字以内');
  });

  await test('删除单条成绩（本地模式）', async () => {
    reset();
    const created = await KM.db.createQuiz({ title: 'D', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    await KM.db.submitScore({ code: created.code, nickname: '要走的人', score: 1, total: 1, duration: 4, answers: [1] });
    await KM.db.submitScore({ code: created.code, nickname: '留下的人', score: 1, total: 1, duration: 5, answers: [1] });
    let scores = await KM.db.getAllScores(created.code);
    assert.strictEqual(scores.length, 2);
    await KM.db.deleteScore(created.code, scores[0].id);
    scores = await KM.db.getAllScores(created.code);
    assert.strictEqual(scores.length, 1);
    assert.strictEqual(scores[0].nickname, '留下的人');
  });

  await test('提交失败 → 进 pending 队列 → flush 补交', async () => {
    reset();
    const created = await KM.db.createQuiz({ title: 'P', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });

    KM.db.queuePending({ code: created.code, nickname: '离线的人', score: 1, total: 1, duration: 9, answers: [1] });
    assert.strictEqual(KM.db.getPending(created.code).length, 1);
    assert.strictEqual(await KM.db.getAllScores(created.code).then((s) => s.length), 0);

    const res = await KM.db.flushPending();
    assert.deepStrictEqual(res, { ok: true, done: 1, failed: 0 });
    assert.strictEqual(KM.db.getPending().length, 0);
    const scores = await KM.db.getAllScores(created.code);
    assert.strictEqual(scores.length, 1);
    assert.strictEqual(scores[0].nickname, '离线的人');
  });

  await test('评价文案五档边界', () => {
    assert.strictEqual(U.evaluate(5, 5).emoji, '🏆');
    assert.strictEqual(U.evaluate(4, 5).emoji, '💯');
    assert.strictEqual(U.evaluate(3, 5).emoji, '😊');
    assert.strictEqual(U.evaluate(2, 5).emoji, '🤔');
    assert.strictEqual(U.evaluate(1, 5).emoji, '😅');
    assert.strictEqual(U.evaluate(0, 5).emoji, '😅');
  });

  await test('时长格式化', () => {
    assert.strictEqual(U.formatDuration(45), '45 秒');
    assert.strictEqual(U.formatDuration(90), '1 分 30 秒');
    assert.strictEqual(U.formatDuration(120), '2 分钟');
    assert.strictEqual(U.formatDuration(null), '—');
  });

  await test('CSV 转义：逗号 / 引号 / 换行', () => {
    assert.strictEqual(U.csvEscape('普通'), '普通');
    assert.strictEqual(U.csvEscape('a,b'), '"a,b"');
    assert.strictEqual(U.csvEscape('说"话"'), '"说""话"""');
    assert.strictEqual(U.csvEscape('两行\n内容'), '"两行\n内容"');
  });

  await test('云端模式缺配置时给出可读报错', async () => {
    reset();
    global.window.KM_CONFIG.STORAGE_MODE = 'cloud';
    let message = '';
    try {
      await KM.db.createQuiz({ title: 'C', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
      throw new Error('应该抛错');
    } catch (err) {
      message = err.message;
    }
    assert.ok(/Supabase/i.test(message), '报错应提示 Supabase 配置，实际：' + message);
    global.window.KM_CONFIG.STORAGE_MODE = 'local';
  });

  await test('未知 code 的排行榜返回空数组（不炸）', async () => {
    reset();
    assert.deepStrictEqual(await KM.db.getRanking('ZZZZ', 20), []);
    assert.deepStrictEqual(await KM.db.getAllScores('ZZZZ'), []);
  });

  /* ─────────── 超级管理员 ─────────── */

  await test('超级管理：列出本机全部题目（按创建时间倒序）', async () => {
    reset();
    const a = await KM.db.createQuiz({ title: 'A 套', creatorName: '甲', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    await new Promise(function (r) { setTimeout(r, 5); });
    const b = await KM.db.createQuiz({ title: 'B 套', creatorName: '乙', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });

    const list = await KM.db.listAllQuizzes();
    assert.strictEqual(list.length, 2);
    assert.strictEqual(list[0].code, b.code, '最新的排最前');
    assert.strictEqual(list[1].code, a.code);
    assert.strictEqual(list[1].creatorName, '甲');
    assert.ok(list[1].adminKey, '列表要带 adminKey，超级后台要跳管理页');
    assert.ok(Array.isArray(list[1].questions) && list[1].questions.length === 1);
  });

  await test('超级管理：列出所有题目时不会被非题目 key 干扰', async () => {
    reset();
    await KM.db.createQuiz({ title: 'T', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    global.localStorage.setItem('km.myCodes', '["XXXX"]');
    global.localStorage.setItem('km.nickname', '"小张"');
    global.localStorage.setItem('km.muted', 'true');
    const list = await KM.db.listAllQuizzes();
    assert.strictEqual(list.length, 1);
  });

  await test('超级管理：每套题的作答人数统计', async () => {
    reset();
    const a = await KM.db.createQuiz({ title: 'A', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });
    const b = await KM.db.createQuiz({ title: 'B', creatorName: '', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] });

    await KM.db.submitScore({ code: a.code, nickname: 'p1', score: 1, total: 1, duration: 3, answers: [1] });
    await KM.db.submitScore({ code: a.code, nickname: 'p2', score: 0, total: 1, duration: 4, answers: [0] });
    await KM.db.submitScore({ code: b.code, nickname: 'p3', score: 1, total: 1, duration: 5, answers: [1] });

    const counts = await KM.db.getScoreCounts();
    assert.strictEqual(counts[a.code], 2);
    assert.strictEqual(counts[b.code], 1);
    assert.strictEqual(counts['ZZZZ'], undefined);
  });

  await test('超级管理：删除整套题 → 题目、成绩、本机记录、待补交队列都清掉', async () => {
    reset();
    const created = await KM.db.createQuiz({
      title: '要被删掉的', creatorName: '',
      questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }]
    });
    await KM.db.submitScore({ code: created.code, nickname: 'p', score: 1, total: 1, duration: 2, answers: [1] });
    KM.db.queuePending({ code: created.code, nickname: 'offline', score: 1, total: 1, duration: 9, answers: [1] });
    global.window.localStorage.setItem('km.lastResult.' + created.code, '{"score":1}');
    global.window.localStorage.setItem('km.submitted.' + created.code, 'true');

    assert.ok(await KM.db.getQuiz(created.code), '删之前应该存在');
    assert.strictEqual(KM.db.getMyCodes().length, 1);

    await KM.db.deleteQuiz(created.code);

    assert.strictEqual(await KM.db.getQuiz(created.code), null, '题目应被删除');
    assert.deepStrictEqual(await KM.db.getAllScores(created.code), [], '成绩应被删除');
    assert.strictEqual(KM.db.getMyCodes().length, 0, '本机记录应被清掉');
    assert.strictEqual(KM.db.getPending().length, 0, '待补交队列应被清掉');
    assert.strictEqual(global.window.localStorage.getItem('km.lastResult.' + created.code), null);
    assert.strictEqual(global.window.localStorage.getItem('km.submitted.' + created.code), null);
    assert.deepStrictEqual(await KM.db.listAllQuizzes(), [], '列表应为空');
  });

  await test('超级管理：删除不存在的 code 也不报错（幂等）', async () => {
    reset();
    const res = await KM.db.deleteQuiz('ZZZZ');
    assert.deepStrictEqual(res, { ok: true });
  });

  await test('代建题目：skipMyCodes 不会进「我的题目」', async () => {
    reset();
    const created = await KM.db.createQuiz(
      { title: '代建', creatorName: '别人', questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }] },
      { skipMyCodes: true }
    );
    assert.strictEqual(KM.db.getMyCodes().length, 0, '不该写入 myCodes');
    assert.ok(await KM.db.getQuiz(created.code), '但题目本身要存在');
  });



  console.log('\n' + '─'.repeat(46));
  if (failures.length) {
    console.log('❌ ' + failures.length + ' 个失败 / ' + passed + ' 个通过\n');
    failures.forEach(function (f) {
      console.log('· ' + f.name);
      console.log('  ' + (f.err && f.err.stack ? f.err.stack.split('\n').slice(0, 3).join('\n  ') : f.err));
    });
    process.exitCode = 1;
  } else {
    console.log('✅ 全部通过：' + passed + ' 个用例');
    console.log('   本次运行 ' + new Date().toLocaleString() + '\n');
  }
})();
