/* ===========================================================
   tests/api.test.js — 服务端 REST API 端到端测试
   -----------------------------------------------------------
   真的把 server.js 起起来（json 驱动 + 临时数据文件），
   用 fetch 走一遍：建题 → 答题判分 → 排行 → 管理 → 超级后台 → 删除。
   运行：node tests/api.test.js
   =========================================================== */

'use strict';

const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');
const PORT = Number(process.env.TEST_PORT) || 8899;
const BASE = 'http://127.0.0.1:' + PORT;
const DATA_DIR = path.join(ROOT, '.testdata');
const DATA_FILE = path.join(DATA_DIR, 'api-test.json');
const SUPER_KEY = 'test-super-key-123';

let child = null;
let passed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('  ✓ ' + name);
  } catch (err) {
    failures.push({ name, err });
    console.log('  ✗ ' + name + '\n      ' + (err && err.message));
  }
}

async function req(method, pathname, body, headers) {
  const res = await fetch(BASE + pathname, {
    method: method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}),
    body: body === undefined || body === null ? undefined : JSON.stringify(body)
  });
  const text = await res.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch (e) { data = null; }
  }
  return { status: res.status, data: data };
}

const wait = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

async function waitForServer() {
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(BASE + '/api/health');
      if (res.ok) return true;
    } catch (e) { /* 还没起来 */ }
    await wait(200);
  }
  return false;
}

function stopServer() {
  if (!child) return Promise.resolve();
  const proc = child;
  child = null;
  return new Promise(function (resolve) {
    let done = false;
    const finish = function () { if (!done) { done = true; resolve(); } };
    proc.on('exit', finish);
    try { proc.kill(); } catch (e) { /* noop */ }
    setTimeout(function () {
      try { process.kill(proc.pid); } catch (e) { /* noop */ }
      finish();
    }, 2500);
  });
}

(async function run() {
  console.log('\n服务端 API 测试（json 驱动）\n');

  fs.rmSync(DATA_DIR, { recursive: true, force: true });
  fs.mkdirSync(DATA_DIR, { recursive: true });

  child = spawn(process.execPath, [path.join(ROOT, 'server.js'), '--no-open'], {
    cwd: ROOT,
    env: Object.assign({}, process.env, {
      PORT: String(PORT),
      KM_DB: 'json',
      KM_DB_FILE: DATA_FILE,
      KM_SUPER_KEY: SUPER_KEY
    }),
    stdio: 'ignore',
    windowsHide: true
  });

  const up = await waitForServer();
  if (!up) {
    console.error('✗ 服务在 25 秒内没起来（端口 ' + PORT + '）');
    await stopServer();
    process.exit(1);
  }

  const questions = [
    { q: '我最喜欢的颜色？', options: ['红', '蓝', '绿', '黄'], answer: 1 },
    { q: '我最常熬夜到几点？', options: ['11 点', '1 点', '3 点', '不睡'], answer: 2 }
  ];

  let code = '';
  let adminKey = '';

  /* ─────────── 基础 ─────────── */

  await test('GET /api/health 返回 ok + 驱动名', async () => {
    const res = await req('GET', '/api/health');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.ok, true);
    assert.strictEqual(res.data.driver, 'json');
  });

  await test('POST /api/quizzes 创建题目，返回 code + adminKey', async () => {
    const res = await req('POST', '/api/quizzes', {
      title: '接口测试题',
      creatorName: '小张',
      questions: questions
    });
    assert.strictEqual(res.status, 200, JSON.stringify(res.data));
    assert.ok(/^[A-HJ-NP-Z2-9]{4,6}$/.test(res.data.code), 'code 格式：' + res.data.code);
    assert.strictEqual(res.data.adminKey.length, 16);
    assert.ok(res.data.createdAt);
    code = res.data.code;
    adminKey = res.data.adminKey;
  });

  await test('GET /api/quizzes/:code 公开取题，且**不泄露 adminKey**', async () => {
    const res = await req('GET', '/api/quizzes/' + code);
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.title, '接口测试题');
    assert.strictEqual(res.data.creatorName, '小张');
    assert.strictEqual(res.data.questions.length, 2);
    assert.strictEqual(res.data.adminKey, undefined, '公开接口不能带 adminKey');
  });

  await test('创建参数校验：空选项 / 题数不对 → 400', async () => {
    const bad1 = await req('POST', '/api/quizzes', {
      title: 'x',
      questions: [{ q: 'q', options: ['a', '', 'c', 'd'], answer: 0 }]
    });
    assert.strictEqual(bad1.status, 400);

    const bad2 = await req('POST', '/api/quizzes', { title: 'x', questions: [] });
    assert.strictEqual(bad2.status, 400);
  });

  /* ─────────── 答题 ─────────── */

  let scoreId = '';

  await test('提交成绩：服务端按 choices 判分（全对 = 2）', async () => {
    const res = await req('POST', '/api/quizzes/' + code + '/scores', {
      nickname: '全对的人',
      choices: [1, 2],
      duration: 12
    });
    assert.strictEqual(res.status, 200, JSON.stringify(res.data));
    assert.strictEqual(res.data.score, 2);
    assert.strictEqual(res.data.total, 2);
    assert.deepStrictEqual(res.data.answers, [1, 1]);
    assert.ok(res.data.id);
    scoreId = res.data.id;
  });

  await test('提交成绩：客户端传的 score 被忽略，以服务端判分为准', async () => {
    const res = await req('POST', '/api/quizzes/' + code + '/scores', {
      nickname: '想刷分的人',
      choices: [0, 0],      // 全错
      score: 999,           // 伪造的分数
      total: 2,
      duration: 5
    });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.score, 0, '伪造的 score 不应生效');
  });

  await test('提交成绩：choices 数量不匹配 → 400', async () => {
    const res = await req('POST', '/api/quizzes/' + code + '/scores', {
      nickname: 'x', choices: [1], duration: 3
    });
    assert.strictEqual(res.status, 400);
    assert.strictEqual(res.data.error, 'BAD_CHOICES');
  });

  await test('提交成绩：不存在的题目 → 404', async () => {
    const res = await req('POST', '/api/quizzes/ZZZZ/scores', { nickname: 'x', choices: [0, 0] });
    assert.strictEqual(res.status, 404);
    assert.strictEqual(res.data.error, 'QUIZ_NOT_FOUND');
  });

  /* ─────────── 排行榜 ─────────── */

  await test('排行榜：按分数降序，且不返回 answers', async () => {
    const res = await req('GET', '/api/quizzes/' + code + '/ranking?limit=20');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.items.length, 2);
    assert.strictEqual(res.data.items[0].nickname, '全对的人');
    assert.strictEqual(res.data.items[0].score, 2);
    assert.strictEqual(res.data.items[0].answers, undefined, '排行榜不该带 answers');
    assert.strictEqual(res.data.total, 2);
  });

  /* ─────────── 管理接口 ─────────── */

  await test('管理接口：没有密钥 → 403', async () => {
    const res = await req('GET', '/api/quizzes/' + code + '/scores');
    assert.strictEqual(res.status, 403);
    assert.strictEqual(res.data.error, 'BAD_KEY');
  });

  await test('管理接口：错误密钥 → 403', async () => {
    const res = await req('GET', '/api/quizzes/' + code + '/scores', null, { 'X-Admin-Key': 'wrong-key' });
    assert.strictEqual(res.status, 403);
  });

  await test('管理接口：正确密钥 → 全部成绩（含 answers）', async () => {
    const res = await req('GET', '/api/quizzes/' + code + '/scores', null, { 'X-Admin-Key': adminKey });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.items.length, 2);
    assert.deepStrictEqual(res.data.items[0].answers, [1, 1]);
    assert.strictEqual(res.data.items[0].score, 2);
  });

  await test('管理接口：删除单条成绩', async () => {
    const del = await req('DELETE', '/api/quizzes/' + code + '/scores/' + scoreId, null, {
      'X-Admin-Key': adminKey
    });
    assert.strictEqual(del.status, 200);

    const list = await req('GET', '/api/quizzes/' + code + '/scores', null, { 'X-Admin-Key': adminKey });
    assert.strictEqual(list.data.items.length, 1, '应只剩伪造分那条');

    const bad = await req('DELETE', '/api/quizzes/' + code + '/scores/' + scoreId, null, {
      'X-Admin-Key': adminKey
    });
    assert.strictEqual(bad.status, 404, '删两次应 404');
  });

  /* ─────────── 超级后台 ─────────── */

  await test('超级登录：错口令 403，对口令 ok', async () => {
    const bad = await req('POST', '/api/admin/login', {}, { 'X-Super-Key': 'nope' });
    assert.strictEqual(bad.status, 403);

    const good = await req('POST', '/api/admin/login', {}, { 'X-Super-Key': SUPER_KEY });
    assert.strictEqual(good.status, 200);
    assert.strictEqual(good.data.ok, true);
  });

  await test('超级列表：没有超级口令 → 403', async () => {
    const res = await req('GET', '/api/admin/quizzes');
    assert.strictEqual(res.status, 403);
  });

  await test('超级列表：含 adminKey + 每套题作答人数', async () => {
    // 再建一套，验证列表排序和 counts
    const second = await req('POST', '/api/quizzes', {
      title: '第二套', creatorName: '小王',
      questions: [{ q: 'q', options: ['a', 'b', 'c', 'd'], answer: 0 }]
    });
    assert.strictEqual(second.status, 200);

    const res = await req('GET', '/api/admin/quizzes', null, { 'X-Super-Key': SUPER_KEY });
    assert.strictEqual(res.status, 200);
    assert.ok(res.data.items.length >= 2);
    const mine = res.data.items.filter(function (q) { return q.code === code; })[0];
    assert.ok(mine, '列表里应有刚才那套题');
    assert.strictEqual(mine.adminKey, adminKey, '超级列表要带 adminKey');
    assert.strictEqual(res.data.counts[code], 1, '这套题还剩 1 条成绩');
    assert.strictEqual(res.data.driver, 'json');
  });

  await test('超级删除：删掉整套题，连带成绩一起没', async () => {
    const del = await req('DELETE', '/api/admin/quizzes/' + code, null, { 'X-Super-Key': SUPER_KEY });
    assert.strictEqual(del.status, 200);

    const gone = await req('GET', '/api/quizzes/' + code);
    assert.strictEqual(gone.status, 404);

    const list = await req('GET', '/api/admin/quizzes', null, { 'X-Super-Key': SUPER_KEY });
    assert.ok(!list.data.items.some(function (q) { return q.code === code; }), '列表里不该再有它');
    assert.strictEqual(list.data.counts[code], undefined, '成绩应一起删掉');
  });

  await test('未知接口 → 404', async () => {
    const res = await req('GET', '/api/nope');
    assert.strictEqual(res.status, 404);
    assert.strictEqual(res.data.error, 'NOT_FOUND');
  });

  await test('数据真的落盘到 json 文件', async () => {
    await wait(300); // 等写入队列 flush
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    assert.ok(Array.isArray(parsed.quizzes));
    assert.ok(Array.isArray(parsed.scores));
    assert.ok(parsed.quizzes.length >= 1, '至少还有第二套题');
  });

  /* ─────────── 收尾 ─────────── */

  await stopServer();

  console.log('\n' + '─'.repeat(46));
  if (failures.length) {
    console.log('❌ ' + failures.length + ' 个失败 / ' + passed + ' 个通过\n');
    failures.forEach(function (f) {
      console.log('· ' + f.name);
      if (f.err && f.err.stack) console.log('  ' + f.err.stack.split('\n').slice(0, 4).join('\n  '));
    });
    process.exit(1);
  } else {
    console.log('✅ 全部通过：' + passed + ' 个用例\n');
    fs.rmSync(DATA_DIR, { recursive: true, force: true });
    process.exit(0);
  }
})().catch(async function (err) {
  console.error('测试崩溃：', err);
  await stopServer();
  process.exit(1);
});
