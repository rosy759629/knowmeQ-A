/* ===========================================================
   result.js — 结果页：得分动画 / 评价 / 排行榜 / 证书
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const store = KM.store;
  const h = U.h;

  let currentQuiz = null;
  let currentResult = null;

  /* ─────────── 结果头部 ─────────── */

  function renderHero(container, quiz, result, rankInfo) {
    const total = result.total || quiz.questions.length;
    const score = result.score || 0;
    const verdict = U.evaluate(score, total);
    const ratePct = total ? Math.round((score / total) * 100) : 0;

    const numEl = h('span', { class: 'num', text: '0' });

    const hero = h('div', { class: 'result-hero' },
      h('p', {
        class: 'result-kicker',
        text: '《' + quiz.title + '》' + (quiz.creatorName ? ' · ' + quiz.creatorName + ' 出的' : '')
      }),
      h('div', { class: 'result-score' },
        numEl,
        h('span', { class: 'slash', text: '/' }),
        h('span', { class: 'total', text: String(total) })
      ),
      h('p', {
        class: 'result-rate',
        text: '正确率 ' + ratePct + '% · 用时 ' + U.formatDuration(result.duration)
      }),
      h('p', { class: 'result-eval', text: verdict.emoji + ' ' + verdict.text }),
      rankInfo
    );

    container.appendChild(hero);
    setTimeout(function () { U.countUp(numEl, score, { duration: 900 }); }, 120);
  }

  function rankLine(ranking, result) {
    if (!ranking.length) return null;
    const myIndex = findMyRank(ranking, result);
    if (myIndex === -1) return null;
    const totalPeople = ranking.length;
    return h('p', {
      class: 'result-quote',
      text: '在 ' + totalPeople + ' 位答题的朋友里，排第 ' + (myIndex + 1) + ' 名。'
    });
  }

  function findMyRank(ranking, result) {
    if (!result) return -1;
    if (result.id) {
      const byId = ranking.findIndex(function (row) { return row.id && row.id === result.id; });
      if (byId !== -1) return byId;
    }
    // 优先用提交时间精确匹配（同昵称多次作答时不会认错人）
    const exact = ranking.findIndex(function (row) {
      return row.createdAt === result.createdAt && row.nickname === result.nickname;
    });
    if (exact !== -1) return exact;
    return ranking.findIndex(function (row) {
      return row.nickname === result.nickname && row.score === result.score && row.duration === result.duration;
    });
  }

  /* ─────────── 排行榜 ─────────── */

  function renderRanking(container, quiz, ranking, result) {
    const myIndex = findMyRank(ranking, result);

    const list = h('div', { class: 'rank-list' });

    if (!ranking.length) {
      list.appendChild(
        h('div', { class: 'rank-empty', text: '还没有别人作答。把链接发给朋友，看看谁最懂你。' })
      );
    } else {
      ranking.forEach(function (row, i) {
        const isMe = i === myIndex;
        list.appendChild(
          h('div', { class: 'rank-row' + (isMe ? ' is-me' : ''), style: { animationDelay: Math.min(i * 45, 400) + 'ms' } },
            h('span', { class: 'rank-no', text: String(i + 1) }),
            h('span', { class: 'rank-name', title: row.nickname },
              row.nickname,
              isMe ? h('span', { class: 'rank-me-tag', text: '你' }) : null
            ),
            h('span', { class: 'rank-score', text: row.score + '/' + row.total }),
            h('span', { class: 'rank-time', text: U.formatDuration(row.duration) })
          )
        );
      });
    }

    const shareBtn = h('button', {
      class: 'btn btn-ghost btn-sm',
      type: 'button',
      onclick: async function () {
        const ok = await U.copyText(KM.nav.quizUrl(quiz.code));
        KM.ui.toast(ok ? '链接已复制，去发给朋友吧' : '复制失败，请手动复制地址栏', ok ? 'success' : 'error');
      }
    }, '复制答题链接');

    container.appendChild(
      h('div', { class: 'card' },
        h('div', { class: 'rank-head' },
          h('h2', { class: 'card-title', text: '排行榜 · Top ' + Math.min(ranking.length || 20, 20) }),
          shareBtn
        ),
        list
      )
    );
  }

  /* ─────────── 证书 ─────────── */

  function renderCertificate(container, quiz, result) {
    const canvas = h('canvas', { width: '1200', height: '850', 'aria-label': '默契证书' });

    const downloadBtn = h('button', { class: 'btn btn-primary', type: 'button' }, '下载证书 PNG');
    const data = {
      nickname: result.nickname,
      creatorName: quiz.creatorName,
      title: quiz.title,
      score: result.score,
      total: result.total || quiz.questions.length,
      code: quiz.code,
      date: U.formatDate(result.createdAt || new Date())
    };

    downloadBtn.addEventListener('click', async function () {
      downloadBtn.disabled = true;
      const original = downloadBtn.textContent;
      downloadBtn.textContent = '生成中…';
      try {
        const name = await KM.cert.download(canvas, data);
        KM.ui.toast(name ? '已保存：' + name : '生成失败，换个浏览器试试', name ? 'success' : 'error');
      } catch (e) {
        KM.ui.toast('生成失败：' + ((e && e.message) || '未知错误'), 'error');
      } finally {
        downloadBtn.disabled = false;
        downloadBtn.textContent = original;
      }
    });

    container.appendChild(
      h('div', { class: 'card cert-card' },
        h('div', { class: 'rank-head' },
          h('h2', { class: 'card-title', text: '默契证书' }),
          h('span', { class: 'subtle', text: '右键长按也能保存' })
        ),
        h('div', { class: 'cert-wrap' }, canvas),
        h('div', { class: 'cert-actions' }, downloadBtn)
      )
    );

    KM.cert.render(canvas, data).catch(function (err) {
      console.error(err);
      KM.ui.toast('证书渲染失败', 'error');
    });
  }

  /* ─────────── 提交失败重试 ─────────── */

  function renderPending(container, quiz) {
    const pending = KM.db.getPending(quiz.code);
    if (!pending.length) return;

    container.appendChild(
      h('div', { class: 'card', style: { display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' } },
        h('div', { style: { flex: '1 1 200px' } },
          h('p', { class: 'card-title', text: '有 ' + pending.length + ' 条成绩还没提交成功' }),
          h('p', { class: 'subtle', text: '成绩已存在本地，联网后点右边重试即可。' })
        ),
        h('button', {
          class: 'btn btn-soft btn-sm',
          type: 'button',
          onclick: async function (e) {
            const btn = e.currentTarget;
            btn.disabled = true;
            btn.textContent = '提交中…';
            const res = await KM.db.flushPending();
            btn.disabled = false;
            btn.textContent = '重试提交';
            if (res.failed === 0) {
              KM.ui.toast('提交成功，共 ' + res.done + ' 条', 'success');
              setTimeout(function () { location.reload(); }, 700);
            } else {
              KM.ui.toast('还有 ' + res.failed + ' 条没成功，稍后再试', 'error');
            }
          }
        }, '重试提交')
      )
    );
  }

  /* ─────────── 空结果（没有作答记录） ─────────── */

  function renderNoResult(container, quiz, ranking) {
    container.appendChild(
      h('div', { class: 'card state-card' },
        h('span', { class: 'state-emoji', text: '🙈' }),
        h('h1', { class: 'state-title', text: '没有找到你的作答记录' }),
        h('p', { class: 'state-desc', text: '可能是换了设备或清了浏览器缓存。你可以先答一遍，成绩会立刻算出来。' }),
        h('div', { class: 'state-actions' },
          h('a', { class: 'btn btn-primary', href: '?code=' + encodeURIComponent(quiz.code) }, '去答题'),
          h('a', { class: 'btn btn-ghost', href: './' }, '我也出一套')
        )
      )
    );

    if (ranking && ranking.length) renderRanking(container, quiz, ranking, null);
  }

  /* ─────────── 入口 ─────────── */

  KM.views.result = {
    init: async function (container, options) {
      const opts = options || {};
      KM.ui.show('result');
      if (!container) return;
      KM.ui.loading(container, '正在统计成绩…');

      const validation = U.validateCode(opts.code);
      if (!validation.ok) {
        KM.ui.errorView(container, {
          emoji: '🔍',
          title: '答题码看起来不对',
          desc: validation.message,
          actions: [{ label: '回首页', kind: 'primary', href: './' }]
        });
        return;
      }

      let quiz = null;
      try {
        quiz = await KM.db.getQuiz(validation.code);
      } catch (err) {
        KM.ui.errorView(container, {
          emoji: '📡',
          title: '加载失败',
          desc: (err && err.message) || '网络好像不太顺',
          actions: [{ label: '刷新重试', kind: 'primary', onClick: function () { location.reload(); } }]
        });
        return;
      }

      if (!quiz) {
        KM.ui.errorView(container, {
          emoji: '🫥',
          title: '题目不存在或已删除',
          desc: '答题码 ' + validation.code + ' 没有对应的题目。',
          actions: [{ label: '回首页', kind: 'primary', href: './' }]
        });
        return;
      }

      currentQuiz = quiz;
      const result = store.get(U.KEYS.lastResultPrefix + quiz.code, null);
      currentResult = result;

      document.title = '成绩 · 《' + quiz.title + '》· 你是不是最懂我';
      U.clear(container);

      let ranking = [];
      try {
        ranking = await KM.db.getRanking(quiz.code, Number(window.KM_CONFIG && window.KM_CONFIG.RANKING_LIMIT) || 20);
      } catch (err) {
        KM.ui.toast('排行榜加载失败：' + ((err && err.message) || '未知错误'), 'error');
      }

      if (!result) {
        renderNoResult(container, quiz, ranking);
        return;
      }

      renderHero(container, quiz, result, rankLine(ranking, result));

      const actions = h('div', { class: 'result-actions' },
        h('a', { class: 'btn btn-ghost', href: './#create' }, '我也出一套'),
        h('button', {
          class: 'btn btn-ghost',
          type: 'button',
          onclick: async function () {
            const ok = await U.copyText(KM.nav.quizUrl(quiz.code));
            KM.ui.toast(ok ? '链接已复制' : '复制失败', ok ? 'success' : 'error');
          }
        }, '分享这套题'),
        h('button', {
          class: 'btn btn-primary',
          type: 'button',
          onclick: function () {
            store.del(U.KEYS.submittedPrefix + quiz.code);
            KM.nav.quiz(quiz.code);
          }
        }, '再答一次')
      );
      container.appendChild(actions);

      renderPending(container, quiz);
      renderRanking(container, quiz, ranking, result);
      renderCertificate(container, quiz, result);

      const total = result.total || quiz.questions.length;
      if (total > 0 && result.score === total) {
        setTimeout(function () { KM.fx.confettiRain(); }, 400);
      }
    }
  };
})();
