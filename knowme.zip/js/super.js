/* ===========================================================
   super.js — 超级管理员后台（?super）
   -----------------------------------------------------------
   能看「全部题目」，能代建，能删除。
   数据范围取决于 STORAGE_MODE：
     local → 只有这台浏览器里的题目（物理上拿不到别人的）
     cloud → Supabase 里所有题目，删除走 RPC（数据库校验口令哈希）
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const h = U.h;

  const SESSION_KEY = 'km.super.ok';
  const DEFAULT_KEY = 'CHANGE-ME-SUPER';

  const state = {
    quizzes: [],
    counts: {},
    query: '',
    createOpen: false
  };

  function cfg() {
    return window.KM_CONFIG || {};
  }

  function superKey() {
    return String(cfg().SUPER_KEY || '');
  }

  /* ─────────── 登录态（sessionStorage：关浏览器即失效） ─────────── */

  function sessionMinutes() {
    const m = Number(cfg().SESSION_MINUTES);
    return isNaN(m) || m <= 0 ? 120 : m;
  }

  function isAuthed() {
    try {
      const raw = window.sessionStorage.getItem(SESSION_KEY);
      if (!raw) return false;
      let at = 0;
      try { at = Number(JSON.parse(raw).at) || 0; } catch (e) { at = 0; }
      if (!at || Date.now() - at > sessionMinutes() * 60000) {
        window.sessionStorage.removeItem(SESSION_KEY);
        return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  function setAuthed(value) {
    try {
      if (value) window.sessionStorage.setItem(SESSION_KEY, JSON.stringify({ at: Date.now() }));
      else window.sessionStorage.removeItem(SESSION_KEY);
    } catch (e) { /* 隐私模式下退化成每次都要输 */ }
  }

  /* ─────────── 口令门 ─────────── */

  function renderGate(container) {
    U.clear(container);

    if (!superKey()) {
      container.appendChild(
        h('div', { class: 'card state-card' },
          h('span', { class: 'state-emoji', text: '🔒' }),
          h('h1', { class: 'state-title', text: '超级后台未启用' }),
          h('p', { class: 'state-desc', text: '打开 js/config.js，把 SUPER_KEY 设成一个你自己记得住的口令，再回到这个页面。' }),
          h('div', { class: 'state-actions' }, h('a', { class: 'btn btn-primary', href: KM.basePath || './' }, '回首页'))
        )
      );
      return;
    }

    const input = h('input', {
      class: 'input',
      type: 'password',
      maxlength: '64',
      placeholder: '输入超级管理员口令',
      autocomplete: 'off',
      'aria-label': '超级管理员口令'
    });
    const errorEl = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const btn = h('button', { class: 'btn btn-primary btn-block', type: 'button' }, '进入超级后台');

    function submit() {
      const value = input.value.trim();
      if (!value) {
        errorEl.hidden = false;
        errorEl.textContent = '请输入口令';
        input.focus();
        return;
      }
      btn.disabled = true;
      KM.db.verifySuper(value).then(function (ok) {
        if (!ok) {
          btn.disabled = false;
          errorEl.hidden = false;
          errorEl.textContent = '口令不对';
          input.classList.add('is-invalid');
          input.select();
          return;
        }
        setAuthed(true);
        reload(container);
      }).catch(function (err) {
        btn.disabled = false;
        errorEl.hidden = false;
        errorEl.textContent = (err && err.message) || '校验失败，请重试';
      });
    }

    btn.addEventListener('click', submit);
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        submit();
      }
    });
    input.addEventListener('input', function () {
      input.classList.remove('is-invalid');
      errorEl.hidden = true;
    });

    const hint = KM.db.isApi()
      ? '口令是服务器上 backend/config.js 里的 SUPER_KEY（或环境变量 KM_SUPER_KEY）。前端文件里没有它。'
      : superKey() === DEFAULT_KEY
        ? '现在是默认口令 CHANGE-ME-SUPER —— 改 js/config.js 的 SUPER_KEY 换个自己的。'
        : '口令就是 js/config.js 里 SUPER_KEY 的值。';

    container.appendChild(
      h('div', { class: 'card key-gate' },
        h('span', { class: 'state-emoji', text: '🛡️' }),
        h('h1', { class: 'state-title', text: '超级管理员' }),
        h('p', { class: 'state-desc', text: '这里能看到所有题目，也能删除它们。请确认你确实是管理员。' }),
        input,
        errorEl,
        h('div', { style: { marginTop: '16px' } }, btn),
        h('p', { class: 'form-hint', style: { marginTop: '14px' }, text: hint }),
        h('p', { style: { marginTop: '10px' } }, h('a', { href: KM.basePath || './' }, '← 回首页'))
      )
    );

    setTimeout(function () { input.focus(); }, 80);
  }

  /* ─────────── 数据 ─────────── */

  async function reload(container) {
    KM.ui.loading(container, '正在读取全部题目…');
    try {
      const results = await Promise.all([KM.db.listAllQuizzes(), KM.db.getScoreCounts()]);
      state.quizzes = results[0] || [];
      state.counts = results[1] || {};
      paint(container);
    } catch (err) {
      KM.ui.errorView(container, {
        emoji: '📡',
        title: '读取失败',
        desc: (err && err.message) || '网络或数据库出了点问题',
        actions: [
          { label: '重试', kind: 'primary', onClick: function () { reload(container); } },
          { label: '回首页', kind: 'ghost', href: KM.basePath || './' }
        ]
      });
    }
  }

  function totalAnswers() {
    return Object.keys(state.counts).reduce(function (sum, code) {
      return sum + (Number(state.counts[code]) || 0);
    }, 0);
  }

  function todayCount() {
    const today = new Date().toDateString();
    return state.quizzes.filter(function (quiz) {
      const d = quiz.createdAt ? new Date(quiz.createdAt) : null;
      return d && !isNaN(d.getTime()) && d.toDateString() === today;
    }).length;
  }

  /* ─────────── 顶部信息 ─────────── */

  function headerCard() {
    const banners = [];

    if (!KM.db.isApi() && superKey() === DEFAULT_KEY) {
      banners.push(
        h('p', { class: 'super-bar is-danger' },
          '⚠️ 正在使用默认超级口令 CHANGE-ME-SUPER。上线前务必改掉 js/config.js 的 SUPER_KEY，' +
          '并在 Supabase 里重跑 schema.sql 末尾的 update 语句同步哈希。'
        )
      );
    }

    if (KM.db.isApi()) {
      banners.push(
        h('p', { class: 'super-bar is-ok' },
          '🗄️ 服务器数据库模式：下面是数据库里全部人的题目，删除会真的删掉（成绩一起）。' +
          '口令由服务端校验（backend/config.js 的 SUPER_KEY），前端文件里没有它。'
        )
      );
    } else if (KM.db.isCloud()) {
      banners.push(
        h('p', { class: 'super-bar is-ok' },
          '☁️ 云端模式：下面是数据库里全部人的题目。删除会真的删掉（成绩一起），不能撤销。'
        )
      );
    } else {
      banners.push(
        h('p', { class: 'super-bar is-warn' },
          '💾 本地模式：只能看到这台设备、这个浏览器里的题目。别人的题目存在他们自己的浏览器里，' +
          '前端拿不到。想真正"看所有人的题目"，请把 js/config.js 的 STORAGE_MODE 改成 api' +
          '（用你自己服务器上的数据库，见 README 第 11 节）。'
        )
      );
    }

    return h('div', { class: 'card super-head' },
      h('div', { class: 'super-head-main' },
        h('p', { class: 'admin-kicker', text: '超级管理员 · SUPER ADMIN' }),
        h('h1', { class: 'admin-title', text: '全部题目' }),
        h('p', { class: 'admin-meta', text: '可以查看题面、代建题目、删除整套题目（含成绩）。' }),
        banners
      ),
      h('div', { class: 'admin-stats' },
        h('div', { class: 'stat' }, h('b', { text: String(state.quizzes.length) }), h('span', { text: '题目总数' })),
        h('div', { class: 'stat' }, h('b', { text: String(totalAnswers()) }), h('span', { text: '作答总数' })),
        h('div', { class: 'stat' }, h('b', { text: String(todayCount()) }), h('span', { text: '今日新增' }))
      )
    );
  }

  /* ─────────── 表格 ─────────── */

  function renderRows(tbody, countText) {
    const keyword = state.query.toLowerCase();
    const list = state.quizzes.filter(function (quiz) {
      if (!keyword) return true;
      const hay = (quiz.code + ' ' + quiz.title + ' ' + (quiz.creatorName || '')).toLowerCase();
      return hay.indexOf(keyword) !== -1;
    });

    U.clear(tbody);
    if (countText) {
      countText.textContent = keyword
        ? '筛出 ' + list.length + ' / ' + state.quizzes.length + ' 套'
        : state.quizzes.length + ' 套 · 共 ' + totalAnswers() + ' 条作答';
    }

    if (!list.length) {
      tbody.appendChild(
        h('tr', {},
          h('td', { colspan: '7', style: { textAlign: 'center', padding: '30px 10px', color: 'var(--muted)' } },
            state.quizzes.length ? '没有匹配的题目，换个关键词试试' : '这里还没有任何题目。可以点「+ 新建题目」代建一套。')
        )
      );
      return;
    }

    list.forEach(function (quiz) {
      const answers = state.counts[quiz.code] || 0;
      tbody.appendChild(
        h('tr', {},
          h('td', {}, h('code', { class: 'super-code', text: quiz.code })),
          h('td', { class: 'col-name', title: quiz.title, text: quiz.title }),
          h('td', { class: 'col-num', text: quiz.creatorName || '—' }),
          h('td', { class: 'col-num', text: String((quiz.questions || []).length) }),
          h('td', { class: 'col-num', text: String(answers) }),
          h('td', { class: 'col-num', text: U.formatDateTime(quiz.createdAt) }),
          h('td', { class: 'col-act' },
            h('div', { class: 'super-actions' },
              h('button', {
                class: 'btn btn-ghost btn-sm',
                type: 'button',
                onclick: function () { showDetail(quiz); }
              }, '详情'),
              h('a', {
                class: 'btn btn-ghost btn-sm',
                href: KM.nav.adminUrl(quiz.code, quiz.adminKey || '')
              }, '管理'),
              h('button', {
                class: 'btn btn-danger btn-sm',
                type: 'button',
                onclick: function () { confirmDelete(quiz); }
              }, '删除')
            )
          )
        )
      );
    });
  }

  function tableCard() {
    const tbody = h('tbody', {});
    const countText = h('span', { class: 'subtle' });

    const card = h('div', { class: 'card' },
      h('div', { class: 'rank-head' },
        h('h2', { class: 'card-title', text: '题目列表' }),
        countText
      ),
      h('div', { class: 'table-scroll' },
        h('table', { class: 'table' },
          h('thead', {},
            h('tr', {},
              h('th', { text: '答题码' }),
              h('th', { text: '标题' }),
              h('th', { text: '出题人' }),
              h('th', { text: '题数' }),
              h('th', { text: '作答' }),
              h('th', { text: '创建时间' }),
              h('th', { class: 'col-act', text: '操作' })
            )
          ),
          tbody
        )
      )
    );

    renderRows(tbody, countText);
    return card;
  }

  /* ─────────── 详情弹窗 ─────────── */

  function copyRow(label, value) {
    const input = h('input', { class: 'input', type: 'text', value: value, readonly: true });
    const btn = h('button', { class: 'btn btn-soft btn-sm', type: 'button' }, '复制');
    btn.addEventListener('click', async function () {
      const ok = await U.copyText(value);
      KM.ui.toast(ok ? '已复制' : '复制失败，请手动选择', ok ? 'success' : 'error');
    });
    input.addEventListener('focus', function () { input.select(); });
    return h('div', {},
      h('p', { class: 'copy-label', text: label }),
      h('div', { class: 'copy-row' }, input, btn)
    );
  }

  function showDetail(quiz) {
    const questions = quiz.questions || [];
    const answers = state.counts[quiz.code] || 0;

    const list = h('div', { class: 'detail-list' });
    questions.forEach(function (item, i) {
      const answerIndex = Number(item.answer) || 0;
      list.appendChild(
        h('div', { class: 'detail-q' },
          h('p', { class: 'detail-qtext' },
            h('b', { text: 'Q' + (i + 1) }),
            item.q
          ),
          h('ul', { class: 'detail-opts' },
            (item.options || []).map(function (opt, j) {
              return h('li', { class: 'detail-opt' + (j === answerIndex ? ' is-answer' : '') },
                h('span', { class: 'detail-key', text: 'ABCD'[j] }),
                h('span', { class: 'detail-opt-text', text: opt }),
                j === answerIndex ? h('span', { class: 'detail-right', text: '✓ 正确答案' }) : null
              );
            })
          )
        )
      );
    });

    const body = h('div', {},
      h('div', { class: 'detail-meta' },
        h('span', { class: 'super-code', text: quiz.code }),
        h('span', { text: (quiz.creatorName || '匿名') + ' 出题' }),
        h('span', { text: questions.length + ' 道题' }),
        h('span', { text: answers + ' 人作答' }),
        h('span', { text: U.formatDateTime(quiz.createdAt) })
      ),
      copyRow('答题链接', KM.nav.quizUrl(quiz.code)),
      quiz.adminKey ? copyRow('管理链接（含密钥）', KM.nav.adminUrl(quiz.code, quiz.adminKey)) : null,
      h('p', { class: 'copy-label', text: '题面（含正确答案）' }),
      questions.length ? list : h('p', { class: 'subtle', text: '这套题里没有题目' })
    );

    KM.ui.modal({
      title: '《' + quiz.title + '》',
      desc: '超级管理员视图：能直接看到正确答案。',
      body: body,
      actions: [
        { label: '删除这套题', kind: 'danger', onClick: function (close) { close(); confirmDelete(quiz); } },
        { label: '关闭', kind: 'ghost' }
      ]
    });
  }

  /* ─────────── 删除 ─────────── */

  function confirmDelete(quiz) {
    const answers = state.counts[quiz.code] || 0;
    KM.ui.confirm({
      title: '删除《' + quiz.title + '》？',
      desc: '答题码 ' + quiz.code + '，' + answers + ' 条成绩会一起删掉，不能撤销。' +
        (KM.db.isCloud() ? ' 这会真的从数据库删除。' : ''),
      confirmText: '永久删除',
      danger: true,
      onConfirm: async function () {
        KM.ui.toast('正在删除…');
        try {
          await KM.db.deleteQuiz(quiz.code);
          KM.ui.toast('已删除 ' + quiz.code, 'success');
          const container = document.getElementById('view-super');
          await reload(container);
        } catch (err) {
          KM.ui.toast((err && err.message) || '删除失败', 'error');
        }
      }
    });
  }

  /* ─────────── 代建题目 ─────────── */

  function createPanel(container) {
    const form = KM.editor.buildForm({
      defaultTitle: '你是不是最懂我',
      defaultCreator: '',
      creatorLabel: '出题人昵称（代谁建就写谁）',
      creatorPlaceholder: '比如：小明',
      submitText: '创建题目',
      busyText: '创建中…',
      compact: true,
      hint: '最多 ' + KM.editor.maxQuestions() + ' 道题 · 创建后不会出现在你自己的「我的题目」里',
      onSubmit: async function (values) {
        const result = await KM.db.createQuiz(values, { skipMyCodes: true });
        state.createOpen = false;
        KM.ui.toast('已创建，答题码 ' + result.code, 'success');
        await reload(container);
        const created = state.quizzes.filter(function (q) { return q.code === result.code; })[0];
        if (created) {
          created.adminKey = created.adminKey || result.adminKey;
          showDetail(created);
        }
      }
    });

    return h('div', { class: 'card super-create' },
      h('div', { class: 'rank-head' },
        h('h2', { class: 'card-title', text: '代建一套题' }),
        h('button', {
          class: 'btn btn-ghost btn-sm',
          type: 'button',
          onclick: function () { state.createOpen = false; paint(container); }
        }, '收起')
      ),
      form.el
    );
  }

  /* ─────────── 主绘制 ─────────── */

  function paint(container) {
    U.clear(container);
    container.appendChild(headerCard());

    /* 工具条 */
    const searchInput = h('input', {
      class: 'input super-search',
      type: 'search',
      placeholder: '搜答题码 / 标题 / 出题人',
      value: state.query,
      'aria-label': '搜索题目'
    });

    const card = tableCard();
    const tbody = card.querySelector('tbody');
    const countText = card.querySelector('.rank-head .subtle');

    searchInput.addEventListener('input', function () {
      state.query = searchInput.value.trim();
      renderRows(tbody, countText);
    });

    container.appendChild(
      h('div', { class: 'super-toolbar' },
        h('div', { class: 'super-search-wrap' }, h('span', { class: 'super-search-icon', text: '🔍', 'aria-hidden': 'true' }), searchInput),
        h('div', { class: 'super-toolbar-actions' },
          h('button', {
            class: 'btn btn-soft btn-sm',
            type: 'button',
            onclick: function () { reload(container); }
          }, '刷新'),
          h('button', {
            class: 'btn btn-primary btn-sm',
            type: 'button',
            onclick: function () {
              state.createOpen = !state.createOpen;
              paint(container);
            }
          }, state.createOpen ? '收起新建' : '+ 新建题目'),
          h('button', {
            class: 'btn btn-ghost btn-sm',
            type: 'button',
            onclick: function () {
              setAuthed(false);
              if (KM.db.forgetSuperKey) KM.db.forgetSuperKey();
              KM.ui.toast('已退出超级后台');
              renderGate(container);
            }
          }, '退出'),
          h('a', { class: 'btn btn-ghost btn-sm', href: KM.basePath || './' }, '回首页')
        )
      )
    );

    if (state.createOpen) container.appendChild(createPanel(container));

    container.appendChild(card);
  }

  /* ─────────── 入口 ─────────── */

  KM.views.super = {
    init: function (container) {
      KM.ui.show('super');
      if (!container) return;
      if (isAuthed()) reload(container);
      else renderGate(container);
    }
  };
})();

