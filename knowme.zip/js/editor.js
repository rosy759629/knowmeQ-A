/* ===========================================================
   editor.js — 题目编辑器（首页出题 / 超级后台代建 共用）
   -----------------------------------------------------------
   KM.editor.buildForm() 负责：动态增删题、4 选项、答案单选、
   校验、提交中状态、错误定位。业务回调交给调用方。
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const h = U.h;

  let seq = 0;

  function cfg() {
    return window.KM_CONFIG || {};
  }

  function maxQuestions() {
    return Math.max(1, Number(cfg().MAX_QUESTIONS) || 10);
  }

  /* ─────────── 单题卡片 ─────────── */

  function questionCard(index) {
    seq += 1;
    const uid = 'q' + seq;

    const optionRows = [];
    for (let i = 0; i < 4; i++) {
      const letter = 'ABCD'[i];
      optionRows.push(
        h('div', { class: 'opt-row' },
          h('span', { class: 'opt-badge', text: letter }),
          h('input', {
            class: 'input opt-input',
            type: 'text',
            maxlength: '60',
            placeholder: '选项 ' + letter,
            'aria-label': '第 ' + index + ' 题选项 ' + letter
          })
        )
      );
    }

    const chips = [];
    for (let i = 0; i < 4; i++) {
      const letter = 'ABCD'[i];
      chips.push(
        h('label', { class: 'ans-chip', title: '把 ' + letter + ' 设为正确答案' },
          h('input', {
            type: 'radio',
            name: 'ans-' + uid,
            value: String(i),
            checked: i === 0,
            'aria-label': '正确答案 ' + letter
          }),
          h('span', { text: letter })
        )
      );
    }

    const card = h('div', { class: 'q-editor', dataset: { uid: uid } },
      h('div', { class: 'q-editor-head' },
        h('span', { class: 'q-no', text: '第 ' + index + ' 题' }),
        h('button', {
          class: 'icon-btn',
          type: 'button',
          title: '删除这道题',
          'aria-label': '删除第 ' + index + ' 题',
          onclick: function () {
            const list = card.parentNode;
            if (!list) return;
            if (list.querySelectorAll('.q-editor').length <= 1) {
              KM.ui.toast('至少要留一道题', 'error');
              return;
            }
            card.remove();
            renumber(list);
          }
        }, '✕')
      ),
      h('input', {
        class: 'input q-text',
        type: 'text',
        maxlength: '120',
        placeholder: '题干，例如：我最喜欢的颜色是？',
        'aria-label': '第 ' + index + ' 题的题干'
      }),
      h('div', { class: 'opt-rows' }, optionRows),
      h('div', { class: 'ans-row' },
        h('span', { class: 'ans-label', text: '正确答案' }),
        h('div', { class: 'ans-chips' }, chips)
      )
    );

    // 输入即消除错误态
    card.addEventListener('input', function (e) {
      if (e.target.classList.contains('input')) e.target.classList.remove('is-invalid');
    });

    return card;
  }

  function renumber(list) {
    list.querySelectorAll('.q-editor').forEach(function (card, i) {
      const no = card.querySelector('.q-no');
      if (no) no.textContent = '第 ' + (i + 1) + ' 题';
    });
  }

  function readQuestion(card) {
    const qText = card.querySelector('.q-text');
    const optInputs = Array.prototype.slice.call(card.querySelectorAll('.opt-input'));
    const checked = card.querySelector('input[type="radio"]:checked');
    return {
      q: qText.value.trim(),
      qInput: qText,
      options: optInputs.map(function (input) { return input.value.trim(); }),
      optInputs: optInputs,
      answer: checked ? Number(checked.value) : 0
    };
  }

  /* ─────────── 校验 ─────────── */

  function validationError(message, input) {
    const err = new Error(message);
    err.isValidation = true;
    err.input = input || null;
    return err;
  }

  function collect(list) {
    const cards = Array.prototype.slice.call(list.querySelectorAll('.q-editor'));
    if (!cards.length) throw validationError('至少要有一道题');

    const problems = [];
    const questions = [];

    cards.forEach(function (card, index) {
      const data = readQuestion(card);
      const no = index + 1;
      if (!data.q) problems.push({ message: '第 ' + no + ' 题的题干还是空的', input: data.qInput });
      data.optInputs.forEach(function (input, i) {
        if (!input.value.trim()) {
          problems.push({ message: '第 ' + no + ' 题的选项 ' + 'ABCD'[i] + ' 还没填', input: input });
        }
      });
      questions.push({ q: data.q, options: data.options, answer: data.answer });
    });

    if (problems.length) throw validationError(problems[0].message, problems[0].input);

    for (let i = 0; i < questions.length; i++) {
      const opts = questions[i].options.filter(Boolean);
      if (new Set(opts).size < opts.length) {
        throw validationError('第 ' + (i + 1) + ' 题有两个选项一模一样，要不要改一下？');
      }
    }

    return questions;
  }

  /* ─────────── 整套表单 ─────────── */

  /**
   * @param {object} options
   *   defaultTitle / defaultCreator / submitText / hint / compact
   *   titleLabel / creatorLabel / creatorPlaceholder
   *   onSubmit(values)  → Promise（values = {title, creatorName, questions}）
   * @returns {{el, reset, showError, setBusy, list}}
   */
  function buildForm(options) {
    const o = options || {};
    const max = maxQuestions();
    const fid = 'ed' + (++seq);

    const titleInput = h('input', {
      class: 'input',
      type: 'text',
      maxlength: '60',
      id: fid + '-title',
      value: o.defaultTitle === undefined ? '你是不是最懂我' : o.defaultTitle,
      placeholder: '例如：你是不是最懂我'
    });

    const nameInput = h('input', {
      class: 'input',
      type: 'text',
      maxlength: '24',
      id: fid + '-name',
      value: o.defaultCreator || '',
      placeholder: o.creatorPlaceholder || '出题人昵称，会显示在答题页上'
    });

    const list = h('div', { class: 'q-list' });
    const errorBox = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const addBtn = h('button', { class: 'btn btn-soft btn-sm', type: 'button' }, '+ 添加一道题');
    const submitBtn = h('button', { class: 'btn btn-primary', type: 'submit' }, o.submitText || '生成题目');

    function addQuestion() {
      const count = list.querySelectorAll('.q-editor').length;
      if (count >= max) {
        KM.ui.toast('最多 ' + max + ' 道题', 'error');
        return null;
      }
      const card = questionCard(count + 1);
      list.appendChild(card);
      const input = card.querySelector('.q-text');
      if (input) input.focus();
      return card;
    }

    function showError(message, target) {
      if (!message) {
        errorBox.hidden = true;
        errorBox.textContent = '';
        return;
      }
      errorBox.hidden = false;
      errorBox.textContent = message;
      if (target) {
        target.classList.add('is-invalid');
        if (target.focus) target.focus({ preventScroll: false });
        if (target.scrollIntoView) target.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    }

    function reset() {
      U.clear(list);
      list.appendChild(questionCard(1));
      renumber(list);
    }

    function setBusy(busy) {
      submitBtn.disabled = !!busy;
      addBtn.disabled = !!busy;
      submitBtn.textContent = busy ? (o.busyText || '处理中…') : (o.submitText || '生成题目');
    }

    addBtn.addEventListener('click', addQuestion);

    const form = h('form', { class: 'create-form' + (o.compact ? ' is-compact' : ''), novalidate: true },
      h('div', { class: 'field' },
        h('label', { for: fid + '-title', text: o.titleLabel || '题目名称' }),
        titleInput
      ),
      h('div', { class: 'field' },
        h('label', { for: fid + '-name', text: o.creatorLabel || '出题人昵称（选填）' }),
        nameInput
      ),
      h('div', { class: 'field' },
        h('label', { text: '题目（每题 4 个选项，选一个正确答案）' }),
        list
      ),
      errorBox,
      h('div', { class: 'create-actions' },
        h('div', { class: 'hint', text: o.hint || ('最多 ' + max + ' 道题 · 选项必填 · 答案单选') }),
        h('div', { class: 'right' }, addBtn, submitBtn)
      )
    );

    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      showError('');

      let questions;
      try {
        questions = collect(list);
      } catch (err) {
        showError(err.message, err.input);
        return;
      }

      const values = {
        title: titleInput.value.trim() || '你是不是最懂我',
        creatorName: nameInput.value.trim(),
        questions: questions
      };

      setBusy(true);
      try {
        await o.onSubmit(values);
        reset();
      } catch (err) {
        showError((err && err.message) || '提交失败，请重试', err && err.input);
      } finally {
        setBusy(false);
      }
    });

    reset();

    return {
      el: form,
      reset: reset,
      showError: showError,
      setBusy: setBusy,
      list: list,
      titleInput: titleInput,
      nameInput: nameInput
    };
  }

  KM.editor = {
    questionCard: questionCard,
    renumber: renumber,
    readQuestion: readQuestion,
    collect: collect,
    buildForm: buildForm,
    maxQuestions: maxQuestions
  };
})();
