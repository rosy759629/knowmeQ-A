/* ===========================================================
   router.js — 路由（后台走目录，其他走 query string）
   -----------------------------------------------------------
   <站点>/                       首页
   <站点>/?code=XXXX             答题页
   <站点>/?code=XXXX&result      结果页
   <站点>/?code=XXXX&admin&key=.. 单题管理页
   <ADMIN_PATH>                  超级管理后台（默认 /manage，见 js/config.admin.js）
   <站点>/?super                 后台的兼容入口（同一口令）
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;

  KM.views = KM.views || {};

  function cfg() {
    return window.KM_CONFIG || {};
  }

  function trimSlash(p) {
    return String(p || '').replace(/\/+$/, '');
  }

  function withTrailingSlash(p) {
    if (!p) return '/';
    return p.charAt(p.length - 1) === '/' ? p : p + '/';
  }

  function normalizeAdminPath(value) {
    let p = String(value || '').trim();
    if (!p) return '';
    if (p.charAt(0) !== '/') p = '/' + p;
    return trimSlash(p);
  }

  const ADMIN_PATH = normalizeAdminPath(cfg().ADMIN_PATH);
  const PAGE_PATH = decodeURIComponent(window.location.pathname || '/');
  const IS_ADMIN_PAGE = !!ADMIN_PATH && trimSlash(PAGE_PATH) === ADMIN_PATH;

  /**
   * 站点根路径（一定以 / 结尾）
   * 后台在 /manage 时，站内跳转必须回到 /，否则会被路由成后台页。
   */
  const BASE_PATH = (function () {
    if (IS_ADMIN_PAGE) {
      const parent = trimSlash(PAGE_PATH).slice(0, trimSlash(PAGE_PATH).length - ADMIN_PATH.length);
      return parent ? withTrailingSlash(parent) : '/';
    }
    try {
      // 用本脚本自己的地址推断，file:// 和子目录部署都准
      const self = document.currentScript || Array.prototype.slice.call(document.scripts)
        .filter(function (s) { return /js\/router\.js(\?|$)/.test(s.src || ''); })[0];
      if (self && self.src) {
        const p = new URL(self.src, window.location.href).pathname;
        const idx = p.indexOf('js/router.js');
        if (idx !== -1) return p.slice(0, idx) || '/';
      }
    } catch (e) { /* 推断失败就退回根目录 */ }
    return '/';
  })();

  function withSearch(search) {
    const url = new URL(window.location.href);
    url.pathname = BASE_PATH;
    url.search = search || '';
    url.hash = '';
    return url.href;
  }

  function go(search) {
    window.location.href = withSearch(search);
  }

  function quizSearch(code) {
    return '?code=' + encodeURIComponent(code);
  }

  const nav = {
    home: function () {
      go('');
    },
    quiz: function (code) {
      go(quizSearch(code));
    },
    result: function (code) {
      go(quizSearch(code) + '&result');
    },
    admin: function (code, key) {
      go(quizSearch(code) + '&admin' + (key ? '&key=' + encodeURIComponent(key) : ''));
    },
    quizUrl: function (code) {
      return withSearch(quizSearch(code));
    },
    adminUrl: function (code, key) {
      return withSearch(quizSearch(code) + '&admin' + (key ? '&key=' + encodeURIComponent(key) : ''));
    },
    adminPage: function () {
      return ADMIN_PATH || withSearch('?super');
    }
  };

  function el(name) {
    const node = document.getElementById('view-' + name);
    if (!node) throw new Error('找不到视图容器：#view-' + name);
    return node;
  }

  /* 页脚的后台入口，受 SHOW_FOOTER_LINK 控制 */
  function renderFooterLink() {
    const box = document.getElementById('footer-admin');
    if (!box) return;
    const conf = cfg();
    if (!conf.SHOW_FOOTER_LINK || !ADMIN_PATH) {
      box.hidden = true;
      return;
    }
    box.hidden = false;
    U.clear(box);
    box.appendChild(U.h('a', { href: ADMIN_PATH, title: '管理后台' }, '管理后台'));
  }

  function start() {
    KM.ui.initChrome();
    renderFooterLink();

    const params = new URLSearchParams(window.location.search);
    const code = U.normalizeCode(params.get('code') || '');

    try {
      // 后台：目录入口优先，?super 作为兼容入口
      if (IS_ADMIN_PAGE || params.has('super')) {
        KM.views.super.init(el('super'));
        return;
      }
      if (params.has('admin')) {
        KM.views.admin.init(el('admin'), { code: code, key: params.get('key') || '' });
        return;
      }
      if (params.has('result')) {
        KM.views.result.init(el('result'), { code: code });
        return;
      }
      if (code) {
        KM.views.quiz.init(el('quiz'), { code: code });
        return;
      }
      KM.views.home.init(el('home'));
    } catch (err) {
      console.error(err);
      KM.ui.show('home');
      KM.ui.errorView(el('home'), {
        emoji: '🛠️',
        title: '页面出错了',
        desc: (err && err.message) || '未知错误，请刷新重试',
        actions: [{ label: '刷新页面', kind: 'primary', onClick: function () { window.location.reload(); } }]
      });
    }
  }

  KM.nav = nav;
  KM.basePath = BASE_PATH;
  KM.adminPath = ADMIN_PATH;
  KM.isAdminPage = IS_ADMIN_PAGE;
  KM.router = { start: start, el: el, go: go, basePath: BASE_PATH };
})();
