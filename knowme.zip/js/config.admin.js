/* ===========================================================
   config.admin.js — 后台入口配置（部署相关，单独一个文件）
   -----------------------------------------------------------
   放到服务器上以后，通常只需要改这一个文件：
   把 ADMIN_PATH 改成别人猜不到的路径，重启服务即可。
   =========================================================== */

window.KM_ADMIN_CONFIG = {
  /* 管理后台的入口路径（站内绝对路径）
     - 一层：'/manage'、'/boss-9x2k'
     - 带子目录（站点不在根目录时）：'/quiz/manage'
     - 结尾不要带斜杠；带不带都能访问，但配置里别写
     ⚠️ 路径只是"不好猜"，真正的防线是 SUPER_KEY 口令 */
  ADMIN_PATH: '/manage',

  /* 首页页脚要不要显示「管理后台」入口
     上线后建议改成 false：自己记住路径就行，别在页面上挂招牌 */
  SHOW_FOOTER_LINK: true,

  /* 后台登录态多久失效（分钟），默认 120 分钟。关掉浏览器也会失效 */
  SESSION_MINUTES: 120
};

/* 合并进主配置，后面所有代码统一读 KM_CONFIG.* */
(function () {
  'use strict';
  const cfg = window.KM_CONFIG || (window.KM_CONFIG = {});
  Object.assign(cfg, window.KM_ADMIN_CONFIG);
})();
