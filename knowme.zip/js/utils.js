/* ===========================================================
   utils.js — 通用工具：随机码、存储、时间、DOM、弹窗、音效、特效
   =========================================================== */

(function () {
  'use strict';

  const KM = (window.KM = window.KM || {});
  const CFG = window.KM_CONFIG || {};

  /* ─────────── 常量 ─────────── */

  // 去掉易混淆的 I / O / 0 / 1
  const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const CODE_RE = /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{4,6}$/;

  const KEYS = {
    nickname: 'km.nickname',
    creator: 'km.creator',
    muted: 'km.muted',
    myCodes: 'km.myCodes',
    lastCode: 'km.lastCode',
    quizPrefix: 'km.quiz.',
    scoresPrefix: 'km.scores.',
    lastResultPrefix: 'km.lastResult.',
    submittedPrefix: 'km.submitted.',
    pending: 'km.pending'
  };

  /* ─────────── 随机码 ─────────── */

  function randomBytes(n) {
    const arr = new Uint32Array(n);
    const c = window.crypto || window.msCrypto;
    if (c && c.getRandomValues) {
      c.getRandomValues(arr);
    } else {
      for (let i = 0; i < n; i++) arr[i] = Math.floor(Math.random() * 4294967296);
    }
    return arr;
  }

  function randomCode(len) {
    const n = Math.max(4, Math.min(6, len || CFG.CODE_LENGTH || 4));
    const bytes = randomBytes(n);
    let out = '';
    // 2^32 能被字符集长度 32 整除，取模不产生偏差
    for (let i = 0; i < n; i++) {
      out += CODE_CHARS[bytes[i] % CODE_CHARS.length];
    }
    return out;
  }

  function randomKey() {
    try {
      if (window.crypto && window.crypto.randomUUID) {
        return window.crypto.randomUUID().replace(/-/g, '').slice(0, 16);
      }
    } catch (e) { /* 忽略，走下面的兜底 */ }
    let out = '';
    const bytes = randomBytes(16);
    for (let i = 0; i < 16; i++) out += CODE_CHARS[bytes[i] % CODE_CHARS.length].toLowerCase();
    return out;
  }

  // 简易 hash，用于证书编号
  function shortHash(str) {
    let hash = 5381;
    const s = String(str);
    for (let i = 0; i < s.length; i++) {
      hash = ((hash << 5) + hash + s.charCodeAt(i)) >>> 0;
    }
    return hash.toString(36).toUpperCase().padStart(6, '0').slice(-6);
  }

  /* ─────────── localStorage 封装 ─────────── */

  const store = {
    get(key, fallback) {
      try {
        const raw = window.localStorage.getItem(key);
        if (raw === null || raw === undefined) return fallback;
        return JSON.parse(raw);
      } catch (e) {
        return fallback;
      }
    },
    set(key, value) {
      try {
        window.localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (e) {
        // 隐私模式 / 配额满
        return false;
      }
    },
    del(key) {
      try { window.localStorage.removeItem(key); } catch (e) { /* noop */ }
    },
    has(key) {
      try { return window.localStorage.getItem(key) !== null; } catch (e) { return false; }
    }
  };

  /* ─────────── 格式化 ─────────── */

  function pad(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function formatDuration(sec) {
    if (sec === null || sec === undefined || isNaN(sec)) return '—';
    const s = Math.max(0, Math.round(Number(sec)));
    if (s < 60) return s + ' 秒';
    const m = Math.floor(s / 60);
    const rest = s % 60;
    if (m < 60) return rest ? m + ' 分 ' + rest + ' 秒' : m + ' 分钟';
    const hr = Math.floor(m / 60);
    return hr + ' 小时 ' + (m % 60) + ' 分';
  }

  function formatClock(sec) {
    const s = Math.max(0, Math.round(Number(sec) || 0));
    return Math.floor(s / 60) + ':' + pad(s % 60);
  }

  function toDate(value) {
    if (!value) return null;
    if (value instanceof Date) return value;
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  function formatDateTime(value) {
    const d = toDate(value);
    if (!d) return '—';
    return (
      d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) +
      ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes())
    );
  }

  function formatDate(value) {
    const d = toDate(value);
    if (!d) return '—';
    return d.getFullYear() + ' 年 ' + pad(d.getMonth() + 1) + ' 月 ' + pad(d.getDate()) + ' 日';
  }

  /* ─────────── 校验 ─────────── */

  function normalizeCode(raw) {
    return String(raw || '').toUpperCase().replace(/[\s\-_]/g, '');
  }

  function validateCode(raw) {
    const code = normalizeCode(raw);
    if (!code) return { ok: false, code, message: '请输入答题码' };
    if (!CODE_RE.test(code)) {
      return { ok: false, code, message: '答题码是 4-6 位字母数字（不含 0、1、I、O）' };
    }
    return { ok: true, code, message: '' };
  }

  /* ─────────── 复制 / 下载 ─────────── */

  async function copyText(text) {
    const value = String(text);
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(value);
        return true;
      }
    } catch (e) { /* 继续走兜底 */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = value;
      ta.setAttribute('readonly', 'readonly');
      ta.style.position = 'fixed';
      ta.style.top = '-1000px';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, value.length);
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (e) {
      return false;
    }
  }

  function csvEscape(value) {
    const s = value === null || value === undefined ? '' : String(value);
    if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function downloadBlob(filename, blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }

  function downloadText(filename, text, mime) {
    // BOM 让 Excel 正确识别 UTF-8
    const blob = new Blob(['\ufeff' + text], { type: (mime || 'text/csv') + ';charset=utf-8' });
    downloadBlob(filename, blob);
  }

  /* ─────────── DOM 小工具 ─────────── */

  function h(tag, props) {
    const node = document.createElement(tag);
    if (props) {
      Object.keys(props).forEach(function (key) {
        const val = props[key];
        if (val === null || val === undefined || val === false) return;
        if (key === 'class') node.className = val;
        else if (key === 'text') node.textContent = val;
        else if (key === 'dataset') Object.assign(node.dataset, val);
        else if (key === 'style' && typeof val === 'object') Object.assign(node.style, val);
        else if (key.slice(0, 2) === 'on' && typeof val === 'function') {
          node.addEventListener(key.slice(2).toLowerCase(), val);
        } else node.setAttribute(key, val === true ? '' : val);
      });
    }
    const kids = Array.prototype.slice.call(arguments, 2);
    appendKids(node, kids);
    return node;
  }

  function appendKids(node, kids) {
    kids.forEach(function (kid) {
      if (kid === null || kid === undefined || kid === false) return;
      if (Array.isArray(kid)) return appendKids(node, kid);
      if (kid instanceof Node) return node.appendChild(kid);
      node.appendChild(document.createTextNode(String(kid)));
    });
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  function $(sel, root) {
    return (root || document).querySelector(sel);
  }

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  /* ─────────── Toast ─────────── */

  let toastTimer = null;
  let toastToken = 0;

  function toast(message, kind) {
    const el = document.getElementById('toast');
    if (!el) return;
    const token = (toastToken += 1);
    el.textContent = message;
    el.className = 'toast is-visible' + (kind === 'error' ? ' is-error' : kind === 'success' ? ' is-success' : '');
    el.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      if (token !== toastToken) return;
      el.className = 'toast';
      setTimeout(function () {
        if (token !== toastToken) return;
        el.hidden = true;
      }, 240);
    }, 2400);
  }

  /* ─────────── 弹窗 ─────────── */

  function modal(options) {
    const opts = options || {};
    const root = document.getElementById('modal-root');
    const previousFocus = document.activeElement;

    const body = h('div', { class: 'modal-body' });
    if (opts.body) {
      if (opts.body instanceof Node) body.appendChild(opts.body);
      else body.appendChild(document.createTextNode(String(opts.body)));
    }

    const actions = h('div', { class: 'modal-actions' });
    let closed = false;

    function close() {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKeydown);
      overlay.remove();
      document.body.style.overflow = '';
      if (previousFocus && previousFocus.focus) {
        try { previousFocus.focus(); } catch (e) { /* noop */ }
      }
      if (typeof opts.onClose === 'function') opts.onClose();
    }

    (opts.actions || []).forEach(function (action) {
      actions.appendChild(
        h('button', {
          class: 'btn ' + (action.kind === 'primary' ? 'btn-primary' : action.kind === 'danger' ? 'btn-danger' : 'btn-ghost'),
          type: 'button',
          onclick: function () {
            if (typeof action.onClick === 'function') action.onClick(close);
            else close();
          }
        }, action.label)
      );
    });

    const dialog = h('div', {
      class: 'modal',
      role: 'dialog',
      'aria-modal': 'true',
      'aria-label': opts.title || '对话框'
    },
      opts.title ? h('h2', { class: 'modal-title', text: opts.title }) : null,
      opts.desc ? h('p', { class: 'modal-desc', text: opts.desc }) : null,
      body,
      actions.childNodes.length ? actions : null
    );

    const overlay = h('div', { class: 'modal-overlay' }, dialog);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay && opts.dismissible !== false) close();
    });

    function onKeydown(e) {
      if (e.key === 'Escape' && opts.dismissible !== false) close();
    }
    document.addEventListener('keydown', onKeydown);

    root.appendChild(overlay);
    document.body.style.overflow = 'hidden';

    const focusTarget = dialog.querySelector('input, textarea, .btn-primary, button');
    if (focusTarget) setTimeout(function () { focusTarget.focus(); }, 30);

    if (typeof opts.onMount === 'function') opts.onMount(dialog, close);

    return { el: dialog, close: close, body: body };
  }

  function confirmAction(opts) {
    const options = opts || {};
    return modal({
      title: options.title || '确认操作',
      desc: options.desc || '',
      dismissible: true,
      actions: [
        { label: options.cancelText || '取消', kind: 'ghost' },
        {
          label: options.confirmText || '确定',
          kind: options.danger === false ? 'primary' : 'danger',
          onClick: function (close) {
            close();
            if (typeof options.onConfirm === 'function') options.onConfirm();
          }
        }
      ]
    });
  }

  /* ─────────── 视图切换 / 状态页 ─────────── */
  const VIEW_IDS = ['home', 'quiz', 'result', 'admin', 'super'];

  function show(which) {
    VIEW_IDS.forEach(function (name) {
      const el = document.getElementById('view-' + name);
      if (el) el.hidden = name !== which;
    });
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  function loading(container, text) {
    clear(container);
    container.appendChild(
      h('div', { class: 'loading' }, h('span', { class: 'spinner' }), text || '加载中…')
    );
  }

  function errorView(container, options) {
    const opts = options || {};
    clear(container);
    const actions = h('div', { class: 'state-actions' });
    (opts.actions || [{ label: '回到首页', kind: 'primary', href: './' }]).forEach(function (action) {
      if (action.href) {
        actions.appendChild(h('a', { class: 'btn ' + (action.kind === 'primary' ? 'btn-primary' : 'btn-ghost'), href: action.href }, action.label));
      } else {
        actions.appendChild(
          h('button', {
            class: 'btn ' + (action.kind === 'primary' ? 'btn-primary' : 'btn-ghost'),
            type: 'button',
            onclick: action.onClick || function () { location.href = './'; }
          }, action.label)
        );
      }
    });
    container.appendChild(
      h('div', { class: 'card state-card' },
        h('span', { class: 'state-emoji', text: opts.emoji || '🫥' }),
        h('h1', { class: 'state-title', text: opts.title || '出了点问题' }),
        h('p', { class: 'state-desc', text: opts.desc || '' }),
        actions
      )
    );
  }

  /* ─────────── 数字滚动 ─────────── */

  function countUp(el, to, options) {
    const opts = options || {};
    const duration = opts.duration || 900;
    const from = opts.from || 0;
    const target = Number(to) || 0;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.textContent = String(target);
      return;
    }
    const start = performance.now();
    function frame(now) {
      const t = Math.min(1, (now - start) / duration);
      // easeOutCubic
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = String(Math.round(from + (target - from) * eased));
      if (t < 1) requestAnimationFrame(frame);
      else el.textContent = String(target);
    }
    requestAnimationFrame(frame);
  }

  /* ─────────── 排行榜排序 ─────────── */

  function scoreOf(item) {
    const s = Number(item && item.score);
    return isNaN(s) ? 0 : s;
  }

  function durationOf(item) {
    const d = Number(item && item.duration);
    return isNaN(d) ? Number.MAX_SAFE_INTEGER : d;
  }

  function timeOf(item) {
    const d = toDate(item && item.createdAt);
    return d ? d.getTime() : Number.MAX_SAFE_INTEGER;
  }

  function sortScores(list) {
    return (list || []).slice().sort(function (a, b) {
      if (scoreOf(b) !== scoreOf(a)) return scoreOf(b) - scoreOf(a);
      if (durationOf(a) !== durationOf(b)) return durationOf(a) - durationOf(b);
      if (timeOf(a) !== timeOf(b)) return timeOf(a) - timeOf(b);
      return 0;
    });
  }

  /* ─────────── 评价文案 ─────────── */

  function evaluate(score, total) {
    if (!total) return { rate: 0, emoji: '🤔', text: '这道题好像没有题目' };
    const rate = score / total;
    if (score === total) return { rate, emoji: '🏆', text: '满分！你就是最懂我的人' };
    if (rate >= 0.8) return { rate, emoji: '💯', text: '很懂我嘛，默契十足' };
    if (rate >= 0.6) return { rate, emoji: '😊', text: '还不错，继续了解我' };
    if (rate >= 0.4) return { rate, emoji: '🤔', text: '我们还需要多聊聊' };
    return { rate, emoji: '😅', text: '看来我们不太熟…' };
  }

  /* ─────────── 音效 ─────────── */

  let audioCtx = null;
  const fileCache = {};

  function isMuted() {
    return store.get(KEYS.muted, false) === true;
  }

  function setMuted(muted) {
    store.set(KEYS.muted, !!muted);
    const btn = document.getElementById('sound-toggle');
    if (btn) {
      btn.setAttribute('aria-pressed', muted ? 'false' : 'true');
      const icon = btn.querySelector('.sound-icon');
      if (icon) icon.textContent = muted ? '🔇' : '🔊';
      btn.title = muted ? '音效已关闭，点击开启' : '音效已开启，点击静音';
    }
  }

  function getContext() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    if (!audioCtx) audioCtx = new AC();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume().catch(function () { /* noop */ });
    }
    return audioCtx;
  }

  function synthTone(kind) {
    const ctx = getContext();
    if (!ctx) return;
    const t0 = ctx.currentTime;
    const out = ctx.createGain();
    out.connect(ctx.destination);

    if (kind === 'correct') {
      // "叮"：两个高频正弦，快速衰减
      const g = ctx.createGain();
      g.connect(out);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.32, t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.42);

      [1318.5, 1975.5].forEach(function (freq, i) {
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t0);
        const mix = ctx.createGain();
        mix.gain.value = i === 0 ? 1 : 0.55;
        osc.connect(mix);
        mix.connect(g);
        osc.start(t0);
        osc.stop(t0 + 0.45);
      });
    } else {
      // "噗"：低频下滑的三角波
      const g = ctx.createGain();
      g.connect(out);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.34, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.34);

      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, t0);
      osc.frequency.exponentialRampToValueAtTime(110, t0 + 0.3);
      osc.connect(g);
      osc.start(t0);
      osc.stop(t0 + 0.36);
    }
    setTimeout(function () { try { out.disconnect(); } catch (e) { /* noop */ } }, 900);
  }

  function playFile(kind) {
    const cfg = (window.KM_CONFIG && window.KM_CONFIG.SOUND_FILES) || {};
    const src = cfg[kind];
    if (!src) return false;
    let audio = fileCache[kind];
    if (!audio) {
      audio = new Audio(src);
      audio.preload = 'auto';
      audio.addEventListener('error', function () { audio.__failed = true; });
      fileCache[kind] = audio;
    }
    if (audio.__failed) return false;
    try {
      audio.currentTime = 0;
      const p = audio.play();
      if (p && p.catch) p.catch(function () { /* 自动播放策略，忽略 */ });
      return true;
    } catch (e) {
      return false;
    }
  }

  function playSound(kind) {
    if (isMuted()) return;
    if (CFG.SOUND_MODE === 'files' && playFile(kind)) return;
    try { synthTone(kind); } catch (e) { /* 音频不可用就算了 */ }
  }

  /* ─────────── 彩带特效 ─────────── */

  function confettiBurst(options) {
    if (typeof window.confetti !== 'function') return;
    const opts = Object.assign({
      particleCount: 60,
      spread: 62,
      origin: { y: 0.68 },
      colors: ['#6C5CE7', '#00B894', '#FDCB6E', '#E17055', '#A29BFE'],
      disableForReducedMotion: true
    }, options || {});
    try { window.confetti(opts); } catch (e) { /* noop */ }
  }

  function confettiRain() {
    if (typeof window.confetti !== 'function') return;
    const colors = ['#6C5CE7', '#00B894', '#FDCB6E', '#E17055', '#A29BFE', '#ffffff'];
    const end = Date.now() + 1600;
    (function frame() {
      window.confetti({ particleCount: 5, angle: 60, spread: 60, origin: { x: 0, y: 0.7 }, colors });
      window.confetti({ particleCount: 5, angle: 120, spread: 60, origin: { x: 1, y: 0.7 }, colors });
      if (Date.now() < end) requestAnimationFrame(frame);
    })();
  }

  /* ─────────── 顶栏 Chrome ─────────── */

  function initChrome() {
    const btn = document.getElementById('sound-toggle');
    if (btn) {
      btn.addEventListener('click', function () {
        const next = !isMuted();
        setMuted(next);
        toast(next ? '已静音' : '已开启音效');
        if (!next) playSound('correct');
      });
    }
    setMuted(isMuted());
  }

  /* ─────────── 导出 ─────────── */

  KM.util = {
    CODE_CHARS, CODE_RE, KEYS,
    randomCode, randomKey, shortHash,
    normalizeCode, validateCode,
    formatDuration, formatClock, formatDateTime, formatDate,
    copyText, csvEscape, downloadText, downloadBlob,
    h, clear, $, sleep, sortScores, evaluate, countUp
  };
  KM.store = store;
  KM.ui = { show, loading, errorView, toast, modal, confirm: confirmAction, initChrome };
  KM.fx = { confettiBurst, confettiRain };
  KM.audio = { play: playSound, isMuted, setMuted };
})();
