/* ===========================================================
   certificate.js — Canvas 默契证书（渲染 + 下载）
   -----------------------------------------------------------
   尺寸固定 1200×850（约 3:2），可直接打印 / 发朋友圈。
   有 assets/cert-bg.png 就铺底图，没有就画渐变 + 装饰。
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;

  const W = 1200;
  const H = 850;

  const FONT = 'system-ui, -apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif';
  const FONT_EMOJI = '"Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';

  function font(size, weight) {
    return (weight || '') + ' ' + size + 'px ' + FONT;
  }

  function roundRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
  }

  // 自动缩小字号直到放进 maxWidth
  function fitText(ctx, text, maxWidth, startSize, weight) {
    let size = startSize;
    while (size > 14) {
      ctx.font = font(size, weight);
      if (ctx.measureText(text).width <= maxWidth) break;
      size -= 2;
    }
    return size;
  }

  function drawText(ctx, text, x, y, options) {
    const opts = options || {};
    ctx.save();
    ctx.fillStyle = opts.color || '#2d3436';
    ctx.textAlign = opts.align || 'center';
    ctx.textBaseline = opts.baseline || 'alphabetic';
    ctx.font = font(opts.size || 24, opts.weight || '');
    if (opts.maxWidth && ctx.measureText(text).width > opts.maxWidth) {
      const size = fitText(ctx, text, opts.maxWidth, opts.size || 24, opts.weight || '');
      ctx.font = font(size, opts.weight || '');
    }
    ctx.fillText(text, x, y);
    ctx.restore();
  }

  function sanitizeFilename(name) {
    return String(name || '')
      .replace(/[\\/:*?"<>|\r\n\t]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 40) || '匿名';
  }

  function fileName(data) {
    return '默契证书_' + sanitizeFilename(data.nickname) + '_' + (data.code || '') + '.png';
  }

  /* ─────────── 装饰槽 ─────────── */

  function paintBackground(ctx) {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#f7f4ff');
    g.addColorStop(0.45, '#ffffff');
    g.addColorStop(1, '#eafaf5');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // 柔和色块
    const blobs = [
      { x: 60, y: 30, r: 260, color: 'rgba(108, 92, 231, 0.10)' },
      { x: W - 40, y: 90, r: 220, color: 'rgba(0, 184, 148, 0.10)' },
      { x: W - 150, y: H - 10, r: 280, color: 'rgba(108, 92, 231, 0.07)' },
      { x: 120, y: H - 60, r: 200, color: 'rgba(0, 184, 148, 0.07)' }
    ];
    blobs.forEach(function (b) {
      const rad = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
      rad.addColorStop(0, b.color);
      rad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = rad;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
      ctx.fill();
    });

    // 细点阵
    ctx.save();
    ctx.fillStyle = 'rgba(108, 92, 231, 0.10)';
    for (let y = 120; y < H - 100; y += 34) {
      for (let x = 120; x < W - 100; x += 34) {
        ctx.beginPath();
        ctx.arc(x, y, 1.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  function paintBorder(ctx) {
    ctx.save();
    ctx.strokeStyle = '#6c5ce7';
    ctx.lineWidth = 6;
    roundRect(ctx, 40, 40, W - 80, H - 80, 28);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(108, 92, 231, 0.28)';
    ctx.lineWidth = 2;
    roundRect(ctx, 60, 60, W - 120, H - 120, 20);
    ctx.stroke();

    // 四角小圆点
    const corners = [
      [72, 72], [W - 72, 72], [72, H - 72], [W - 72, H - 72]
    ];
    corners.forEach(function (p) {
      ctx.beginPath();
      ctx.fillStyle = '#6c5ce7';
      ctx.arc(p[0], p[1], 5, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  function paintContent(ctx, data) {
    const score = Number(data.score) || 0;
    const total = Number(data.total) || 0;
    const verdict = KM.util.evaluate(score, total);
    const evalText = verdict.emoji + ' ' + verdict.text;

    // 奖杯
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '68px ' + FONT_EMOJI;
    ctx.fillText('🏆', W / 2, 148);
    ctx.restore();

    // 标题
    drawText(ctx, '默 契 证 书', W / 2, 250, {
      size: 58, weight: '800', color: '#2d3436', maxWidth: 800
    });

    // 标题下的装饰线
    ctx.save();
    ctx.strokeStyle = 'rgba(108, 92, 231, 0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(W / 2 - 190, 285);
    ctx.lineTo(W / 2 - 40, 285);
    ctx.moveTo(W / 2 + 40, 285);
    ctx.lineTo(W / 2 + 190, 285);
    ctx.stroke();
    ctx.fillStyle = '#6c5ce7';
    [0, -1, 1].forEach(function (dir) {
      ctx.beginPath();
      ctx.arc(W / 2 + dir * 22, 285, dir === 0 ? 4.5 : 3, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();

    // 昵称
    drawText(ctx, data.nickname || '匿名', W / 2, 396, {
      size: 78, weight: '800', color: '#6c5ce7', maxWidth: 860
    });

    // 说明
    const creator = data.creatorName ? data.creatorName + ' 的' : '朋友的';
    drawText(ctx, '完成了 ' + creator, W / 2, 452, {
      size: 28, color: '#7b8794', maxWidth: 700
    });

    drawText(ctx, '《' + (data.title || '你是不是最懂我') + '》', W / 2, 508, {
      size: 38, weight: '700', color: '#2d3436', maxWidth: 820
    });

    // 成绩胶囊
    const pillW = 360;
    const pillH = 82;
    const pillX = W / 2 - pillW / 2;
    const pillY = 556;
    ctx.save();
    ctx.fillStyle = 'rgba(0, 184, 148, 0.12)';
    roundRect(ctx, pillX, pillY, pillW, pillH, pillH / 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(0, 184, 148, 0.45)';
    ctx.lineWidth = 2;
    roundRect(ctx, pillX, pillY, pillW, pillH, pillH / 2);
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = font(30, '600');
    ctx.fillStyle = '#00876c';
    const label = '答对 ';
    const scoreText = score + ' / ' + total;
    const widthLabel = ctx.measureText(label).width;
    ctx.font = font(40, '800');
    const widthScore = ctx.measureText(scoreText).width;
    const startX = W / 2 - (widthLabel + widthScore + 12) / 2;

    ctx.font = font(30, '600');
    ctx.textAlign = 'left';
    ctx.fillText(label, startX, pillY + pillH / 2 + 2);
    ctx.font = font(40, '800');
    ctx.fillText(scoreText, startX + widthLabel + 12, pillY + pillH / 2 + 1);
    ctx.restore();

    // 评价
    drawText(ctx, evalText, W / 2, 700, {
      size: 26, weight: '600', color: '#4b5563', maxWidth: 780
    });

    // 页脚
    const certNo = U.shortHash(String(data.nickname) + String(data.code) + String(data.date));
    ctx.save();
    ctx.strokeStyle = 'rgba(45, 52, 54, 0.12)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(200, 736);
    ctx.lineTo(W - 200, 736);
    ctx.stroke();
    ctx.restore();

    drawText(ctx, data.date || U.formatDate(new Date()), 200, 772, {
      size: 20, color: '#7b8794', align: 'left'
    });
    drawText(ctx, 'Code: ' + (data.code || '----'), W / 2, 772, {
      size: 20, color: '#7b8794'
    });
    drawText(ctx, 'No. ' + certNo, W - 200, 772, {
      size: 20, color: '#7b8794', align: 'right'
    });

    drawText(ctx, '你是不是最懂我 · 默契测试', W / 2, 806, {
      size: 17, color: 'rgba(123, 135, 148, 0.85)'
    });
  }

  function loadImage(src) {
    return new Promise(function (resolve) {
      const img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = function () { resolve(null); };
      img.src = src;
    });
  }

  function drawCover(ctx, img) {
    const scale = Math.max(W / img.width, H / img.height);
    const w = img.width * scale;
    const h = img.height * scale;
    ctx.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
  }

  /**
   * 渲染证书到 canvas
   * @param {HTMLCanvasElement} canvas
   * @param {{nickname,creatorName,title,score,total,code,date}} data
   */
  async function render(canvas, data) {
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, W, H);

    const bg = (window.KM_CONFIG && window.KM_CONFIG.CERT_BG) || '';
    let painted = false;
    if (bg) {
      const img = await loadImage(bg);
      if (img) {
        drawCover(ctx, img);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
        ctx.fillRect(0, 0, W, H);
        painted = true;
      }
    }
    if (!painted) paintBackground(ctx);

    paintBorder(ctx);
    paintContent(ctx, data);
    return canvas;
  }

  /**
   * 下载证书 PNG
   */
  function download(canvas, data) {
    const name = fileName(data || {});
    return new Promise(function (resolve) {
      if (!canvas.toBlob) {
        const a = document.createElement('a');
        a.href = canvas.toDataURL('image/png');
        a.download = name;
        a.click();
        resolve(name);
        return;
      }
      canvas.toBlob(function (blob) {
        if (!blob) {
          resolve(null);
          return;
        }
        U.downloadBlob(name, blob);
        resolve(name);
      }, 'image/png');
    });
  }

  KM.cert = { render: render, download: download, fileName: fileName, WIDTH: W, HEIGHT: H };
})();
