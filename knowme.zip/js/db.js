/* ===========================================================
   db.js — 数据层抽象
   -----------------------------------------------------------
   同一套 API，两种实现（STORAGE_MODE）：
     local ：localStorage，开箱即用，数据只在本机浏览器
     cloud ：Supabase（Postgres + RLS），跨设备可分享
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const store = KM.store;

  const SUPABASE_CDN = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js';

  function cfg() {
    return window.KM_CONFIG || {};
  }

  function mode() {
    const m = String(cfg().STORAGE_MODE || 'local').toLowerCase();
    if (m === 'cloud') return 'cloud';
    if (m === 'api') return 'api';
    return 'local';
  }

  function isCloud() {
    return mode() === 'cloud';
  }

  /** 走自己服务器上的 /api（backend/） */
  function isApi() {
    return mode() === 'api';
  }

  /** 数据是否跨设备（cloud 或 api） */
  function isRemote() {
    return isCloud() || isApi();
  }

  /** 管理口令是否由服务端校验（api 模式） */
  function isServerAuth() {
    return isApi();
  }

  /** 能不能删单条成绩 */
  function canDeleteScore() {
    return !isCloud();
  }

  /* ─────────── Supabase client（懒加载） ─────────── */

  let clientPromise = null;

  function getClient() {
    if (clientPromise) return clientPromise;
    clientPromise = new Promise(function (resolve, reject) {
      const conf = cfg();
      if (!conf.SUPABASE_URL || !conf.SUPABASE_ANON_KEY) {
        reject(new Error('还没配置 Supabase：请在 js/config.js 里填写 SUPABASE_URL 和 SUPABASE_ANON_KEY'));
        return;
      }
      function boot() {
        if (window.supabase && typeof window.supabase.createClient === 'function') {
          try {
            resolve(window.supabase.createClient(conf.SUPABASE_URL, conf.SUPABASE_ANON_KEY));
          } catch (e) {
            reject(new Error('Supabase 初始化失败：' + e.message));
          }
        } else {
          reject(new Error('Supabase SDK 加载失败，请检查网络或 CDN 是否可访问'));
        }
      }
      if (window.supabase && window.supabase.createClient) {
        boot();
        return;
      }
      const script = document.createElement('script');
      script.src = SUPABASE_CDN;
      script.async = true;
      script.onload = boot;
      script.onerror = function () { reject(new Error('Supabase SDK 加载失败，请检查网络')); };
      document.head.appendChild(script);
    }).catch(function (err) {
      clientPromise = null; // 允许下次重试
      throw err;
    });
    return clientPromise;
  }

  /* ─────────── 本地存储 key ─────────── */

  function quizKey(code) {
    return U.KEYS.quizPrefix + code;
  }

  function scoresKey(code) {
    return U.KEYS.scoresPrefix + code;
  }

  /* ─────────── 数据归一化 ─────────── */

  function normalizeQuiz(row) {
    if (!row) return null;
    return {
      code: String(row.code || '').toUpperCase(),
      title: row.title || '',
      creatorName: row.creator_name !== undefined ? row.creator_name : (row.creatorName || ''),
      adminKey: row.admin_key !== undefined ? row.admin_key : (row.adminKey || ''),
      questions: Array.isArray(row.questions) ? row.questions : [],
      createdAt: row.created_at !== undefined ? row.created_at : (row.createdAt || null)
    };
  }

  function normalizeScore(row) {
    if (!row) return null;
    return {
      id: row.id || '',
      quizCode: row.quiz_code !== undefined ? row.quiz_code : (row.quizCode || ''),
      nickname: row.nickname || '匿名',
      score: Number(row.score) || 0,
      total: Number(row.total) || 0,
      duration: row.duration === null || row.duration === undefined ? null : Number(row.duration),
      answers: Array.isArray(row.answers) ? row.answers : [],
      createdAt: row.created_at !== undefined ? row.created_at : (row.createdAt || null)
    };
  }

  function cleanQuestions(questions) {
    return (questions || []).map(function (item) {
      return {
        q: String(item.q || '').slice(0, 200),
        options: (item.options || []).map(function (opt) { return String(opt).slice(0, 120); }),
        answer: Math.max(0, Math.min(3, Number(item.answer) || 0))
      };
    });
  }

  function genId() {
    try {
      if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    } catch (e) { /* noop */ }
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  /* ─────────── 自家服务器 API（STORAGE_MODE: 'api'） ─────────── */

  const ADMIN_KEY_PREFIX = 'km.adminKey.';
  const SUPER_KEY_SESSION = 'km.super.key';

  function adminKeyOf(code) {
    return store.get(ADMIN_KEY_PREFIX + code, '') || '';
  }

  function rememberAdminKey(code, key) {
    if (code && key) store.set(ADMIN_KEY_PREFIX + code, key);
  }

  function sessionGet(key) {
    try { return window.sessionStorage.getItem(key) || ''; } catch (e) { return ''; }
  }

  function sessionSet(key, value) {
    try {
      if (value) window.sessionStorage.setItem(key, value);
      else window.sessionStorage.removeItem(key);
    } catch (e) { /* 隐私模式 */ }
  }

  function apiBase() {
    return String(cfg().API_BASE || '').replace(/\/+$/, '');
  }

  async function apiFetch(method, pathname, body, headers) {
    const url = apiBase() + pathname;
    let res;
    try {
      res = await window.fetch(url, {
        method: method,
        headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}),
        body: body === undefined || body === null ? undefined : JSON.stringify(body)
      });
    } catch (e) {
      const err = new Error('连不上服务器（' + url + '），检查网络或服务是否在跑');
      err.code = 'NETWORK';
      throw err;
    }

    const text = await res.text();
    let data = null;
    if (text) {
      try { data = JSON.parse(text); } catch (e) { data = null; }
    }

    if (!res.ok) {
      const err = new Error((data && data.message) || ('请求失败（HTTP ' + res.status + '）'));
      err.status = res.status;
      err.code = (data && data.error) || 'HTTP_' + res.status;
      throw err;
    }
    return data || {};
  }

  async function apiCreateQuiz(payload) {
    const data = await apiFetch('POST', '/api/quizzes', {
      title: payload.title,
      creatorName: payload.creatorName,
      questions: payload.questions
    });
    if (!payload.skipMyCodes) {
      rememberAdminKey(data.code, data.adminKey);
      addMyCode(data.code);
    }
    return { code: data.code, adminKey: data.adminKey, createdAt: data.createdAt };
  }

  async function apiGetQuiz(code) {
    let data;
    try {
      data = await apiFetch('GET', '/api/quizzes/' + encodeURIComponent(code));
    } catch (e) {
      if (e.status === 404) return null;
      throw e;
    }
    const quiz = normalizeQuiz(data);
    if (quiz) quiz.adminKey = adminKeyOf(code); // 服务端不下发，用本机记住的
    return quiz;
  }

  async function apiSubmitScore(record, input) {
    const data = await apiFetch(
      'POST',
      '/api/quizzes/' + encodeURIComponent(record.quiz_code) + '/scores',
      {
        nickname: record.nickname,
        choices: Array.isArray(input.choices) ? input.choices : [],
        duration: record.duration
      }
    );
    return { ok: true, id: data.id, score: data.score, total: data.total, answers: data.answers };
  }

  async function apiGetAllScores(code) {
    const key = adminKeyOf(code);
    if (!key) {
      const err = new Error('需要管理密钥');
      err.status = 403;
      err.code = 'NO_KEY';
      throw err;
    }
    const data = await apiFetch('GET', '/api/quizzes/' + encodeURIComponent(code) + '/scores', null, {
      'X-Admin-Key': key
    });
    return U.sortScores((data.items || []).map(normalizeScore).filter(Boolean));
  }

  async function apiGetRanking(code, limit) {
    const data = await apiFetch(
      'GET',
      '/api/quizzes/' + encodeURIComponent(code) + '/ranking?limit=' + encodeURIComponent(limit || 20)
    );
    return (data.items || []).map(function (row) {
      return {
        id: row.id,
        nickname: row.nickname,
        score: row.score,
        total: row.total,
        duration: row.duration,
        createdAt: row.createdAt
      };
    });
  }

  async function apiDeleteScore(code, id) {
    await apiFetch(
      'DELETE',
      '/api/quizzes/' + encodeURIComponent(code) + '/scores/' + encodeURIComponent(id),
      null,
      { 'X-Admin-Key': adminKeyOf(code) }
    );
    return { ok: true };
  }

  function requireSuperKey() {
    const key = sessionGet(SUPER_KEY_SESSION);
    if (!key) {
      const err = new Error('还没有登录超级后台，请重新输入口令');
      err.status = 401;
      err.code = 'NO_SUPER_KEY';
      throw err;
    }
    return key;
  }

  async function apiListAllQuizzes() {
    const data = await apiFetch('GET', '/api/admin/quizzes', null, { 'X-Super-Key': requireSuperKey() });
    return {
      items: (data.items || []).map(normalizeQuiz).filter(Boolean),
      counts: data.counts || {},
      driver: data.driver || 'json'
    };
  }

  /* 校验管理密钥；api 模式下顺便记住它 */
  async function verifyAdmin(codeInput, key) {
    const code = U.normalizeCode(codeInput);
    if (!code) return false;

    if (isApi()) {
      const candidate = key || adminKeyOf(code);
      if (!candidate) return false;
      try {
        await apiFetch('GET', '/api/quizzes/' + encodeURIComponent(code) + '/scores', null, {
          'X-Admin-Key': candidate
        });
        rememberAdminKey(code, candidate);
        return true;
      } catch (e) {
        if (e.status === 403) return false;
        throw e;
      }
    }

    if (!key) return false;
    const quiz = await getQuiz(code);
    return !!(quiz && quiz.adminKey && quiz.adminKey === key);
  }

  /* 校验超级口令；api 模式交给服务端 */
  async function verifySuper(key) {
    if (isApi()) {
      if (!key) return false;
      try {
        await apiFetch('POST', '/api/admin/login', {}, { 'X-Super-Key': key });
        sessionSet(SUPER_KEY_SESSION, key);
        return true;
      } catch (e) {
        if (e.status === 403) return false;
        throw e;
      }
    }
    return !!key && key === String(cfg().SUPER_KEY || '');
  }

  function forgetSuperKey() {
    sessionSet(SUPER_KEY_SESSION, '');
  }

  function storedAdminKey(code) {
    return adminKeyOf(code);
  }

  /* ─────────── 我的题目（本机记录） ─────────── */

  function getMyCodes() {
    const list = store.get(U.KEYS.myCodes, []);
    return Array.isArray(list) ? list : [];
  }

  function addMyCode(code) {
    const list = getMyCodes();
    if (list.indexOf(code) === -1) {
      list.unshift(code);
      store.set(U.KEYS.myCodes, list.slice(0, 50));
    }
  }

  function removeMyCode(code) {
    store.set(U.KEYS.myCodes, getMyCodes().filter(function (c) { return c !== code; }));
  }

  /* ─────────── 创建题目 ─────────── */

  async function localCreateQuiz(input) {
    const questions = cleanQuestions(input.questions);
    const adminKey = U.randomKey();
    const createdAt = new Date().toISOString();

    for (let attempt = 0; attempt < 10; attempt++) {
      const code = U.randomCode();
      if (store.get(quizKey(code), null)) continue;
      const quiz = {
        code: code,
        title: input.title,
        creatorName: input.creatorName || '',
        adminKey: adminKey,
        questions: questions,
        createdAt: createdAt
      };
      if (!store.set(quizKey(code), quiz)) {
        throw new Error('浏览器存储不可用（可能是隐私模式），请检查设置后重试');
      }
      store.set(scoresKey(code), []);
      if (!input.skipMyCodes) addMyCode(code);
      return { code: code, adminKey: adminKey, createdAt: createdAt };
    }
    throw new Error('生成答题码失败，请重试');
  }

  async function cloudCreateQuiz(input) {
    const client = await getClient();
    const questions = cleanQuestions(input.questions);
    const adminKey = U.randomKey();

    for (let attempt = 0; attempt < 6; attempt++) {
      const code = U.randomCode();
      const found = await client.from('quizzes').select('code').eq('code', code).maybeSingle();
      if (found.error) throw new Error('查询答题码失败：' + found.error.message);
      if (found.data) continue;

      const inserted = await client.from('quizzes').insert({
        code: code,
        title: input.title,
        creator_name: input.creatorName || '',
        admin_key: adminKey,
        questions: questions
      }).select('created_at').maybeSingle();

      if (inserted.error) {
        // 23505 = 唯一键冲突，换一个 code 重试
        if (inserted.error.code === '23505') continue;
        throw new Error('创建失败：' + inserted.error.message);
      }
      if (!input.skipMyCodes) addMyCode(code);
      return {
        code: code,
        adminKey: adminKey,
        createdAt: (inserted.data && inserted.data.created_at) || new Date().toISOString()
      };
    }
    throw new Error('生成答题码失败，请重试');
  }

  async function createQuiz(input, options) {
    const opts = options || {};
    const payload = {
      title: String(input.title || '').slice(0, 60) || '你是不是最懂我',
      creatorName: String(input.creatorName || '').slice(0, 24),
      questions: input.questions,
      // 超级后台代别人建题时不要污染自己的「我的题目」
      skipMyCodes: !!opts.skipMyCodes
    };
    return isApi() ? apiCreateQuiz(payload)
      : isCloud() ? cloudCreateQuiz(payload)
        : localCreateQuiz(payload);
  }

  /* ─────────── 读取题目 ─────────── */

  async function getQuiz(codeInput) {
    const code = U.normalizeCode(codeInput);
    if (!code) return null;
    if (isApi()) return apiGetQuiz(code);

    if (!isCloud()) {
      return normalizeQuiz(store.get(quizKey(code), null));
    }

    const client = await getClient();
    const res = await client
      .from('quizzes')
      .select('code,title,creator_name,admin_key,questions,created_at')
      .eq('code', code)
      .maybeSingle();

    if (res.error) throw new Error('读取题目失败：' + res.error.message);
    return normalizeQuiz(res.data);
  }

  /* ─────────── 提交成绩 ─────────── */

  async function submitScore(input) {
    const code = U.normalizeCode(input.code);
    const record = {
      quiz_code: code,
      nickname: String(input.nickname || '').slice(0, 24) || '匿名',
      score: Number(input.score) || 0,
      total: Number(input.total) || 0,
      duration: input.duration === null || input.duration === undefined ? null : Math.max(0, Math.round(Number(input.duration))),
      answers: Array.isArray(input.answers) ? input.answers.map(function (v) { return v ? 1 : 0; }) : []
    };

    // api 模式：把选择交给服务端判分，分数由服务端算
    if (isApi()) return apiSubmitScore(record, input);

    if (!isCloud()) {
      const list = store.get(scoresKey(code), []);
      const rows = Array.isArray(list) ? list : [];
      const row = Object.assign({ id: genId(), createdAt: new Date().toISOString() }, record);
      rows.push(row);
      if (!store.set(scoresKey(code), rows)) {
        throw new Error('本地存储写入失败，可能空间已满');
      }
      return { ok: true, id: row.id };
    }

    const client = await getClient();
    const res = await client.from('scores').insert(record).select('id').maybeSingle();
    if (res.error) throw new Error('提交成绩失败：' + res.error.message);
    return { ok: true, id: (res.data && res.data.id) || '' };
  }

  /* ─────────── 读取成绩 ─────────── */

  async function getAllScores(codeInput) {
    const code = U.normalizeCode(codeInput);
    if (!code) return [];
    if (isApi()) return apiGetAllScores(code);

    if (!isCloud()) {
      const list = store.get(scoresKey(code), []);
      return U.sortScores((Array.isArray(list) ? list : []).map(normalizeScore).filter(Boolean));
    }

    const client = await getClient();
    const res = await client
      .from('scores')
      .select('id,nickname,score,total,duration,answers,created_at,quiz_code')
      .eq('quiz_code', code)
      .limit(1000);

    if (res.error) throw new Error('读取成绩失败：' + res.error.message);
    return U.sortScores((res.data || []).map(normalizeScore).filter(Boolean));
  }

  async function getRanking(codeInput, limit) {
    if (isApi()) return apiGetRanking(U.normalizeCode(codeInput), limit);

    const list = await getAllScores(codeInput);
    const max = Math.max(1, Number(limit) || Number(cfg().RANKING_LIMIT) || 20);
    return list.slice(0, max).map(function (row) {
      return {
        id: row.id,
        nickname: row.nickname,
        score: row.score,
        total: row.total,
        duration: row.duration,
        createdAt: row.createdAt
      };
    });
  }

  /* ─────────── 删除成绩（仅 local） ─────────── */

  async function deleteScore(codeInput, id) {
    const code = U.normalizeCode(codeInput);
    if (isApi()) return apiDeleteScore(code, id);

    if (isCloud()) {
      throw new Error('云端模式暂不支持删除（RLS 只允许读和插入），可到 Supabase 控制台操作');
    }
    const list = store.get(scoresKey(code), []).filter(function (row) { return row.id !== id; });
    store.set(scoresKey(code), list);
    return { ok: true };
  }

  /* ─────────── 提交失败时的本地暂存 ─────────── */

  function queuePending(record) {
    const list = store.get(U.KEYS.pending, []);
    list.unshift(Object.assign({ id: genId(), queuedAt: new Date().toISOString() }, record));
    store.set(U.KEYS.pending, list.slice(0, 30));
  }

  function getPending(code) {
    const list = store.get(U.KEYS.pending, []);
    if (!code) return list;
    return list.filter(function (row) { return row.code === U.normalizeCode(code); });
  }

  async function flushPending() {
    const list = store.get(U.KEYS.pending, []);
    if (!list.length) return { ok: true, done: 0, failed: 0 };

    const remain = [];
    let done = 0;
    for (let i = 0; i < list.length; i++) {
      try {
        await submitScore(list[i]);
        done += 1;
      } catch (e) {
        remain.push(list[i]);
      }
    }
    store.set(U.KEYS.pending, remain);
    return { ok: remain.length === 0, done: done, failed: remain.length };
  }

  /* ─────────── 超级管理员：全量读取 / 删除 ─────────── */

  function localKeys(prefix) {
    const out = [];
    try {
      const ls = window.localStorage;
      for (let i = 0; i < ls.length; i++) {
        const k = ls.key(i);
        if (k && k.indexOf(prefix) === 0) out.push(k);
      }
    } catch (e) {
      throw new Error('读取浏览器存储失败：' + e.message);
    }
    return out;
  }

  function timeValue(value) {
    const d = value ? new Date(value) : null;
    return d && !isNaN(d.getTime()) ? d.getTime() : 0;
  }

  /**
   * 列出所有题目。
   * local：只能看到这台浏览器里的（数据本来就在各自浏览器，跨设备看不到）
   * cloud：quizzes 表全量
   */
  async function listAllQuizzes() {
    if (isApi()) return (await apiListAllQuizzes()).items;

    if (!isCloud()) {
      return localKeys(U.KEYS.quizPrefix)
        .map(function (k) { return normalizeQuiz(store.get(k, null)); })
        .filter(function (q) { return q && q.code && Array.isArray(q.questions); })
        .sort(function (a, b) { return timeValue(b.createdAt) - timeValue(a.createdAt); });
    }

    const client = await getClient();
    const res = await client
      .from('quizzes')
      .select('code,title,creator_name,admin_key,questions,created_at')
      .order('created_at', { ascending: false })
      .limit(2000);

    if (res.error) throw new Error('读取全部题目失败：' + res.error.message);
    return (res.data || []).map(normalizeQuiz).filter(Boolean);
  }

  /** 每套题的作答人数 {code: n} */
  async function getScoreCounts() {
    const counts = {};
    if (isApi()) return (await apiListAllQuizzes()).counts;

    if (!isCloud()) {
      localKeys(U.KEYS.scoresPrefix).forEach(function (k) {
        const code = k.slice(U.KEYS.scoresPrefix.length);
        const list = store.get(k, []);
        counts[code] = Array.isArray(list) ? list.length : 0;
      });
      return counts;
    }

    const client = await getClient();
    const pageSize = 1000;
    for (let page = 0; page < 10; page++) {
      const res = await client
        .from('scores')
        .select('quiz_code')
        .order('id', { ascending: true })
        .range(page * pageSize, page * pageSize + pageSize - 1);
      if (res.error) throw new Error('统计作答数失败：' + res.error.message);
      const rows = res.data || [];
      rows.forEach(function (row) {
        const code = row.quiz_code;
        counts[code] = (counts[code] || 0) + 1;
      });
      if (rows.length < pageSize) break;
    }
    return counts;
  }

  /**
   * 删除一整套题（连带成绩）。
   * local：直接删 localStorage
   * cloud：走 security definer RPC，数据库校验口令哈希，前端拿不到 delete 权限
   */
  async function deleteQuiz(codeInput) {
    const code = U.normalizeCode(codeInput);
    if (!code) throw new Error('缺少答题码');

    if (isApi()) {
      await apiFetch('DELETE', '/api/admin/quizzes/' + encodeURIComponent(code), null, {
        'X-Super-Key': requireSuperKey()
      });
      removeMyCode(code);
      return { ok: true };
    }

    if (!isCloud()) {
      store.del(quizKey(code));
      store.del(scoresKey(code));
      store.del(U.KEYS.lastResultPrefix + code);
      store.del(U.KEYS.submittedPrefix + code);
      removeMyCode(code);
      const pending = store.get(U.KEYS.pending, []);
      if (Array.isArray(pending)) {
        store.set(U.KEYS.pending, pending.filter(function (row) { return row.code !== code; }));
      }
      return { ok: true };
    }

    const key = String(cfg().SUPER_KEY || '');
    if (!key) throw new Error('config.js 里没有配置 SUPER_KEY，云端无法删除');

    const client = await getClient();
    const res = await client.rpc('super_delete_quiz', { p_key: key, p_code: code });

    if (res.error) {
      const msg = res.error.message || '';
      if (/SUPER_KEY_INVALID/i.test(msg)) {
        throw new Error('超级口令不对：数据库里存的是 sha256 哈希，要和 config.js 的 SUPER_KEY 完全一致');
      }
      if (/Could not find the function|does not exist|schema cache/i.test(msg)) {
        throw new Error('数据库还没有 super_delete_quiz 函数，请重跑 supabase/schema.sql');
      }
      throw new Error('删除失败：' + msg);
    }

    removeMyCode(code);
    return { ok: true };
  }

  /* ─────────── 统计 ─────────── */

  function accuracyByQuestion(quiz, scores) {
    const total = scores.length;
    return (quiz.questions || []).map(function (item, index) {
      let correct = 0;
      scores.forEach(function (row) {
        if (row.answers && row.answers[index]) correct += 1;
      });
      return {
        index: index,
        q: item.q,
        correct: correct,
        total: total,
        rate: total ? correct / total : 0
      };
    });
  }

  function stats(scores) {
    const total = scores.length;
    if (!total) return { count: 0, avgScore: 0, avgDuration: 0, fullCount: 0 };
    let scoreSum = 0;
    let durationSum = 0;
    let durationCount = 0;
    let fullCount = 0;
    scores.forEach(function (row) {
      scoreSum += row.score;
      if (row.duration !== null && row.duration !== undefined && !isNaN(row.duration)) {
        durationSum += row.duration;
        durationCount += 1;
      }
      if (row.total > 0 && row.score === row.total) fullCount += 1;
    });
    return {
      count: total,
      avgScore: scoreSum / total,
      avgDuration: durationCount ? durationSum / durationCount : 0,
      fullCount: fullCount
    };
  }

  KM.db = {
    mode: mode,
    isCloud: isCloud,
    isApi: isApi,
    isRemote: isRemote,
    isServerAuth: isServerAuth,
    canDeleteScore: canDeleteScore,
    verifyAdmin: verifyAdmin,
    verifySuper: verifySuper,
    forgetSuperKey: forgetSuperKey,
    storedAdminKey: storedAdminKey,
    getClient: getClient,
    createQuiz: createQuiz,
    getQuiz: getQuiz,
    submitScore: submitScore,
    getRanking: getRanking,
    getAllScores: getAllScores,
    deleteScore: deleteScore,
    getMyCodes: getMyCodes,
    addMyCode: addMyCode,
    removeMyCode: removeMyCode,
    listAllQuizzes: listAllQuizzes,
    getScoreCounts: getScoreCounts,
    deleteQuiz: deleteQuiz,
    queuePending: queuePending,
    getPending: getPending,
    flushPending: flushPending,
    accuracyByQuestion: accuracyByQuestion,
    stats: stats
  };
})();
