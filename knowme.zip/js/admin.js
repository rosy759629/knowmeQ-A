/* ===========================================================
   admin.js — 管理页：密钥校验 / 排行榜 / 每题正确率 / CSV 导出
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const store = KM.store;
  const h = U.h;

  /* ─────────── 权限 ─────────── */

  function isAuthorized(quiz) {
    if (KM.db.getMyCodes().indexOf(quiz.code) !== -1) return true;
    return false;
  }

  function renderGate(container, quiz, options) {
    const opts = options || {};
    const input = h('input', {
      class: 'input',
      type: 'password',
      maxlength: '32',
      placeholder: '粘贴管理密钥',
      autocomplete: 'off',
      'aria-label': '管理密钥'
    });
    const errorEl = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const btn = h('button', { class: 'btn btn-primary btn-block', type: 'button' }, '进入管理页');

    function submit() {
      const value = input.value.trim();
      if (!value) {
        errorEl.hidden = false;
        errorEl.textContent = '请输入密钥';
        input.focus();
        return;
      }
      btn.disabled = true;
      KM.db.verifyAdmin(quiz.code, value).then(function (ok) {
        btn.disabled = false;
        if (!ok) {
          errorEl.hidden = false;
          errorEl.textContent = '密钥不对，检查一下完整的管理链接';
          input.classList.add('is-invalid');
          input.select();
          return;
        }
        KM.db.addMyCode(quiz.code);
        renderDashboard(container, quiz);
      }).catch(function (err) {
        btn.disabled = false;
        errorEl.hidden = false;
        errorEl.textContent = (err && err.message) || '校验失败，请重试';
      });
    }

    btn.addEventListener('click', submit);
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        submit();
      }
    });
    input.addEventListener('input', function () {
      input.classList.remove('is-invalid');
      errorEl.hidden = true;
    });

    U.clear(container);
    container.appendChild(
      h('div', { class: 'card key-gate' },
        h('span', { class: 'state-emoji', text: '🔐' }),
        h('h1', { class: 'state-title', text: '需要管理密钥' }),
        h('p', { class: 'state-desc', text: '《' + quiz.title + '》· 答题码 ' + quiz.code + '。密钥在创建时给你的管理链接里（?code=' + quiz.code + '&admin&key=…）。' }),
        input,
        errorEl,
        h('div', { style: { marginTop: '16px' } }, btn),
        h('p', { class: 'subtle', style: { marginTop: '14px' }, text: '提示：在这台电脑上创建过的题目会自动放行。' })
      )
    );
    setTimeout(function () { input.focus(); }, 80);
  }

  /* ─────────── 工具条 ─────────── */

  function buildTools(quiz, scores, container) {
    const copyQuiz = h('button', {
      class: 'btn btn-ghost btn-sm',
      type: 'button',
      onclick: async function () {
        const ok = await U.copyText(KM.nav.quizUrl(quiz.code));
        KM.ui.toast(ok ? '答题链接已复制' : '复制失败', ok ? 'success' : 'error');
      }
    }, '复制答题链接');

    const copyAdmin = h('button', {
      class: 'btn btn-ghost btn-sm',
      type: 'button',
      onclick: async function () {
        const ok = await U.copyText(KM.nav.adminUrl(quiz.code, quiz.adminKey));
        KM.ui.toast(ok ? '管理链接已复制（别发给别人）' : '复制失败', ok ? 'success' : 'error');
      }
    }, '复制管理链接');

    const exportBtn = h('button', {
      class: 'btn btn-soft btn-sm',
      type: 'button',
      onclick: function () {
        if (!scores.length) {
          KM.ui.toast('还没有成绩可导出', 'error');
          return;
        }
        exportCsv(quiz, scores);
      }
    }, '导出 CSV');

    const refreshBtn = h('button', {
      class: 'btn btn-soft btn-sm',
      type: 'button',
      onclick: function () { renderDashboard(container, quiz); }
    }, '刷新');

    return h('div', { class: 'admin-tools' }, copyQuiz, copyAdmin, exportBtn, refreshBtn);
  }

  function exportCsv(quiz, scores) {
    const rows = [['名次', '昵称', '答对', '总题数', '用时（秒）', '提交时间']];
    scores.forEach(function (row, i) {
      rows.push([
        i + 1,
        row.nickname,
        row.score,
        row.total,
        row.duration === null || row.duration === undefined ? '' : row.duration,
        U.formatDateTime(row.createdAt)
      ]);
    });
    // 每题正确率也附在最后，方便一起存档
    rows.push([]);
    rows.push(['题目', '答对人数', '作答人数', '正确率']);
    const acc = KM.db.accuracyByQuestion(quiz, scores);
    acc.forEach(function (item, i) {
      rows.push(['Q' + (i + 1) + ' ' + item.q, item.correct, item.total, Math.round(item.rate * 100) + '%']);
    });

    const csv = rows.map(function (row) {
      return row.map(U.csvEscape).join(',');
    }).join('\r\n');

    const name = '默契测试_' + quiz.code + '_' + U.formatDateTime(new Date()).replace(/[: ]/g, '-') + '.csv';
    U.downloadText(name, csv, 'text/csv');
    KM.ui.toast('已导出 ' + scores.length + ' 条成绩', 'success');
  }

  /* ─────────── 排行表 ─────────── */

  function renderTable(quiz, scores, container) {
    const canDelete = KM.db.canDeleteScore();

    const thead = h('thead', {},
      h('tr', {},
        h('th', { class: 'col-rank', text: '#' }),
        h('th', { text: '昵称' }),
        h('th', { text: '答对' }),
        h('th', { text: '用时' }),
        h('th', { text: '提交时间' }),
        h('th', { class: 'col-act', text: '操作' })
      )
    );

    const tbody = h('tbody', {});

    if (!scores.length) {
      tbody.appendChild(
        h('tr', {}, h('td', { colspan: '6', style: { textAlign: 'center', padding: '30px 10px', color: 'var(--muted)' } },
          '还没有人作答。把答题链接发出去吧。'))
      );
    }

    scores.forEach(function (row, i) {
      const medal = i === 0 ? '🥇 ' : i === 1 ? '🥈 ' : i === 2 ? '🥉 ' : '';
      const actions = h('span', {});

      if (canDelete) {
        const del = h('button', {
          class: 'btn btn-danger btn-sm',
          type: 'button',
          onclick: function () {
            KM.ui.confirm({
              title: '删除这条成绩？',
              desc: '「' + row.nickname + '」' + row.score + '/' + row.total + ' 的成绩会从排行榜里移除，不能撤销。',
              confirmText: '删除',
              onConfirm: async function () {
                try {
                  await KM.db.deleteScore(quiz.code, row.id);
                  KM.ui.toast('已删除', 'success');
                  renderDashboard(container, quiz);
                } catch (err) {
                  KM.ui.toast((err && err.message) || '删除失败', 'error');
                }
              }
            });
          }
        }, '删除');
        actions.appendChild(del);
      }

      tbody.appendChild(
        h('tr', {},
          h('td', { class: 'col-rank' },
            medal ? h('span', { class: 'medal', text: medal }) : null,
            h('b', { text: String(i + 1) })
          ),
          h('td', { class: 'col-name', title: row.nickname, text: row.nickname }),
          h('td', { class: 'col-score', text: row.score + '/' + row.total }),
          h('td', { class: 'col-num', text: U.formatDuration(row.duration) }),
          h('td', { class: 'col-num', text: U.formatDateTime(row.createdAt) }),
          h('td', { class: 'col-act' }, actions)
        )
      );
    });

    const card = h('div', { class: 'card' },
      h('div', { class: 'rank-head' },
        h('h2', { class: 'card-title', text: '排行榜 · ' + scores.length + ' 人' }),
        h('span', { class: 'subtle', text: '排序：答对多 → 用时短 → 先提交' })
      ),
      h('div', { class: 'table-scroll' }, h('table', { class: 'table' }, thead, tbody))
    );

    if (!canDelete) {
      card.appendChild(h('p', { class: 'form-hint', text: '云端模式下删除需要到 Supabase 控制台操作（RLS 只开放读取和插入）。' }));
    }

    return card;
  }

  /* ─────────── 每题正确率 ─────────── */

  function renderAccuracy(quiz, scores) {
    const acc = KM.db.accuracyByQuestion(quiz, scores);

    const list = h('div', { class: 'acc-list' });
    const barRefs = [];

    acc.forEach(function (item, i) {
      const pct = Math.round(item.rate * 100);
      const bar = h('div', {
        class: 'acc-bar' + (pct >= 70 ? ' is-high' : pct < 35 ? ' is-low' : '')
      }, h('i', {}));
      barRefs.push({ bar: bar, pct: scores.length ? pct : 0 });

      list.appendChild(
        h('div', { class: 'acc-row' },
          h('div', { class: 'acc-label' },
            h('span', { class: 'acc-q', title: item.q }, h('b', { text: 'Q' + (i + 1) }), item.q),
            h('span', { class: 'acc-pct', text: scores.length ? pct + '%' : '—' })
          ),
          bar,
          h('span', { class: 'acc-sub', text: scores.length ? item.correct + ' / ' + item.total + ' 人答对' : '还没有人作答' })
        )
      );
    });

    setTimeout(function () {
      barRefs.forEach(function (ref) {
        const fill = ref.bar.querySelector('i');
        if (fill) fill.style.width = ref.pct + '%';
      });
    }, 60);

    return h('div', { class: 'card' },
      h('div', { class: 'rank-head' },
        h('h2', { class: 'card-title', text: '每题正确率' }),
        h('span', { class: 'subtle', text: '哪道题最能把人区分开' })
      ),
      list
    );
  }

  /* ─────────── 信息卡 ─────────── */

  function renderInfo(quiz, scores) {
    const stats = KM.db.stats(scores);
    const mode = KM.db.mode();
    const modeText = mode === 'api'
      ? '🗄️ 服务器数据库，跨设备可见'
      : mode === 'cloud'
        ? '☁️ 云端模式（Supabase），跨设备可见'
        : '💾 本地模式，仅这台设备浏览器里的成绩';

    return h('div', { class: 'card admin-head' },
      h('div', { style: { flex: '1 1 260px', minWidth: '0' } },
        h('p', { class: 'admin-kicker', text: '出题人后台' }),
        h('h1', { class: 'admin-title', text: '《' + quiz.title + '》' }),
        h('p', { class: 'admin-meta' },
          (quiz.creatorName ? quiz.creatorName + ' 出题 · ' : ''),
          h('span', {}, 'code ', h('code', { text: quiz.code })),
          ' · ',
          quiz.questions.length + ' 道题 · 创建于 ' + U.formatDateTime(quiz.createdAt)
        ),
        h('p', { class: 'admin-meta' },
          modeText,
          ' · ',
          h('a', { href: '?code=' + encodeURIComponent(quiz.code) }, '打开答题页')
        )
      ),
      h('div', { class: 'admin-stats' },
        h('div', { class: 'stat' }, h('b', { text: String(stats.count) }), h('span', { text: '作答人数' })),
        h('div', { class: 'stat' }, h('b', { text: stats.count ? (Math.round(stats.avgScore * 10) / 10) : '—' }), h('span', { text: '平均答对' })),
        h('div', { class: 'stat' }, h('b', { text: stats.fullCount ? String(stats.fullCount) : '0' }), h('span', { text: '满分人数' }))
      )
    );
  }

  /* ─────────── 面板 ─────────── */

  async function renderDashboard(container, quiz) {
    KM.ui.loading(container, '正在读取成绩…');

    let scores = [];
    try {
      scores = await KM.db.getAllScores(quiz.code);
    } catch (err) {
      KM.ui.errorView(container, {
        emoji: '📡',
        title: '读取成绩失败',
        desc: (err && err.message) || '网络好像不太顺',
        actions: [
          { label: '重试', kind: 'primary', onClick: function () { renderDashboard(container, quiz); } },
          { label: '回首页', kind: 'ghost', href: './' }
        ]
      });
      return;
    }

    U.clear(container);
    container.appendChild(renderInfo(quiz, scores));
    container.appendChild(buildTools(quiz, scores, container));
    container.appendChild(renderTable(quiz, scores, container));
    container.appendChild(renderAccuracy(quiz, scores));
  }

  /* ─────────── 入口 ─────────── */

  KM.views.admin = {
    init: async function (container, options) {
      const opts = options || {};
      KM.ui.show('admin');
      if (!container) return;
      KM.ui.loading(container, '正在加载题目…');

      const validation = U.validateCode(opts.code);
      if (!validation.ok) {
        KM.ui.errorView(container, {
          emoji: '🔍',
          title: '管理链接不完整',
          desc: '链接里需要带上 code，例如：?code=A7K2&admin&key=…',
          actions: [{ label: '回首页', kind: 'primary', href: './' }]
        });
        return;
      }

      let quiz = null;
      try {
        quiz = await KM.db.getQuiz(validation.code);
      } catch (err) {
        KM.ui.errorView(container, {
          emoji: '📡',
          title: '加载失败',
          desc: (err && err.message) || '网络好像不太顺',
          actions: [{ label: '刷新重试', kind: 'primary', onClick: function () { location.reload(); } }]
        });
        return;
      }

      if (!quiz) {
        KM.ui.errorView(container, {
          emoji: '🫥',
          title: '题目不存在或已删除',
          desc: '答题码 ' + validation.code + ' 没有对应的题目。',
          actions: [{ label: '回首页', kind: 'primary', href: './' }]
        });
        return;
      }

      document.title = '管理 · 《' + quiz.title + '》';

      let authed = false;
      try {
        if (opts.key) authed = await KM.db.verifyAdmin(quiz.code, opts.key);
        if (!authed && KM.db.storedAdminKey(quiz.code)) {
          authed = await KM.db.verifyAdmin(quiz.code, KM.db.storedAdminKey(quiz.code));
        }
      } catch (err) {
        KM.ui.errorView(container, {
          emoji: '🔐',
          title: '校验密钥失败',
          desc: (err && err.message) || '请稍后重试',
          actions: [
            { label: '重试', kind: 'primary', onClick: function () { location.reload(); } },
            { label: '回首页', kind: 'ghost', href: './' }
          ]
        });
        return;
      }

      // 本地 / 云端模式：这台机器创建过就放行（api 模式必须凭密钥，见上）
      if (!authed && !KM.db.isServerAuth() && isAuthorized(quiz)) authed = true;

      if (authed) {
        KM.db.addMyCode(quiz.code);
        store.set(U.KEYS.lastCode, quiz.code);
        renderDashboard(container, quiz);
      } else {
        renderGate(container, quiz, {});
      }
    }
  };
})();
