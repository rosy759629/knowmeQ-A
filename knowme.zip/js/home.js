/* ===========================================================
   home.js — 首页：输入答题码 / 创建题目 / 我的题目
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const store = KM.store;
  const h = U.h;

  /* ─────────── 创建表单 ───────────
     编辑器本身在 js/editor.js，超级后台代建题目用的是同一套 */

  function buildCreateForm(body) {
    U.clear(body);

    const form = KM.editor.buildForm({
      defaultTitle: '你是不是最懂我',
      defaultCreator: store.get(U.KEYS.creator, ''),
      submitText: '生成题目',
      busyText: '生成中…',
      onSubmit: async function (values) {
        store.set(U.KEYS.creator, values.creatorName);
        const result = await KM.db.createQuiz(values);
        renderMyQuizzes();
        showCreatedModal(result, values.title, values.questions.length);
      }
    });

    body.appendChild(form.el);
  }

  /* ─────────── 创建成功弹窗 ─────────── */

  function copyRow(label, value) {
    const input = h('input', { class: 'input', type: 'text', value: value, readonly: true });
    const btn = h('button', { class: 'btn btn-soft btn-sm', type: 'button' }, '复制');
    btn.addEventListener('click', async function () {
      const ok = await U.copyText(value);
      KM.ui.toast(ok ? '已复制' : '复制失败，请手动长按选择', ok ? 'success' : 'error');
    });
    input.addEventListener('focus', function () { input.select(); });
    return h('div', {},
      h('p', { class: 'copy-label', text: label }),
      h('div', { class: 'copy-row' }, input, btn)
    );
  }

  function showCreatedModal(result, title, count) {
    const shareUrl = KM.nav.quizUrl(result.code);
    const adminUrl = KM.nav.adminUrl(result.code, result.adminKey);

    const body = h('div', {},
      h('div', { class: 'result-code' },
        h('strong', { text: result.code }),
        h('button', {
          class: 'btn btn-soft btn-sm',
          type: 'button',
          onclick: async function () {
            const ok = await U.copyText(result.code);
            KM.ui.toast(ok ? '答题码已复制' : '复制失败', ok ? 'success' : 'error');
          }
        }, '复制码')
      ),
      copyRow('答题链接（发给朋友）', shareUrl),
      copyRow('管理链接（只给自己）', adminUrl),
      h('div', { class: 'warn-box', text: '⚠️ 管理链接等于密码，别发到群里。弄丢了也没关系：用创建它的这台电脑打开 code 就能进管理页。' })
    );

    KM.ui.modal({
      title: '出好了！' + title,
      desc: '《' + title + '》' + count + ' 道题，答题码 ' + result.code + '。',
      body: body,
      actions: [
        { label: '去答题试试', kind: 'ghost', onClick: function () { KM.nav.quiz(result.code); } },
        { label: '查看管理页', kind: 'primary', onClick: function () { KM.nav.admin(result.code, result.adminKey); } }
      ],
      onClose: function () {
        KM.ui.toast('答题码 ' + result.code + '，随时可以从首页「我的题目」找回');
      }
    });
  }

  /* ─────────── 我的题目 ─────────── */

  async function renderMyQuizzes() {
    const box = document.getElementById('my-quizzes');
    if (!box) return;
    const codes = KM.db.getMyCodes();
    if (!codes.length) {
      box.hidden = true;
      U.clear(box);
      return;
    }

    box.hidden = false;
    U.clear(box);
    box.appendChild(h('h2', { text: '我的题目' }));

    const seen = [];
    for (let i = 0; i < codes.length; i++) {
      const code = codes[i];
      let quiz = null;
      try {
        quiz = await KM.db.getQuiz(code);
      } catch (e) {
        quiz = null;
      }
      if (!quiz) {
        // 本地模式下题目已被清掉，顺带清理记录
        if (!KM.db.isCloud()) KM.db.removeMyCode(code);
        continue;
      }
      seen.push(code);
      box.appendChild(
        h('div', { class: 'my-quiz-item' },
          h('div', { class: 'my-quiz-main' },
            h('span', { class: 'my-quiz-title', text: '《' + quiz.title + '》' }),
            h('span', { class: 'my-quiz-meta', text: 'CODE ' + quiz.code + ' · ' + (quiz.questions.length || 0) + ' 题' })
          ),
          h('div', { class: 'my-quiz-actions' },
            h('button', {
              class: 'btn btn-ghost btn-sm',
              type: 'button',
              onclick: async function () {
                const ok = await U.copyText(KM.nav.quizUrl(quiz.code));
                KM.ui.toast(ok ? '答题链接已复制' : '复制失败', ok ? 'success' : 'error');
              }
            }, '复制链接'),
            h('a', { class: 'btn btn-soft btn-sm', href: KM.nav.adminUrl(quiz.code, quiz.adminKey) }, '管理')
          )
        )
      );
    }

    if (!seen.length) box.hidden = true;
  }

  /* ─────────── 模式提示 ─────────── */

  function renderModeHint() {
    const el = document.getElementById('mode-hint');
    if (!el) return;
    // api / cloud 都是跨设备数据，不需要这个提示
    if (KM.db.isRemote()) {
      el.hidden = true;
      return;
    }
    el.hidden = false;
    el.innerHTML = '';
    el.appendChild(
      h('span', {},
        '💡 当前是本地体验模式：题目和成绩只保存在这台设备的浏览器里。想让朋友打开链接就能答题，请把 ',
        h('code', { text: 'js/config.js' }),
        ' 的 ',
        h('code', { text: 'STORAGE_MODE' }),
        ' 改为 ',
        h('code', { text: 'cloud' }),
        ' 并填好 Supabase（步骤见 README）。'
      )
    );
  }

  /* ─────────── 进入答题 ─────────── */

  function bindJoin(container) {
    const form = document.getElementById('join-form');
    const input = document.getElementById('join-code');
    const errorEl = document.getElementById('join-error');
    if (!form || !input) return;

    input.addEventListener('input', function () {
      const pos = input.selectionStart;
      input.value = U.normalizeCode(input.value);
      // 光标回位（大写转换不改变长度，仅保险）
      try { input.setSelectionRange(pos, pos); } catch (e) { /* noop */ }
      input.classList.remove('is-invalid');
      if (errorEl) errorEl.hidden = true;
    });

    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      const result = U.validateCode(input.value);
      if (!result.ok) {
        if (errorEl) {
          errorEl.hidden = false;
          errorEl.textContent = result.message;
        }
        input.classList.add('is-invalid');
        input.focus();
        return;
      }

      const btn = form.querySelector('button[type="submit"]');
      const original = btn.textContent;
      btn.disabled = true;
      btn.textContent = '查找中…';
      try {
        const quiz = await KM.db.getQuiz(result.code);
        if (!quiz) {
          if (errorEl) {
            errorEl.hidden = false;
            errorEl.textContent = '没有找到答题码 ' + result.code + '，检查一下有没有输错' + (KM.db.isCloud() ? '' : '（本地模式下题目只存在于创建它的浏览器里）');
          }
          input.classList.add('is-invalid');
          return;
        }
        KM.nav.quiz(result.code);
        store.set(U.KEYS.lastCode, result.code);
      } catch (err) {
        if (errorEl) {
          errorEl.hidden = false;
          errorEl.textContent = (err && err.message) || '查找失败，请重试';
        }
      } finally {
        btn.disabled = false;
        btn.textContent = original;
      }
    });
  }

  function bindCreateToggle() {
    const btn = document.getElementById('toggle-create');
    const body = document.getElementById('create-body');
    if (!btn || !body) return;

    btn.addEventListener('click', function () {
      const willOpen = body.hidden;
      body.hidden = !willOpen;
      btn.textContent = willOpen ? '收起表单' : '展开表单';
      btn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      if (willOpen) {
        if (!body.querySelector('.create-form')) buildCreateForm(body);
        body.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });

    // 支持从别处（如结果页"我也出一套"）自动展开
    if (window.location.hash === '#create') {
      window.setTimeout(function () { btn.click(); }, 50);
    }
  }

  /* ─────────── 导出 ─────────── */

  KM.views.home = {
    init: function (container) {
      if (!container) return;
      // 回到首页时清掉可能的错误展示：直接重新绑定即可
      KM.ui.show('home');
      bindJoin(container);
      bindCreateToggle();
      renderModeHint();

      const cachedCode = store.get(U.KEYS.lastCode, '');
      const input = document.getElementById('join-code');
      if (input && !input.value && cachedCode) input.value = cachedCode;

      renderMyQuizzes();
    }
  };
})();
