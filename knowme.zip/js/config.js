/* ===========================================================
   config.js — 全局配置（唯一的"开关面板"）
   ===========================================================
   想切换到云端：把 STORAGE_MODE 改成 'cloud'，
   并填好 SUPABASE_URL / SUPABASE_ANON_KEY（见 supabase/schema.sql 和 README）。
   =========================================================== */

window.KM_CONFIG = {
  /* 'local' = 数据存在当前浏览器（默认，开箱即用，适合演示）
     'api'   = 存到你自己服务器上的数据库（推荐上线用）
               走 server.js 的 /api，数据层见 backend/，支持 json 文件 / MySQL
     'cloud' = 存到 Supabase，跨设备、可分享 */
  STORAGE_MODE: 'local',

  /* api 模式下如果前后端不同源（比如页面在 CDN、API 在别的域名），填 API 的地址
     同源部署留空即可，例如 '' */
  API_BASE: '',

  /* Supabase 项目配置（仅 cloud 模式需要）
     注意：这里填的是 anon public key，不是 service_role key */
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: '',

  /* 音效：
     'synth' = Web Audio 实时合成（默认，零资源、可离线）
     'files' = 读取 assets/sounds/*.mp3，读不到自动退回合成 */
  SOUND_MODE: 'synth',
  SOUND_FILES: {
    correct: 'assets/sounds/correct.mp3',
    wrong: 'assets/sounds/wrong.mp3'
  },

  /* 题目数量上限 */
  MAX_QUESTIONS: 10,

  /* code 长度（4-6） */
  CODE_LENGTH: 4,

  /* 结果页排行榜条数 */
  RANKING_LIMIT: 20,

  /* 证书底图（放 assets/cert-bg.png，1200×850）；留空则用渐变底 */
  CERT_BG: '',

  /* 超级管理员口令（访问后台用，默认 <站点>/manage）
     ⚠️ 前端口令只是"门帘"，任何人都能看到这个文件。
        真正拦得住的是云端：删除走 Supabase 的 security definer 函数，
        数据库里存的是这个口令的 sha256，对不上就删不掉（见 supabase/schema.sql）。
     上线前务必改掉默认值！ */
  SUPER_KEY: 'CHANGE-ME-SUPER',

  /* 下面三项是兜底默认值，实际请改 js/config.admin.js
     （那个文件就是专门管后台入口的） */
  ADMIN_PATH: '/manage',
  SHOW_FOOTER_LINK: true,
  SESSION_MINUTES: 120,

  /* 排行榜排序：分数高 → 用时短 → 先提交 */
  SORT: 'score_desc_duration_asc_created_asc'
};
