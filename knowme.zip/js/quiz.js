/* ===========================================================
   quiz.js — 答题页：昵称 → 逐题作答 → 对错特效 → 提交 → 结果
   =========================================================== */

(function () {
  'use strict';

  const KM = window.KM;
  const U = KM.util;
  const store = KM.store;
  const h = U.h;

  const MARK_SVG = {
    correct: '<svg viewBox="0 0 56 56" aria-hidden="true"><path d="M12 30 L23 41 L44 16"/></svg>',
    wrong: '<svg viewBox="0 0 56 56" aria-hidden="true"><path d="M16 16 L40 40 M40 16 L16 40"/></svg>'
  };

  let state = null;

  /* ─────────── 开始卡 ─────────── */

  function renderStart(container, quiz, options) {
    const opts = options || {};
    const savedNick = opts.nickname || store.get(U.KEYS.nickname, '');
    const total = quiz.questions.length;

    const nickInput = h('input', {
      class: 'input',
      id: 'nick-input',
      type: 'text',
      maxlength: '24',
      value: savedNick,
      placeholder: '怎么称呼你？',
      autocomplete: 'nickname',
      'aria-label': '你的昵称'
    });

    const errorEl = h('p', { class: 'form-error', role: 'alert', hidden: true });

    const startBtn = h('button', { class: 'btn btn-primary btn-block', type: 'button' }, '开始答题');

    function start() {
      const nickname = nickInput.value.trim();
      if (!nickname) {
        errorEl.hidden = false;
        errorEl.textContent = '先填个昵称，排行榜上要用';
        nickInput.classList.add('is-invalid');
        nickInput.focus();
        return;
      }
      store.set(U.KEYS.nickname, nickname);
      beginQuiz(container, quiz, nickname);
    }

    startBtn.addEventListener('click', start);
    nickInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        start();
      }
    });
    nickInput.addEventListener('input', function () {
      nickInput.classList.remove('is-invalid');
      errorEl.hidden = true;
    });

    const card = h('div', { class: 'card quiz-start' },
      h('p', { class: 'quiz-start-eyebrow', text: '默契测试' }),
      h('h1', { class: 'quiz-start-title', text: '《' + quiz.title + '》' }),
      h('p', {
        class: 'quiz-start-by',
        text: (quiz.creatorName ? quiz.creatorName + ' 出了 ' : '') + total + ' 道题，看看你有多懂' + (quiz.creatorName ? quiz.creatorName : '他/她')
      }),
      h('div', { class: 'field' },
        h('label', { for: 'nick-input', text: '你的昵称' }),
        nickInput
      ),
      errorEl,
      startBtn,
      h('p', { class: 'subtle', text: '昵称会显示在排行榜上；成绩只提交给你正在答的这套题。' })
    );

    U.clear(container);
    container.appendChild(card);
    setTimeout(function () { nickInput.focus(); }, 60);
  }

  /* ─────────── 已答过提示 ─────────── */

  function renderAlreadyDone(container, quiz, last) {
    const card = h('div', { class: 'card quiz-done-card state-card' },
      h('span', { class: 'state-emoji', text: '📮' }),
      h('h1', { class: 'state-title', text: '你已经答过这套题了' }),
      h('p', {
        class: 'state-desc',
        text: last
          ? '上次答对 ' + last.score + '/' + last.total + ' 题，用时 ' + U.formatDuration(last.duration) + '。'
          : '可以看上次的成绩，或者再答一次（会重新记录一条成绩）。'
      }),
      h('div', { class: 'state-actions' },
        h('a', { class: 'btn btn-primary', href: '?code=' + encodeURIComponent(quiz.code) + '&result' }, '查看我的成绩'),
        h('button', {
          class: 'btn btn-ghost',
          type: 'button',
          onclick: function () {
            renderStart(container, quiz, { nickname: last ? last.nickname : '' });
          }
        }, '再答一次')
      )
    );
    U.clear(container);
    container.appendChild(card);
  }

  /* ─────────── 答题主流程 ─────────── */

  function beginQuiz(container, quiz, nickname) {
    const total = quiz.questions.length;

    state = {
      quiz: quiz,
      nickname: nickname,
      index: 0,
      picks: [],
      startedAt: Date.now(),
      questionAt: Date.now(),
      locked: false,
      finished: false,
      total: total
    };
    store.set(U.KEYS.lastCode, quiz.code);

    const progressBar = h('div', { class: 'quiz-progress-bar' });
    const counter = h('span', { class: 'quiz-counter', text: '1 / ' + total });
    const timer = h('span', { class: 'quiz-timer', text: '0:00' });
    const cardSlot = h('div', {});

    const wrapper = h('div', { class: 'quiz-wrap' },
      h('div', { class: 'quiz-top' },
        h('div', { class: 'quiz-progress' }, progressBar),
        h('div', { class: 'quiz-meta' },
          counter,
          h('span', { class: 'quiz-meta-title', text: '《' + quiz.title + '》' }),
          timer
        )
      ),
      cardSlot
    );

    U.clear(container);
    container.appendChild(wrapper);

    const tick = setInterval(function () {
      timer.textContent = U.formatClock((Date.now() - state.startedAt) / 1000);
    }, 500);

    const keyHandler = function (e) {
      if (state.locked || state.finished) return;
      const key = e.key.toUpperCase();
      const map = { '1': 0, '2': 1, '3': 2, '4': 3, A: 0, B: 1, C: 2, D: 3 };
      if (map[key] === undefined) return;
      const btn = cardSlot.querySelectorAll('.opt')[map[key]];
      if (btn) btn.click();
    };
    document.addEventListener('keydown', keyHandler);

    state.tick = tick;
    state.keyHandler = keyHandler;

    renderQuestion(cardSlot, progressBar, counter, function onDone() {
      clearInterval(tick);
      document.removeEventListener('keydown', keyHandler);
      finishQuiz(container, quiz);
    });
  }

  function renderQuestion(slot, progressBar, counter, onDone) {
    const index = state.index;
    const item = state.quiz.questions[index];
    const total = state.total;

    counter.textContent = (index + 1) + ' / ' + total;
    progressBar.style.width = Math.round((index / total) * 100) + '%';

    const optionButtons = (item.options || []).map(function (text, i) {
      const btn = h('button', {
        class: 'opt',
        type: 'button',
        'data-index': String(i)
      },
        h('span', { class: 'opt-key', text: 'ABCD'[i] || String(i + 1) }),
        h('span', { class: 'opt-text', text: text })
      );
      btn.addEventListener('click', function () { pick(i, btn); });
      return btn;
    });

    const card = h('div', { class: 'card quiz-card is-entering' },
      h('p', { class: 'quiz-qno', text: 'Q' + (index + 1) }),
      h('h2', { class: 'quiz-q', text: item.q }),
      h('div', { class: 'quiz-options', role: 'group', 'aria-label': '选项' }, optionButtons),
      h('p', { class: 'quiz-tip', text: '点选项作答（也可按键盘 A-D / 1-4），答完自动进入下一题' })
    );

    U.clear(slot);
    slot.appendChild(card);
    setTimeout(function () { card.classList.remove('is-entering'); }, 320);

    state.questionAt = Date.now();
    state.locked = false;

    /* ── 选择 ── */
    function pick(choice, chosenBtn) {
      if (state.locked) return;
      state.locked = true;

      const answerIndex = Number(item.answer) || 0;
      const correct = choice === answerIndex;
      const spent = Math.round((Date.now() - state.questionAt) / 1000);

      state.picks.push({
        index: index,
        choice: choice,
        correct: correct,
        seconds: spent
      });

      // 锁定所有按钮
      optionButtons.forEach(function (btn) { btn.disabled = true; });

      chosenBtn.classList.add(correct ? 'is-correct' : 'is-wrong');

      if (!correct) {
        optionButtons.forEach(function (btn, i) {
          if (i === answerIndex) btn.classList.add('is-answer');
          else if (i !== choice) btn.classList.add('is-dim');
        });
        KM.audio.play('wrong');
      } else {
        optionButtons.forEach(function (btn, i) {
          if (i !== choice) btn.classList.add('is-dim');
        });
        KM.audio.play('correct');
        KM.fx.confettiBurst({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
      }

      showMark(card, correct);

      progressBar.style.width = Math.round(((index + 1) / total) * 100) + '%';

      const delay = correct ? 1100 : 1400;
      setTimeout(function () {
        if (index + 1 >= total) {
          onDone();
          return;
        }
        card.classList.add('is-leaving');
        setTimeout(function () {
          state.index += 1;
          renderQuestion(slot, progressBar, counter, onDone);
        }, 250);
      }, delay);
    }
  }

  function showMark(card, correct) {
    const mark = h('div', {
      class: 'quiz-mark ' + (correct ? 'is-correct' : 'is-wrong'),
      'aria-hidden': 'true'
    });
    mark.innerHTML = MARK_SVG[correct ? 'correct' : 'wrong'];
    card.appendChild(mark);
  }

  /* ─────────── 交卷 ─────────── */

  async function finishQuiz(container, quiz) {
    if (state.finished) return;
    state.finished = true;

    const duration = Math.max(1, Math.round((Date.now() - state.startedAt) / 1000));
    const flags = state.picks.map(function (pick) { return pick.correct ? 1 : 0; });
    const score = flags.reduce(function (sum, v) { return sum + v; }, 0);
    const details = state.quiz.questions.map(function (item, i) {
      const pick = state.picks[i] || {};
      return {
        q: item.q,
        options: item.options,
        answer: Number(item.answer) || 0,
        choice: pick.choice === undefined ? null : pick.choice,
        correct: !!pick.correct,
        seconds: pick.seconds || 0
      };
    });

    const record = {
      code: quiz.code,
      nickname: state.nickname,
      score: score,
      total: quiz.questions.length,
      duration: duration,
      answers: flags,
      // api 模式下服务端用 choices 重新判分（分数以服务端为准）
      choices: state.picks.map(function (pick) { return pick.choice; }),
      details: details,
      createdAt: new Date().toISOString()
    };

    // 本地先落地，结果页一定拿得到
    store.set(U.KEYS.lastResultPrefix + quiz.code, record);
    store.set(U.KEYS.submittedPrefix + quiz.code, true);

    // 显示交卷中
    U.clear(container);
    container.appendChild(
      h('div', { class: 'loading' }, h('span', { class: 'spinner' }), '正在提交成绩…')
    );

    try {
      const res = await KM.db.submitScore(record);
      if (res) {
        // 以服务端判分为准（防止前端算错或被改）
        if (typeof res.score === 'number') {
          record.score = res.score;
          record.total = typeof res.total === 'number' ? res.total : record.total;
          if (Array.isArray(res.answers)) record.answers = res.answers;
        }
        if (res.id) record.id = res.id;
        store.set(U.KEYS.lastResultPrefix + quiz.code, record);
      }
    } catch (err) {
      KM.db.queuePending(record);
      KM.ui.toast('成绩暂时没提交成功，已存在本地，可在结果页重试', 'error');
    }

    KM.nav.result(quiz.code);
  }

  /* ─────────── 入口 ─────────── */

  KM.views.quiz = {
    init: async function (container, options) {
      const opts = options || {};
      KM.ui.show('quiz');

      if (!container) return;
      KM.ui.loading(container, '正在加载题目…');

      const validation = U.validateCode(opts.code);
      if (!validation.ok) {
        KM.ui.errorView(container, {
          emoji: '🔍',
          title: '答题码看起来不对',
          desc: validation.message,
          actions: [{ label: '回首页重输', kind: 'primary', href: './' }]
        });
        return;
      }

      let quiz = null;
      try {
        quiz = await KM.db.getQuiz(validation.code);
      } catch (err) {
        KM.ui.errorView(container, {
          emoji: '📡',
          title: '加载失败',
          desc: (err && err.message) || '网络好像不太顺，刷新试试',
          actions: [
            { label: '重新加载', kind: 'primary', onClick: function () { location.reload(); } },
            { label: '回首页', kind: 'ghost', href: './' }
          ]
        });
        return;
      }

      if (!quiz) {
        KM.ui.errorView(container, {
          emoji: '🫥',
          title: '题目不存在或已删除',
          desc: '答题码 ' + validation.code + ' 没有对应的题目。' + (KM.db.isCloud() ? '' : '本地模式下，题目只存在于创建它的那台浏览器里。'),
          actions: [{ label: '回首页', kind: 'primary', href: './' }]
        });
        return;
      }

      if (!quiz.questions.length) {
        KM.ui.errorView(container, {
          emoji: '📭',
          title: '这套题还没有题目',
          desc: '可能是出题时出错了，找出题人重出一套吧。',
          actions: [{ label: '回首页', kind: 'primary', href: './' }]
        });
        return;
      }

      document.title = '《' + quiz.title + '》· 你是不是最懂我';

      const submitted = store.get(U.KEYS.submittedPrefix + quiz.code, false) === true;
      const last = store.get(U.KEYS.lastResultPrefix + quiz.code, null);

      if (submitted) {
        renderAlreadyDone(container, quiz, last);
      } else {
        renderStart(container, quiz, {});
      }
    }
  };
})();
