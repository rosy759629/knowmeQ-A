-- ============================================================
--  MySQL / MariaDB 建表脚本
--  用法：
--    mysql -u root -p -e "create database if not exists knowme character set utf8mb4 collate utf8mb4_unicode_ci;"
--    mysql -u root -p knowme < backend/schema.mysql.sql
--
--  建完给应用建个只读写这两张表的账号：
--    create user 'knowme'@'localhost' identified by '换成你的密码';
--    grant select, insert, update, delete on knowme.* to 'knowme'@'localhost';
--    flush privileges;
-- ============================================================

create table if not exists quizzes (
  code         varchar(8)   not null,
  title        varchar(120) not null,
  creator_name varchar(60)  not null default '',
  admin_key    varchar(32)  not null,
  questions    json         not null,
  created_at   datetime(3)  not null default current_timestamp(3),
  primary key (code),
  key idx_quizzes_created (created_at)
) engine = InnoDB default charset = utf8mb4 collate = utf8mb4_unicode_ci;

create table if not exists scores (
  id         char(36)    not null,
  quiz_code  varchar(8)  not null,
  nickname   varchar(60) not null,
  score      int         not null,
  total      int         not null,
  duration   int         null,
  answers    json        null,
  created_at datetime(3) not null default current_timestamp(3),
  primary key (id),
  key idx_scores_quiz (quiz_code, score desc, duration asc),
  constraint fk_scores_quiz foreign key (quiz_code)
    references quizzes (code) on delete cascade on update cascade
) engine = InnoDB default charset = utf8mb4 collate = utf8mb4_unicode_ci;

-- 自检
-- select count(*) from quizzes;
-- select count(*) from scores;
-- select quiz_code, count(*) from scores group by quiz_code;
