/* ===========================================================
   backend/store-mysql.js — MySQL / MariaDB 驱动（可选）
   -----------------------------------------------------------
   需要：npm i mysql2
   建表：mysql -u root -p < backend/schema.mysql.sql
   切换：KM_DB=mysql 或改 backend/config.js 的 DB.DRIVER
   =========================================================== */

'use strict';

function toIso(value) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString();
  return String(value);
}

function parseJson(value, fallback) {
  if (value === null || value === undefined) return fallback;
  if (typeof value === 'object') return value; // 有的驱动会直接给对象
  try {
    return JSON.parse(value);
  } catch (e) {
    return fallback;
  }
}

function mapQuiz(row) {
  return {
    code: row.code,
    title: row.title,
    creatorName: row.creator_name || '',
    adminKey: row.admin_key,
    questions: parseJson(row.questions, []),
    createdAt: toIso(row.created_at)
  };
}

function mapScore(row) {
  return {
    id: row.id,
    quizCode: row.quiz_code,
    nickname: row.nickname,
    score: Number(row.score),
    total: Number(row.total),
    duration: row.duration === null ? null : Number(row.duration),
    answers: parseJson(row.answers, []),
    createdAt: toIso(row.created_at)
  };
}

class MysqlStore {
  constructor(options) {
    this.options = options || {};
    this.pool = null;
    this.driver = 'mysql';
  }

  async init() {
    let mysql;
    try {
      mysql = require('mysql2/promise');
    } catch (err) {
      throw new Error('MySQL 驱动没装：在项目目录执行  npm i mysql2  然后再启动');
    }

    const conf = this.options;
    this.pool = mysql.createPool({
      host: conf.host,
      port: conf.port,
      user: conf.user,
      password: conf.password,
      database: conf.database,
      charset: conf.charset || 'utf8mb4',
      connectionLimit: conf.connectionLimit || 10,
      waitForConnections: true,
      dateStrings: false
    });

    try {
      await this.pool.query('select 1');
      await this.pool.query('select 1 from quizzes limit 1');
      await this.pool.query('select 1 from scores limit 1');
    } catch (err) {
      throw new Error('连上 MySQL 了，但表还没建：' +
        (err.code === 'ER_NO_SUCH_TABLE' ? '请先执行 backend/schema.mysql.sql' : err.message));
    }
    return this;
  }

  async createQuiz(quiz) {
    await this.pool.query(
      'insert into quizzes (code, title, creator_name, admin_key, questions) values (?, ?, ?, ?, ?)',
      [quiz.code, quiz.title, quiz.creatorName || '', quiz.adminKey, JSON.stringify(quiz.questions)]
    );
    return this.getQuiz(quiz.code);
  }

  async getQuiz(code) {
    const [rows] = await this.pool.query(
      'select code, title, creator_name, admin_key, questions, created_at from quizzes where code = ? limit 1',
      [code]
    );
    return rows.length ? mapQuiz(rows[0]) : null;
  }

  async listQuizzes() {
    const [rows] = await this.pool.query(
      'select code, title, creator_name, admin_key, questions, created_at from quizzes order by created_at desc'
    );
    return rows.map(mapQuiz);
  }

  async deleteQuiz(code) {
    const conn = await this.pool.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query('delete from scores where quiz_code = ?', [code]);
      const [res] = await conn.query('delete from quizzes where code = ?', [code]);
      await conn.commit();
      return res.affectedRows > 0;
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  }

  async addScore(score) {
    await this.pool.query(
      'insert into scores (id, quiz_code, nickname, score, total, duration, answers) values (?, ?, ?, ?, ?, ?, ?)',
      [score.id, score.quizCode, score.nickname, score.score, score.total,
        score.duration === null ? null : score.duration, JSON.stringify(score.answers)]
    );
    return this.getScore(score.id);
  }

  async getScore(id) {
    const [rows] = await this.pool.query(
      'select id, quiz_code, nickname, score, total, duration, answers, created_at from scores where id = ? limit 1',
      [id]
    );
    return rows.length ? mapScore(rows[0]) : null;
  }

  async listScores(quizCode) {
    const [rows] = await this.pool.query(
      'select id, quiz_code, nickname, score, total, duration, answers, created_at ' +
      'from scores where quiz_code = ? order by score desc, duration asc, created_at asc',
      [quizCode]
    );
    return rows.map(mapScore);
  }

  async deleteScore(id) {
    const [res] = await this.pool.query('delete from scores where id = ?', [id]);
    return res.affectedRows > 0;
  }

  async scoreCounts() {
    const [rows] = await this.pool.query(
      'select quiz_code, count(*) as n from scores group by quiz_code'
    );
    const counts = {};
    rows.forEach(function (row) { counts[row.quiz_code] = Number(row.n); });
    return counts;
  }

  async close() {
    if (this.pool) await this.pool.end();
  }
}

module.exports = { MysqlStore };
