/* ===========================================================
   backend/store.js — 存储工厂 + code / adminKey 生成
   =========================================================== */

'use strict';

const crypto = require('crypto');
const { JsonStore } = require('./store-json');
const { MysqlStore } = require('./store-mysql');

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function randomCode(length) {
  const len = Math.max(4, Math.min(6, Number(length) || 4));
  const bytes = crypto.randomBytes(len * 2);
  let out = '';
  for (let i = 0; i < len; i++) out += CODE_CHARS[bytes[i] % CODE_CHARS.length];
  return out;
}

function randomKey() {
  return crypto.randomUUID().replace(/-/g, '').slice(0, 16);
}

function newId() {
  return crypto.randomUUID();
}

/**
 * 生成一个库里不存在的 code（最多试 20 次）
 */
async function uniqueCode(store) {
  for (let i = 0; i < 20; i++) {
    const code = randomCode(4);
    const exists = await store.getQuiz(code);
    if (!exists) return code;
  }
  // 4 位撞太多次，换 6 位
  for (let i = 0; i < 10; i++) {
    const code = randomCode(6);
    const exists = await store.getQuiz(code);
    if (!exists) return code;
  }
  throw new Error('生成答题码失败，请重试');
}

async function createStore(conf) {
  const driver = String((conf && conf.DB && conf.DB.DRIVER) || 'json').toLowerCase();

  if (driver === 'mysql' || driver === 'mariadb') {
    const store = new MysqlStore((conf.DB && conf.DB.MYSQL) || {});
    await store.init();
    return store;
  }

  const store = new JsonStore({ file: conf.DB && conf.DB.FILE });
  await store.init();
  return store;
}

module.exports = { createStore, uniqueCode, randomKey, randomCode, newId };
