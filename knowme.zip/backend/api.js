/* ===========================================================
   backend/api.js — REST API
   -----------------------------------------------------------
   鉴权：
     X-Admin-Key  每套题的管理密钥（创建时返回，前端存在本地）
     X-Super-Key  服务端超级口令（backend/config.js 的 SUPER_KEY）
   成绩由服务端根据 choices 判分，客户端伪造不了分数。
   =========================================================== */

'use strict';

const crypto = require('crypto');
const { uniqueCode, randomKey, newId } = require('./store');

/* ─────────── 小工具 ─────────── */

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(body);
}

function ok(res, data) {
  sendJson(res, 200, data || { ok: true });
}

function fail(res, status, code, message) {
  sendJson(res, status, { error: code, message: message });
}

function safeEqual(a, b) {
  const left = Buffer.from(String(a === undefined || a === null ? '' : a));
  const right = Buffer.from(String(b === undefined || b === null ? '' : b));
  if (left.length !== right.length) return false;
  try {
    return crypto.timingSafeEqual(left, right);
  } catch (e) {
    return false;
  }
}

function readBody(req, limit) {
  return new Promise(function (resolve, reject) {
    const max = limit || 256 * 1024;
    let size = 0;
    const chunks = [];
    req.on('data', function (chunk) {
      size += chunk.length;
      if (size > max) {
        reject(Object.assign(new Error('请求体太大'), { status: 413, code: 'BODY_TOO_LARGE' }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', function () {
      const raw = Buffer.concat(chunks).toString('utf8').trim();
      if (!raw) return resolve({});
      try {
        const parsed = JSON.parse(raw);
        resolve(parsed && typeof parsed === 'object' ? parsed : {});
      } catch (e) {
        reject(Object.assign(new Error('JSON 解析失败'), { status: 400, code: 'BAD_JSON' }));
      }
    });
    req.on('error', reject);
  });
}

function normalizeCode(value) {
  return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
}

function normalizeQuestions(input) {
  if (!Array.isArray(input) || !input.length) {
    throw Object.assign(new Error('至少要有 1 道题'), { status: 400, code: 'BAD_QUESTIONS' });
  }
  if (input.length > 10) {
    throw Object.assign(new Error('最多 10 道题'), { status: 400, code: 'BAD_QUESTIONS' });
  }

  return input.map(function (item, index) {
    const q = String((item && item.q) || '').trim().slice(0, 200);
    const options = Array.isArray(item && item.options) ? item.options : [];
    if (!q) throw Object.assign(new Error('第 ' + (index + 1) + ' 题题干为空'), { status: 400, code: 'BAD_QUESTIONS' });
    if (options.length !== 4) {
      throw Object.assign(new Error('第 ' + (index + 1) + ' 题必须 4 个选项'), { status: 400, code: 'BAD_QUESTIONS' });
    }
    const cleaned = options.map(function (opt) { return String(opt || '').trim().slice(0, 120); });
    if (cleaned.some(function (opt) { return !opt; })) {
      throw Object.assign(new Error('第 ' + (index + 1) + ' 题有空选项'), { status: 400, code: 'BAD_QUESTIONS' });
    }
    const answer = Number(item.answer);
    if (!(answer >= 0 && answer <= 3)) {
      throw Object.assign(new Error('第 ' + (index + 1) + ' 题答案下标不合法'), { status: 400, code: 'BAD_QUESTIONS' });
    }
    return { q: q, options: cleaned, answer: Math.floor(answer) };
  });
}

function publicQuiz(quiz) {
  return {
    code: quiz.code,
    title: quiz.title,
    creatorName: quiz.creatorName || '',
    questions: quiz.questions,
    createdAt: quiz.createdAt
  };
}

function sortScores(list) {
  return list.slice().sort(function (a, b) {
    if (b.score !== a.score) return b.score - a.score;
    const da = a.duration === null || a.duration === undefined ? Number.MAX_SAFE_INTEGER : a.duration;
    const db = b.duration === null || b.duration === undefined ? Number.MAX_SAFE_INTEGER : b.duration;
    if (da !== db) return da - db;
    return new Date(a.createdAt) - new Date(b.createdAt);
  });
}

/* ─────────── 主入口 ─────────── */

async function handleApi(req, res, pathname, query, store, conf) {
  const method = req.method || 'GET';

  // 可选跨域（前后端不同域时才需要）
  if (conf.CORS_ORIGIN) {
    res.setHeader('Access-Control-Allow-Origin', conf.CORS_ORIGIN);
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Admin-Key, X-Super-Key');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Vary', 'Origin');
  }
  if (method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  const parts = pathname.split('/').filter(Boolean); // ['api', ...]
  const seg = parts.slice(1);

  try {
    /* GET /api/health */
    if (seg[0] === 'health' && seg.length === 1) {
      return ok(res, {
        ok: true,
        driver: store.driver || 'json',
        quizzes: (await store.listQuizzes()).length,
        time: new Date().toISOString()
      });
    }

    /* POST /api/quizzes — 创建 */
    if (seg[0] === 'quizzes' && seg.length === 1 && method === 'POST') {
      const body = await readBody(req, conf.MAX_BODY_BYTES);
      const questions = normalizeQuestions(body.questions);
      const title = String(body.title || '').trim().slice(0, 120) || '你是不是最懂我';
      const creatorName = String(body.creatorName || '').trim().slice(0, 60);

      const code = await uniqueCode(store);
      const adminKey = randomKey();
      const quiz = await store.createQuiz({
        code: code,
        title: title,
        creatorName: creatorName,
        adminKey: adminKey,
        questions: questions,
        createdAt: new Date().toISOString()
      });

      return ok(res, { code: quiz.code, adminKey: quiz.adminKey, createdAt: quiz.createdAt });
    }

    /* GET /api/quizzes/:code — 答题用（不含 admin_key） */
    if (seg[0] === 'quizzes' && seg.length === 2 && method === 'GET') {
      const quiz = await store.getQuiz(normalizeCode(seg[1]));
      if (!quiz) return fail(res, 404, 'QUIZ_NOT_FOUND', '题目不存在或已删除');
      return ok(res, publicQuiz(quiz));
    }

    /* POST /api/quizzes/:code/scores — 提交成绩（服务端判分） */
    if (seg[0] === 'quizzes' && seg.length === 3 && seg[2] === 'scores' && method === 'POST') {
      const code = normalizeCode(seg[1]);
      const quiz = await store.getQuiz(code);
      if (!quiz) return fail(res, 404, 'QUIZ_NOT_FOUND', '题目不存在或已删除');

      const body = await readBody(req, conf.MAX_BODY_BYTES);
      const choices = Array.isArray(body.choices) ? body.choices.map(Number) : [];
      if (choices.length !== quiz.questions.length) {
        return fail(res, 400, 'BAD_CHOICES', '作答数量和题目数量不一致');
      }
      if (choices.some(function (c) { return !(c >= 0 && c <= 3); })) {
        return fail(res, 400, 'BAD_CHOICES', '选项下标不合法');
      }

      const answers = quiz.questions.map(function (item, i) {
        return Number(item.answer) === choices[i] ? 1 : 0;
      });
      const score = answers.reduce(function (sum, v) { return sum + v; }, 0);

      let duration = Number(body.duration);
      if (!isFinite(duration) || duration < 0) duration = 0;
      duration = Math.max(Number(conf.MIN_DURATION) || 0, Math.min(Number(conf.MAX_DURATION) || 86400, Math.round(duration)));

      const nickname = String(body.nickname || '').trim().slice(0, 24) || '匿名';

      const row = await store.addScore({
        id: newId(),
        quizCode: code,
        nickname: nickname,
        score: score,
        total: quiz.questions.length,
        duration: duration,
        answers: answers,
        createdAt: new Date().toISOString()
      });

      return ok(res, {
        ok: true,
        id: row.id,
        score: score,
        total: quiz.questions.length,
        answers: answers,
        duration: duration
      });
    }

    /* GET /api/quizzes/:code/ranking?limit=20 */
    if (seg[0] === 'quizzes' && seg.length === 3 && seg[2] === 'ranking' && method === 'GET') {
      const code = normalizeCode(seg[1]);
      const quiz = await store.getQuiz(code);
      if (!quiz) return fail(res, 404, 'QUIZ_NOT_FOUND', '题目不存在或已删除');

      const limit = Math.max(1, Math.min(200, Number(query.get('limit')) || conf.RANKING_LIMIT || 20));
      const all = sortScores(await store.listScores(code));
      const items = all.slice(0, limit).map(function (row) {
        return {
          id: row.id,
          nickname: row.nickname,
          score: row.score,
          total: row.total,
          duration: row.duration,
          createdAt: row.createdAt
        };
      });
      return ok(res, { items: items, total: all.length });
    }

    /* 以下都需要管理密钥 */
    if (seg[0] === 'quizzes' && seg.length >= 3 && seg[2] === 'scores') {
      const code = normalizeCode(seg[1]);
      const quiz = await store.getQuiz(code);
      if (!quiz) return fail(res, 404, 'QUIZ_NOT_FOUND', '题目不存在或已删除');

      if (!safeEqual(req.headers['x-admin-key'], quiz.adminKey)) {
        return fail(res, 403, 'BAD_KEY', '管理密钥不对');
      }

      /* GET /api/quizzes/:code/scores */
      if (seg.length === 3 && method === 'GET') {
        return ok(res, { items: sortScores(await store.listScores(code)) });
      }

      /* DELETE /api/quizzes/:code/scores/:id */
      if (seg.length === 4 && method === 'DELETE') {
        const removed = await store.deleteScore(seg[3]);
        if (!removed) return fail(res, 404, 'SCORE_NOT_FOUND', '这条成绩不存在');
        return ok(res, { ok: true });
      }
    }

    /* POST /api/admin/login — 校验超级口令 */
    if (seg[0] === 'admin' && seg[1] === 'login' && method === 'POST') {
      if (!safeEqual(req.headers['x-super-key'], conf.SUPER_KEY)) {
        return fail(res, 403, 'SUPER_KEY_INVALID', '超级口令不对');
      }
      return ok(res, { ok: true, driver: store.driver || 'json' });
    }

    /* /api/admin/quizzes 系列 */
    if (seg[0] === 'admin' && seg[1] === 'quizzes') {
      if (!safeEqual(req.headers['x-super-key'], conf.SUPER_KEY)) {
        return fail(res, 403, 'SUPER_KEY_INVALID', '超级口令不对（服务端 backend/config.js 的 SUPER_KEY）');
      }

      /* GET /api/admin/quizzes */
      if (seg.length === 2 && method === 'GET') {
        const [items, counts] = await Promise.all([store.listQuizzes(), store.scoreCounts()]);
        return ok(res, {
          items: items.map(function (quiz) {
            return Object.assign(publicQuiz(quiz), { adminKey: quiz.adminKey });
          }),
          counts: counts,
          driver: store.driver || 'json'
        });
      }

      /* DELETE /api/admin/quizzes/:code */
      if (seg.length === 3 && method === 'DELETE') {
        const code = normalizeCode(seg[2]);
        const removed = await store.deleteQuiz(code);
        if (!removed) return fail(res, 404, 'QUIZ_NOT_FOUND', '题目不存在');
        return ok(res, { ok: true });
      }
    }

    return fail(res, 404, 'NOT_FOUND', '接口不存在：' + pathname);
  } catch (err) {
    if (err && err.status) return fail(res, err.status, err.code || 'BAD_REQUEST', err.message);
    console.error('[api] ' + (err && err.stack ? err.stack : err));
    return fail(res, 500, 'INTERNAL', '服务器内部错误');
  }
}

module.exports = { handleApi: handleApi };
