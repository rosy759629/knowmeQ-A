/* ===========================================================
   backend/config.js — 服务端配置（只跑在服务器上，前端拿不到）
   -----------------------------------------------------------
   改完要重启 node / systemctl restart knowme
   =========================================================== */

'use strict';

const path = require('path');

module.exports = {
  /* 数据库驱动
     'json'  = 零依赖，写 data/db.json（默认，开箱即用，几千条没问题）
     'mysql' = 连你服务器上已有的 MySQL / MariaDB，需要 npm i mysql2
     也可以用环境变量 KM_DB=mysql 覆盖 */
  DB: {
    DRIVER: process.env.KM_DB || 'json',

    /* json 驱动的数据文件 */
    FILE: process.env.KM_DB_FILE || path.join(__dirname, '..', 'data', 'db.json'),

    /* MySQL 连接（DRIVER=mysql 时才用） */
    MYSQL: {
      host: process.env.MYSQL_HOST || '127.0.0.1',
      port: Number(process.env.MYSQL_PORT) || 3306,
      user: process.env.MYSQL_USER || 'knowme',
      password: process.env.MYSQL_PASSWORD || '',
      database: process.env.MYSQL_DATABASE || 'knowme',
      charset: 'utf8mb4',
      connectionLimit: 10
    }
  },

  /* 服务端超级口令：列全部题目 / 删整套题 都要它
     ⚠️ 这个值只在服务器上，浏览器拿不到——
        所以即使别人改了 js/config.js 的 SUPER_KEY，也删不掉数据。
     建议：改成随机串，用环境变量 KM_SUPER_KEY 传，别写死在文件里 */
  SUPER_KEY: process.env.KM_SUPER_KEY || 'CHANGE-ME-SUPER',

  /* 排行榜默认返回条数 */
  RANKING_LIMIT: 20,

  /* 前后端不同域时才需要（比如页面在 nginx、API 在别的端口）
     同源部署留空即可；填了就允许这个来源跨域访问 /api */
  CORS_ORIGIN: process.env.KM_CORS || '',

  /* 提交成绩的合法耗时范围（秒），防止乱传 */
  MIN_DURATION: 0,
  MAX_DURATION: 86400,

  /* 单次请求体上限 */
  MAX_BODY_BYTES: 256 * 1024
};
