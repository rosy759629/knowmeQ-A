/* ===========================================================
   backend/store-json.js — 零依赖文件数据库（默认驱动）
   -----------------------------------------------------------
   数据全在内存，每次写入原子落盘（写 .tmp 再 rename），
   写入串行化，避免并发丢数据。
   适合单机、几千套题/几万条成绩的规模。
   =========================================================== */

'use strict';

const fs = require('fs');
const path = require('path');

function clone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

class JsonStore {
  constructor(options) {
    const opts = options || {};
    this.file = opts.file || path.join(__dirname, '..', 'data', 'db.json');
    this.data = { quizzes: [], scores: [] };
    this.byCode = new Map();
    this.writeChain = Promise.resolve();
    this.lastError = null;
  }

  async init() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });

    let raw = null;
    try {
      raw = fs.readFileSync(this.file, 'utf8');
    } catch (err) {
      if (err.code !== 'ENOENT') throw err;
    }

    if (raw) {
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch (err) {
        // 文件坏了不要直接覆盖，先备份再重建，避免丢数据
        const backup = this.file + '.broken-' + Date.now();
        fs.renameSync(this.file, backup);
        console.error('[store] db.json 解析失败，已备份到 ' + backup);
        parsed = {};
      }
      this.data.quizzes = Array.isArray(parsed.quizzes) ? parsed.quizzes : [];
      this.data.scores = Array.isArray(parsed.scores) ? parsed.scores : [];
    }

    this.reindex();
    if (!raw) await this.persist();
    return this;
  }

  reindex() {
    this.byCode = new Map();
    this.data.quizzes.forEach((quiz) => this.byCode.set(quiz.code, quiz));
  }

  persist() {
    const snapshot = JSON.stringify(this.data, null, 0);
    this.writeChain = this.writeChain
      .then(() => this.atomicWrite(snapshot))
      .catch((err) => {
        this.lastError = err;
        console.error('[store] 写入失败：' + err.message);
      });
    return this.writeChain;
  }

  atomicWrite(text) {
    return new Promise((resolve, reject) => {
      const tmp = this.file + '.tmp';
      fs.writeFile(tmp, text, 'utf8', (err) => {
        if (err) return reject(err);
        fs.rename(tmp, this.file, (err2) => (err2 ? reject(err2) : resolve()));
      });
    });
  }

  /* ─────────── quizzes ─────────── */

  async createQuiz(quiz) {
    const row = clone(quiz);
    this.data.quizzes.push(row);
    this.byCode.set(row.code, row);
    await this.persist();
    return clone(row);
  }

  async getQuiz(code) {
    const found = this.byCode.get(code);
    return found ? clone(found) : null;
  }

  async listQuizzes() {
    return clone(this.data.quizzes).sort(function (a, b) {
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
  }

  async deleteQuiz(code) {
    const before = this.data.quizzes.length;
    this.data.quizzes = this.data.quizzes.filter(function (q) { return q.code !== code; });
    this.data.scores = this.data.scores.filter(function (s) { return s.quizCode !== code; });
    this.byCode.delete(code);
    await this.persist();
    return before !== this.data.quizzes.length;
  }

  /* ─────────── scores ─────────── */

  async addScore(score) {
    const row = clone(score);
    this.data.scores.push(row);
    await this.persist();
    return clone(row);
  }

  async listScores(quizCode) {
    return clone(this.data.scores.filter(function (s) { return s.quizCode === quizCode; }));
  }

  async deleteScore(id) {
    const before = this.data.scores.length;
    this.data.scores = this.data.scores.filter(function (s) { return s.id !== id; });
    await this.persist();
    return before !== this.data.scores.length;
  }

  async scoreCounts() {
    const counts = {};
    this.data.scores.forEach(function (s) {
      counts[s.quizCode] = (counts[s.quizCode] || 0) + 1;
    });
    return counts;
  }

  async close() {
    await this.writeChain;
  }
}

module.exports = { JsonStore };
