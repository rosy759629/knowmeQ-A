# 你是不是最懂我 · 默契测试

出题人写一套关于自己的选择题 → 生成链接 → 朋友打开就答，答对有彩带和证书 → 出题人打开管理链接看排行榜，看谁最懂自己。

纯静态前端（原生 HTML/CSS/JS，无构建），数据默认存 localStorage，一行配置即可切到 Supabase 跨设备。

---

## 1. 30 秒跑起来

### 方式 A：双击 `启动.bat`（推荐）

```
双击  启动.bat
```

会弹出一个黑色窗口，自动打开浏览器到 `http://localhost:8000/`。
窗口里还会打印一个 `192.168.x.x` 的地址 —— 手机连同一个 Wi-Fi 就能直接访问。

- **这个窗口不能关**，关掉 = 服务器停止。要停止就按 `Ctrl+C` 或直接关窗口。
- 8000 端口被占用会自动顺延到 8001、8002……（窗口里会打印实际地址）。
- 它优先用 Node.js（跑 `server.js`），没装 Node 再试 Python，都没有就直接打开 `index.html`。

### 方式 B：命令行启动

```bash
node server.js                  # 自动开浏览器
node server.js --no-open        # 只启动（服务器上用这个）
set PORT=9000 && node server.js # 换端口
```

> ⚠️ 后台目录 `/manage` 只有 `server.js` 认识（它会内部重写成 `index.html`）。
> 换成 `python -m http.server` 这类普通静态服务器时，`/manage` 会 404 —— 那种情况下用 `/?super` 进后台。

### 方式 C：直接双击 `index.html`

`file://` 下也能完整体验本地模式（题库、答题、证书都正常），
只是「复制链接」出来的是 `file:///D:/...` 这种地址，**发给朋友是打不开的**，
也没法用手机测。所以想分享就用方式 A。
后台在这种情况下只能用 `index.html?super` 打开。

打开后：

1. 点「创建我的题目」→ 填 1-10 道题 → 生成
2. 弹窗里拿到 **答题码 / 答题链接 / 管理链接**（管理链接要自己收好）
3. 把答题链接发给朋友 → 朋友答题 → 结果页看排行榜 + 下载证书
4. 你打开管理链接 → 排行榜 / 每题正确率 / 导出 CSV
5. 管理后台：`http://localhost:8000/manage`（路径在 [js/config.admin.js](js/config.admin.js) 里改）

---

## 2. 目录结构

```
├── index.html              # 单页入口（5 个视图都在这里）
├── 启动.bat                # 双击启动本地预览（Windows）
├── server.js               # 零依赖静态服务器（认识后台目录，可直接上服务器）
├── css/
│   ├── base.css            # 变量、重置、按钮、卡片、弹窗、toast、动画
│   ├── home.css            # 首页
│   ├── quiz.css            # 答题页（选项、对错标记、抖动、进度条）
│   ├── result.css          # 结果页（得分、排行榜、证书）
│   ├── admin.css           # 单题管理页（表格、正确率条、密钥门）
│   └── super.css           # 超级后台（搜索条、详情弹窗、提示条）
├── js/
│   ├── config.js           # ★ 站点配置：STORAGE_MODE / Supabase / 音效 / SUPER_KEY
│   ├── config.admin.js     # ★ 后台配置：ADMIN_PATH / 页脚入口 / 登录态时长
│   ├── utils.js            # 随机码、存储、时间格式化、DOM 助手、弹窗、音效、彩带
│   ├── editor.js           # 题目编辑器（首页出题 / 超级后台代建 共用）
│   ├── db.js               # 数据层抽象（local / cloud 同一套 API）
│   ├── router.js           # 路由：后台走目录，其余走 query string
│   ├── home.js             # 创建题目 / 输入答题码 / 我的题目
│   ├── quiz.js             # 答题流程 + 对错特效 + 计时 + 交卷
│   ├── result.js           # 得分动画 + 排行榜高亮 + 证书
│   ├── admin.js            # 单题管理页：密钥校验 + 排行榜 + 正确率 + CSV
│   ├── super.js            # 超级管理员后台（全部题目 / 代建 / 删除）
│   └── certificate.js      # Canvas 证书绘制与下载
├── backend/                # ← 服务端（只有 node 用，浏览器不加载）
│   ├── config.js           # ★ 服务端配置：数据库驱动 / MySQL 连接 / SUPER_KEY
│   ├── api.js              # REST API（/api/*）+ 鉴权 + 服务端判分
│   ├── store.js            # 存储工厂 + code / adminKey 生成
│   ├── store-json.js       # json 文件驱动（零依赖，默认）
│   ├── store-mysql.js      # MySQL / MariaDB 驱动（需 npm i mysql2）
│   └── schema.mysql.sql    # MySQL 建表脚本
├── assets/                 # 可选资源（底图 / 音效），见 assets/README.md
├── supabase/schema.sql     # （可选）改用 Supabase 时的建表 + RLS
├── deploy/                 # Ubuntu 部署：nginx.conf / knowme.service / 同步脚本
├── data/                   # json 驱动的数据文件（自动创建，已 gitignore）
├── tests/local-db.test.js  # 数据层逻辑自测（node 直接跑）
├── tests/api.test.js       # 服务端 API 自测（真起服务 + fetch）
├── tests/dom.test.js       # 页面流程自测（需要 jsdom）
└── tests/dom-api.test.js   # 前端 ↔ 真后端 全流程（需要 jsdom）
```

**为什么没用 ES module？** 为了让 `index.html` 双击就能跑（`file://` 下 `import` 会被 CORS 拦），
所以所有脚本按顺序用普通 `<script>` 加载，统一挂在 `window.KM` 命名空间上。

---

## 3. 文档第 13 节的 6 个决策项：已按推荐值定稿

| # | 决策 | 取值 | 想改的话 |
|---|---|---|---|
| 1 | 存储模式 | **默认 `local` 演示；上线用 `api`（自己服务器的数据库，json 或 MySQL）；Supabase 作为备选保留** | `js/config.js` → `STORAGE_MODE` |
| 2 | 题目数量 | 默认 1 题，最多 **10 题** | `MAX_QUESTIONS` |
| 3 | 排行榜排序 | `score DESC, duration ASC, created_at ASC` | `db.js` 的 `sortScores`（`utils.js`）与 SQL 索引 |
| 4 | 证书 | 页面展示 + **下载 PNG**，无底图时用**渐变** | `CERT_BG: 'assets/cert-bg.png'` 可换底图 |
| 5 | 主题色 | **糖果紫绿**：`#6C5CE7` / `#00B894` / `#E17055` | `css/base.css` 的 `:root` 变量 |
| 6 | 音效 | **Web Audio 实时合成**（零资源、可离线），支持静音开关 | `SOUND_MODE: 'files'` 换成 mp3 |

### 已覆盖的里程碑

- **M1** 骨架：query 路由、创建表单（动态增删题）、localStorage 存题、答题基础
- **M2** 特效：对勾/叉子描边动画、confetti、合成音效、进度条、切题淡入淡出、键盘 A-D/1-4
- **M3** 结果：得分 0→N 滚动、评价文案五档、排行榜（高亮自己 + 逐行淡入）、排名百分比
- **M4** 证书：1200×850 Canvas、渐变装饰、证书编号 hash、PNG 下载
- **M5** 管理：key 校验 + 本机放行、排行榜、每题正确率条形图、CSV 导出、删除单条（本地）
- **M6** 上云：Supabase 数据层 + RLS 脚本 + 加载失败重试（缺的只是你的项目密钥）
- **M7** 打磨：移动端单列、16px 防缩放、空状态、错误页、加载态、SEO/OG meta、`prefers-reduced-motion`

---

## 4. （可选）改用 Supabase 云端

> 如果你有自己的服务器，**跳过这节，看 [第 11 节](#11-用自己服务器上的数据库api-模式)**。
> Supabase 是给"没有服务器"或者不想自己维护后端的人准备的，两条路二选一。

### 4.1 建表

1. 打开 [supabase.com](https://supabase.com) 新建一个免费项目
2. 左边 **SQL Editor** → **New query** → 把 `supabase/schema.sql` 整段粘进去 → **Run**
3. 记下 **Project Settings → API** 里的 `Project URL` 和 `anon public` key

### 4.2 填配置

```js
// js/config.js
STORAGE_MODE: 'cloud',
SUPABASE_URL: 'https://xxxxxxxx.supabase.co',
SUPABASE_ANON_KEY: 'eyJhbGciOi...',   // anon public key，不是 service_role
```

### 4.3 为什么要 RLS

前端直连数据库，浏览器里带着 anon key 谁都能看到。所以：
- `quizzes` / `scores` 只开放 `select` 和 `insert`，**没有** `update` / `delete`
- 管理页的删除按钮在云端模式下自动隐藏（要删请去 Supabase 控制台）
- `admin_key` 存在 `quizzes` 表里、可被读取，这是 v1 已知风险（文档 4.4 已标注）；
  想收紧见 `schema.sql` 末尾的 v2 方案（拆表 + `security definer` RPC）

### 4.4 跨设备验证清单

- [ ] A 电脑创建 → B 手机打开答题链接，能正常答题
- [ ] B 提交后，A 打开管理链接能看到这条成绩
- [ ] A 的「我的题目」里能看到这套题（前提是同一浏览器；换设备用带 key 的管理链接）
- [ ] Supabase 表里 `scores.answers` 是 `[1,0,1]` 这样的数组

---

## 5. 部署

纯静态，任何静态托管都行（都是相对路径，放子目录也没问题）：

| 平台 | 操作 |
|---|---|
| **Vercel** | 拖文件夹到 vercel.com，或 `npx vercel --prod` |
| **Netlify** | app.netlify.com → 把整个目录拖进 Drop 区 |
| **GitHub Pages** | 推到仓库 → Settings → Pages → 选分支根目录 |
| **Cloudflare Pages** | 连仓库，build command 留空，输出目录填 `.` |

部署后**记得改 `js/config.js`**：云端模式要填线上 Supabase 配置。
（`js/config.js` 会被公开访问，这没关系——放进去的本来就是 anon public key。）

---

## 6. 数据与隐私

只收昵称，不收手机号/邮箱；证书在本地 Canvas 生成，不上传。

本地模式用的 localStorage key：

| key | 内容 |
|---|---|
| `km.quiz.<CODE>` | 题目本体（含 adminKey） |
| `km.scores.<CODE>` | 该题所有作答记录 |
| `km.myCodes` | 本机创建过的 code 列表（进管理页的凭据） |
| `km.lastResult.<CODE>` | 我最近一次的成绩（结果页要显示） |
| `km.submitted.<CODE>` | 已答过的标记（防重复提交） |
| `km.pending` | 提交失败的暂存队列（联网后可重试） |
| `km.nickname` / `km.creator` | 昵称 |
| `km.muted` | 静音开关 |

**清缓存 = 本地模式下的数据全没**。要长期保存/分享，请切云端。

---

## 7. 常见问题

**Q：朋友打开链接说「题目不存在」？**
本地模式下题目只在你那台电脑的浏览器里，别人肯定看不到。两种解法：切 Supabase（推荐），
或者把整套题的目标环境跑在同一浏览器里自测。

**Q：管理链接丢了怎么办？**
- 同一台电脑/浏览器：直接打开 `?code=XXXX&admin`，会自动放行（`km.myCodes` 里有记录）
- 换设备：只能找回 `admin_key`（本地模式在 `km.quiz.XXXX` 里，云端在 `quizzes.admin_key` 列）

**Q：macOS 上音效没声音？**
浏览器要求先有用户交互。第一次点击选项时才会创建 AudioContext，这是正常的；检查右上角静音开关。

**Q：能不能改题目？**
v1 不支持编辑（RLS 也没开 update），只能重新出一套。

**Q：证书字体想换？**
`js/certificate.js` 顶部的 `FONT` 常量；中文建议保留系统字体栈，跨平台最稳。

---

## 8. 自测

### 8.1 数据层（零依赖）

```bash
node tests/local-db.test.js
```

25 个用例：code 生成/校验、建题取题、排行榜排序（分数→用时→时间）、每题正确率、删除、
提交失败补偿队列、评价文案边界、CSV 转义、云端缺配置时的可读报错，
以及超级后台的「列出全部题目 / 作答人数统计 / 删除整套题连带清理 / 代建不进我的题目」。

### 8.2 页面流程（可选，需要 jsdom）

```bash
npm i jsdom          # 会生成 node_modules / package.json，已加进 .gitignore
node tests/dom.test.js
```

29 个用例：把 `index.html` + 12 个脚本真的跑起来，走
**创建题目 → 填答 → 对错特效 class → 交卷 → 结果页分数/排行榜/证书 → 单题管理页表格/正确率/密钥门
→ 后台口令门/列表/搜索/详情/代建/删除 → `/manage` 目录路由与站内跳转**，
并断言「运行过程中没有未捕获的 JS 错误」。Canvas 用假 2D 上下文，所以它验的是逻辑不是像素。

### 8.3 JS 语法检查

```bash
for f in js/*.js; do node --check "$f"; done
```

### 8.4 浏览器手动回归清单

- [ ] 首页输入错误码 → 提示格式问题；输不存在的码 → 提示找不到
- [ ] 创建 0 题 / 空选项 / 重复选项 → 有拦截提示
- [ ] 答题：答对绿+✓+彩带+叮；答错红+抖动+✗+正确答案高亮+噗；1.2s 后自动切题
- [ ] 中途刷新 → 重新开始（不做断点续答，v1 取舍）
- [ ] 交卷后结果页：分数滚动、排行榜高亮自己、证书能下载
- [ ] 已答过再进答题页 → 出现「已答过」卡，可看成绩或再答一次
- [ ] 管理页：错 key 被拦、正确 key 放行、CSV 用 Excel 打开中文不乱码
- [ ] 手机宽度 375px：选项单列、字号不触发缩放、表格可横向滑

---

## 9. 管理后台（目录可配置）

> 需求原文：「查看每一个人的题目，可以创建或者删除」。

后台是**一个可配置的目录**，不是固定路径。配置在 [js/config.admin.js](js/config.admin.js)：

```js
window.KM_ADMIN_CONFIG = {
  ADMIN_PATH: '/manage',      // ← 改这里就换后台地址
  SHOW_FOOTER_LINK: true,     // 首页页脚要不要挂「管理后台」入口
  SESSION_MINUTES: 120        // 登录态多久失效
};
```

打开方式：

```
http://localhost:8000/manage        ← 默认
```

默认口令：`CHANGE-ME-SUPER`（在 `js/config.js` 的 `SUPER_KEY` 里）

> 上线后建议把 `ADMIN_PATH` 改成别人猜不到的（比如 `/boss-9x2k`），
> 并把 `SHOW_FOOTER_LINK` 设成 `false`。改完**重启 node 服务**即可生效。
> `?super` 仍然能用（同一口令），方便你在没配服务器时调试。

### 9.1 能做什么

| 功能 | 说明 |
|---|---|
| 看全部题目 | 表格列出 答题码 / 标题 / 出题人 / 题数 / 作答人数 / 创建时间，按时间倒序 |
| 搜索 | 按答题码、标题、出题人实时过滤 |
| 看题面 | 点「详情」看每道题的全部选项，**正确答案高亮**，还能复制答题链接 / 管理链接 |
| 代建 | 点「新建题目」在后台直接出一套，可以填任意出题人昵称；不会污染你自己的「我的题目」 |
| 删除 | 整套删（连带所有成绩），二次确认后不可撤销 |
| 进单题后台 | 每行「管理」直接带着 `admin_key` 跳进那套题的排行榜页 |

登录态存在 `sessionStorage`，关掉浏览器就要重新输口令。

### 9.2 必须先看懂的一件事：数据范围

| 模式 | 你能看到的"全部题目" | 原因 |
|---|---|---|
| `STORAGE_MODE: 'local'`（默认） | **只有这台电脑、这个浏览器里的题目** | 数据存在各自浏览器的 localStorage，跨设备物理隔离，前端拿不到别人的 |
| `STORAGE_MODE: 'cloud'` | **Supabase 里所有人的题目** | 大家共用一张 `quizzes` 表 |

所以想要「看到每个人的题目」，**必须切云端**（[第 4 节](#4-切到云端跨设备可分享)）。
本地模式下这个后台依然有用：能看本机所有题目、代建、删掉测试数据。

### 9.3 安全模型（重要）

超级后台的"安全"分两层：

| 层 | 挡什么 | 强度 |
|---|---|---|
| 前端口令（`config.js` 的 `SUPER_KEY`） | 挡误入、挡随手点 | **弱**：任何人都能打开 `config.js` 看到口令，只是门帘 |
| 数据库 RPC（`super_delete_quiz`） | 挡真正的破坏 | **强**：口令以 sha256 存在 `super_config` 表，该表 RLS 全禁 + 权限收回，只有 definer 函数能比对；删除动作在数据库里校验，前端拿不到 delete 权限 |

所以：

- **云端模式**：即使别人改了前端口令，只要数据库里的哈希不是他的口令，删除就会失败（报 `SUPER_KEY_INVALID`）。
- **本地模式**：没有服务端，前端口令就是全部防线——数据本来就在你机器上，这属于"自己的数据自己管"，可接受。
- **上线前必做**：
  1. 改 `js/config.js` 的 `SUPER_KEY`
  2. 在 Supabase SQL Editor 里跑 `schema.sql` 末尾那条 `update public.super_config ...` 把哈希改成同一个口令
  > 两处不一致时，后台能进、但删除会失败并提示"超级口令不对"。这是故意的。

### 9.4 相关的库函数

| 函数 | 作用 |
|---|---|
| `KM.db.listAllQuizzes()` | 本地扫 `km.quiz.*`；云端 `select quizzes`（limit 2000） |
| `KM.db.getScoreCounts()` | 每套题的作答人数（云端自动分页，最多 1 万条） |
| `KM.db.deleteQuiz(code)` | 本地删 `km.quiz.*` / `km.scores.*` / 本机记录 / 待补交队列 / 上次成绩；云端走 RPC |
| `KM.db.createQuiz(values, {skipMyCodes:true})` | 代建，不写进 `km.myCodes` |

---

## 10. 部署到 Ubuntu 服务器

> **最快路径（推荐）**：代码传上去之后，在服务器上跑一条命令，脚本会把 Node、systemd、nginx、随机超级口令全配好：
>
> ```bash
> cd /var/www/knowme && sudo bash deploy/install-ubuntu.sh
> ```
>
> Windows 上传用：`powershell -ExecutionPolicy Bypass -File deploy\upload.ps1 -Server root@你的IP`
>
> 下面是手动分步版，想搞清楚每一步在做什么就看这里。

目标形态：

```
浏览器 ──HTTPS──> nginx :443 ──反代──> node server.js 127.0.0.1:8080 ──> 静态文件
                                        └─ 认识 /manage（后台目录）
```

### 10.1 服务器准备

```bash
# Node 20（22 也行）+ nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt update && sudo apt install -y nodejs nginx

# 代码目录
sudo mkdir -p /var/www/knowme
```

把项目传上去（本地执行，二选一）：

```bash
# A. rsync（推荐，Windows 上用 git-bash / WSL）
rsync -avz --delete --exclude node_modules --exclude tests ./ user@你的服务器:/var/www/knowme/

# B. 或者用现成脚本
chmod +x deploy/upload.example.sh
./deploy/upload.example.sh user@你的服务器
```

```bash
# 服务器上修正属主
sudo chown -R www-data:www-data /var/www/knowme
```

### 10.2 改配置（**两处，别漏**）

**① `js/config.admin.js`** —— 后台目录

```js
ADMIN_PATH: '/boss-9x2k',    // 改成只有你知道的路径
SHOW_FOOTER_LINK: false,     // 别在页面上挂「管理后台」招牌
```

**② `js/config.js`** —— 数据源

```js
STORAGE_MODE: 'api',          // ← 走你自己服务器上的数据库（第 11 节）
SUPER_KEY: '随便一个口令'      // api 模式下这只是前端口令，真正的在服务端
```

> ⚠️ **服务器上不要用 `local` 模式**：local 模式下每个访客的题目都存在**他自己浏览器**里，
> 互相看不见，你的后台也看不到——那这套网站就变成"单机玩具"了。要跨设备、要看全部题目，必须 `api`。

数据库怎么配、MySQL 还是 json 文件，见 [第 11 节](#11-用自己服务器上的数据库api-模式)。

### 10.3 让服务常驻（systemd）

```bash
sudo cp deploy/knowme.service /etc/systemd/system/
which node                      # 记下路径，比如 /usr/bin/node
sudo nano /etc/systemd/system/knowme.service   # 把 ExecStart 的 node 路径改对

# json 驱动：数据目录要可写（MySQL 驱动不需要）
sudo mkdir -p /var/www/knowme/data
sudo chown -R www-data:www-data /var/www/knowme/data

sudo systemctl daemon-reload
sudo systemctl enable --now knowme
sudo systemctl status knowme
```

自检（还没配 nginx 也能验）：

```bash
curl -I http://127.0.0.1:8080/            # 200
curl -I http://127.0.0.1:8080/manage      # 200，不是 404
```

### 10.4 nginx 反代 + HTTPS

```bash
sudo cp deploy/nginx.conf /etc/nginx/sites-available/knowme
sudo nano /etc/nginx/sites-available/knowme     # 改 server_name 为你的域名

sudo ln -sf /etc/nginx/sites-available/knowme /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# 免费证书（顺带自动配好 443）
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d 你的域名
```

nginx 只做反代，**不需要知道后台路径**——`server.js` 会读 `config.admin.js`。
所以以后改 `ADMIN_PATH`，只要 `sudo systemctl restart knowme`。

> 想省掉 Node 常驻？`deploy/nginx.conf` 末尾有"纯静态方案 B"，
> 但要额外配两条 `rewrite` 把 `/manage` 映射回 `index.html`，且必须和 `ADMIN_PATH` 保持一致。

### 10.5 上线检查清单

- [ ] `https://域名/` 首页正常，样式没丢
- [ ] `https://域名/manage` 出后台登录页（**不是 404，也不是首页**）
- [ ] 口令已改：前端 `js/config.js` 的 `SUPER_KEY` + 服务端 `backend/config.js` 的 `SUPER_KEY` 都换了
- [ ] `curl http://127.0.0.1:8080/api/health` 能返回 `{"ok":true,"driver":"..."}`
- [ ] 用错误口令点删除 → 报"超级口令不对"（说明数据库校验真的生效了）
- [ ] 创建一套题 → 手机打开答题链接答完 → 后台列表里能看到这条成绩
- [ ] `sudo systemctl restart knowme` 后服务自动恢复；重启服务器也能自动起来

### 10.6 常见问题

| 现象 | 原因 / 处理 |
|---|---|
| `/manage` 返回 404 | ① node 没起来（`curl 127.0.0.1:8080` 试）② 用了纯静态方案但没配 rewrite |
| `/manage` 能开但样式全丢 | 地址带了尾斜杠 `/manage/` 且服务端没剥前缀 → 用 `/manage` 访问，或按 `deploy/nginx.conf` 配 |
| 改了 `ADMIN_PATH` 没生效 | `server.js` 启动时读一次配置，必须 `systemctl restart knowme` |
| 后台"看不到别人的题目" | 还在 `local` 模式 |
| 端口被占 | 改 `Environment=PORT=8081`，同时改 nginx 的 `proxy_pass` |
| 看日志 | `journalctl -u knowme -f` |

### 10.7 走 GitHub 部署和更新（推荐）

比 scp 省事：以后改完 `git push`，服务器上一条命令更新。

**① 本地推到 GitHub**（本机需装 [Git for Windows](https://git-scm.com/download/win)）

```bash
cd D:/z张赟博/projects/knowme
git init
git add .
git status --short          # 先看一眼，不该出现 data/、node_modules/
git commit -m "init: 默契测试站"
git branch -M main
git remote add origin https://github.com/你的用户名/knowme.git
git push -u origin main
```

**② 服务器拉下来并部署**

```bash
sudo apt install -y git
sudo mkdir -p /var/www && cd /var/www
sudo git clone https://github.com/你的用户名/knowme.git knowme
cd knowme
sudo bash deploy/install-ubuntu.sh
```

私有仓库要带 token（fine-grained，只给这一个仓库的读权限）：

```bash
sudo git clone https://<token>@github.com/你的用户名/knowme.git knowme
```

**③ 以后更新**

```bash
cd /var/www/knowme
sudo bash deploy/update.sh
```

`update.sh` 会：`git pull --ff-only`（有本地改动会拒绝，不会冲掉服务器上的东西）→ 修正权限 → 重启服务 → 自检 `/api/health`。

**注意两件事：**

- 仓库里的 `.gitattributes` 已经把 `*.sh` 固定成 LF。**如果 `.sh` 被 Windows 弄成 CRLF，服务器上会报 `bash\r: No such file or directory`**，救急命令：`sed -i 's/\r$//' deploy/*.sh`
- 不要把 `data/db.json`、真实口令提交上去（`.gitignore` 已排除 data，但如果你手动改过 `js/config.js` 的口令，提交前想清楚——api 模式下前端口令只是门帘，真正的在服务器 `/etc/knowme.env`）

---

## 11. 用自己服务器上的数据库（api 模式）

浏览器**连不了 MySQL**（没法直连数据库、也没 CORS），所以 `server.js` 兼了一个 REST API 的角色：

```
浏览器 ──fetch /api/*──> node server.js ──> 存储驱动 ──> data/db.json  或  MySQL
```

### 11.1 两种驱动，二选一

| 驱动 | 依赖 | 数据在哪 | 适合 |
|---|---|---|---|
| **json**（默认） | **零依赖** | `data/db.json` 一个文件 | 先跑通、小站（几千套题 / 几万条成绩无压力） |
| **mysql** | `npm i mysql2` | `knowme.quizzes` / `knowme.scores` | 你服务器上已有 MySQL / MariaDB |

### 11.2 切换只要改两处

```js
// ① 前端 js/config.js
STORAGE_MODE: 'api',

// ② 服务端 backend/config.js
DB: { DRIVER: 'json' }     // 或 'mysql'
```

改完 `sudo systemctl restart knowme`。

### 11.3 用 json 文件（什么都不用装）

启动就会自动创建 `data/db.json`，首次写入时建目录。

- **写入是原子的**：先写 `db.json.tmp` 再 `rename`，断电不会写坏文件；写入串行化，并发不会互相覆盖。
- 文件解析失败时会**自动备份**成 `db.json.broken-<时间戳>`，再重建一个空库，不会静默丢数据。
- 备份就一条：`cp data/db.json ~/backup-$(date +%F).json`

### 11.4 用 MySQL / MariaDB

```bash
# 1. 建库 + 建表
sudo mysql -e "create database if not exists knowme character set utf8mb4 collate utf8mb4_unicode_ci;"
sudo mysql knowme < backend/schema.mysql.sql

# 2. 建个只读写这两张表的账号
sudo mysql -e "create user 'knowme'@'localhost' identified by '换成强密码';"
sudo mysql -e "grant select, insert, update, delete on knowme.* to 'knowme'@'localhost'; flush privileges;"

# 3. 装驱动（服务端依赖，前端不需要）
cd /var/www/knowme && sudo npm i mysql2

# 4. 让服务用 mysql
sudo systemctl edit knowme      # 加 Environment=KM_DB=mysql 和 MYSQL_* 变量
```

`systemctl edit knowme` 里加（**密码用环境变量，别写进 git**）：

```ini
[Service]
Environment=KM_DB=mysql
Environment=MYSQL_HOST=127.0.0.1
Environment=MYSQL_USER=knowme
Environment=MYSQL_PASSWORD=你的密码
Environment=MYSQL_DATABASE=knowme
Environment=KM_SUPER_KEY=换成随机串
```

验证：

```bash
curl -s http://127.0.0.1:8080/api/health
# {"ok":true,"driver":"mysql","quizzes":3,...}
```

### 11.5 接口一览

| 方法 | 路径 | 鉴权 | 作用 |
|---|---|---|---|
| GET | `/api/health` | — | 健康检查 + 当前驱动 |
| POST | `/api/quizzes` | — | 建题（服务端生成 code / adminKey） |
| GET | `/api/quizzes/:code` | — | 取题（**不含 admin_key**） |
| POST | `/api/quizzes/:code/scores` | — | 交卷（**服务端按 choices 判分**） |
| GET | `/api/quizzes/:code/ranking?limit=` | — | 排行榜（不含 answers） |
| GET | `/api/quizzes/:code/scores` | `X-Admin-Key` | 全部成绩（含 answers，给管理页） |
| DELETE | `/api/quizzes/:code/scores/:id` | `X-Admin-Key` | 删单条成绩 |
| POST | `/api/admin/login` | `X-Super-Key` | 校验超级口令 |
| GET | `/api/admin/quizzes` | `X-Super-Key` | 全部题目 + 作答人数 |
| DELETE | `/api/admin/quizzes/:code` | `X-Super-Key` | 删整套题 |

### 11.6 安全模型（比直连 Supabase 更硬）

| 东西 | 在哪 | 谁能看到 |
|---|---|---|
| 题目答案 | `/api/quizzes/:code` 会返回 | 任何人（这是默契测试，作弊没意义；要彻底防可以改成逐题向服务端问对错） |
| 每套题的管理密钥 | 创建时返回一次，前端存本地 | 只有拿到管理链接的人 |
| `admin_key` | 不在任何公开接口里 | 只有服务端 + 带密钥的请求 |
| 超级口令 | `backend/config.js` / 环境变量 | **只存在于服务器**，前端文件里没有 |

两个关键点：
- **分数由服务端算**：前端只提交 `choices`，客户端传的 `score` 会被忽略（已有测试覆盖）。
- **删除由服务端验口令**：即使有人改了前端的 `SUPER_KEY`，也删不掉数据。

### 11.7 备份与维护

```bash
# json
tar czf ~/knowme-$(date +%F).tgz /var/www/knowme/data

# mysql
mysqldump -u knowme -p knowme > ~/knowme-$(date +%F).sql

# 清理 90 天前的成绩（mysql）
mysql -u knowme -p knowme -e "delete from scores where created_at < now() - interval 90 day;"
```

### 11.8 自测

```bash
node tests/api.test.js        # 19 个用例：接口、鉴权、服务端判分、删除、落盘
node tests/dom-api.test.js    # 8 个用例：前端 ↔ 真后端全流程（需要 jsdom）
```
