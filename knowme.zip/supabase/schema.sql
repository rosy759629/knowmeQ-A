-- ============================================================
--  你是不是最懂我 · Supabase 建表 + RLS 脚本
--  用法：Supabase 控制台 → SQL Editor → 新建查询 → 整段粘贴执行
--  执行完把 Project URL / anon public key 填到 js/config.js
-- ============================================================

create extension if not exists "pgcrypto";

-- ─────────────────────────────────────────────
-- 表：quizzes（一套题 = 一条记录）
-- ─────────────────────────────────────────────
create table if not exists public.quizzes (
  id           uuid primary key default gen_random_uuid(),
  code         varchar(8)  not null unique,
  title        text        not null,
  creator_name text,
  admin_key    varchar(32) not null,
  questions    jsonb       not null,
  created_at   timestamptz not null default now(),

  -- code 只能是 4-6 位「大写字母（去掉 I/O）+ 数字（去掉 0/1）」
  constraint quizzes_code_format check (code ~ '^[A-HJ-NP-Z2-9]{4,6}$'),
  -- 1-10 道题，每题必须 4 个选项、答案在 0-3
  constraint quizzes_questions_shape check (
    jsonb_typeof(questions) = 'array'
    and jsonb_array_length(questions) between 1 and 10
  )
);

-- ─────────────────────────────────────────────
-- 表：scores（一次作答 = 一条记录）
-- ─────────────────────────────────────────────
create table if not exists public.scores (
  id         uuid primary key default gen_random_uuid(),
  quiz_code  varchar(8) not null
             references public.quizzes(code) on delete cascade on update cascade,
  nickname   text   not null,
  score      int    not null,
  total      int    not null,
  duration   int,
  answers    jsonb,
  created_at timestamptz not null default now(),

  constraint scores_nickname_len check (char_length(nickname) between 1 and 24),
  constraint scores_score_range  check (score >= 0 and score <= total),
  constraint scores_total_range  check (total between 1 and 10),
  constraint scores_duration_range check (duration is null or (duration >= 0 and duration <= 86400))
);

-- ─────────────────────────────────────────────
-- 索引
-- ─────────────────────────────────────────────
create index if not exists idx_scores_code on public.scores(quiz_code);
create index if not exists idx_scores_rank on public.scores(quiz_code, score desc, duration asc);
create index if not exists idx_quizzes_created on public.quizzes(created_at desc);

-- ─────────────────────────────────────────────
-- 行级安全（RLS）：只允许「读」和「插入」，不允许改 / 删
-- ─────────────────────────────────────────────
alter table public.quizzes enable row level security;
alter table public.scores  enable row level security;

drop policy if exists "read quizzes"   on public.quizzes;
drop policy if exists "insert quizzes" on public.quizzes;
create policy "read quizzes"   on public.quizzes for select to anon, authenticated using (true);
create policy "insert quizzes" on public.quizzes for insert to anon, authenticated with check (true);

drop policy if exists "read scores"   on public.scores;
drop policy if exists "insert scores" on public.scores;
create policy "read scores"   on public.scores for select to anon, authenticated using (true);
create policy "insert scores" on public.scores for insert to anon, authenticated with check (true);

-- 显式授权（新项目默认已授权，写上更保险）
grant select, insert on public.quizzes to anon, authenticated;
grant select, insert on public.scores  to anon, authenticated;

-- ─────────────────────────────────────────────
-- 校验：查一下建好了没
-- ─────────────────────────────────────────────
-- select tablename, rowsecurity from pg_tables
--   where schemaname = 'public' and tablename in ('quizzes', 'scores');

-- ============================================================
--  超级管理员（?super）：删除整套题目
--  ------------------------------------------------------------
--  为什么走函数而不是给 anon delete 权限：
--    前端带着 anon key，如果开放 delete 策略，任何人都能删库。
--    这里用 security definer 函数，口令以 sha256 存在一张
--    「谁都读不到」的表里，删除动作由数据库校验。
--
--  ⚠️ 口令必须改：把下面的 'CHANGE-ME-SUPER' 换成你自己的，
--     并同步改 js/config.js 的 SUPER_KEY（两边要一模一样）。
-- ============================================================

create table if not exists public.super_config (
  id             int primary key default 1,
  super_key_hash text        not null,
  updated_at     timestamptz not null default now(),
  constraint super_config_single_row check (id = 1)
);

-- 这张表不给任何客户端读权限：RLS 打开且不建 policy，
-- 再把 anon / authenticated 的权限收回，只有 definer 函数能查。
alter table public.super_config enable row level security;
revoke all on public.super_config from anon, authenticated;

-- 第一次执行时写入口令哈希；重复执行会覆盖成新口令
insert into public.super_config (id, super_key_hash)
values (1, encode(digest('CHANGE-ME-SUPER', 'sha256'), 'hex'))
on conflict (id) do update
  set super_key_hash = excluded.super_key_hash,
      updated_at     = now();

-- 删除一套题（连带成绩）。口令不对直接抛异常。
create or replace function public.super_delete_quiz(p_key text, p_code text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_ok boolean;
begin
  select (super_key_hash = encode(digest(p_key, 'sha256'), 'hex'))
    into v_ok
    from public.super_config
   where id = 1;

  if coalesce(v_ok, false) is not true then
    raise exception 'SUPER_KEY_INVALID';
  end if;

  delete from public.scores  where quiz_code = p_code;
  delete from public.quizzes where code = p_code;
  return true;
end;
$$;

revoke all on function public.super_delete_quiz(text, text) from public;
grant execute on function public.super_delete_quiz(text, text) to anon, authenticated;

-- ─────────────────────────────────────────────
-- 以后想换口令，单独执行这几行（不用重跑整个文件）：
-- ─────────────────────────────────────────────
-- update public.super_config
--    set super_key_hash = encode(digest('你的新口令', 'sha256'), 'hex'),
--        updated_at = now()
--  where id = 1;

-- 自测：口令对不对（应该返回 true；把 CHANGE-ME-SUPER 换成你的口令）
-- select (super_key_hash = encode(digest('CHANGE-ME-SUPER', 'sha256'), 'hex')) as ok
--   from public.super_config where id = 1;

-- ============================================================
-- ⚠️ v1 已知风险（文档 4.4 / 第 12 节）：
--    admin_key 存在 quizzes 表且任何人对可读，懂技术的人能通过
--    anon key 直接查出来。目标用户非恶意时风险可接受。
--
-- v2 收紧方向（任选一种，都不需要改前端结构太多）：
--   1) 把 admin_key 拆到 public.quiz_secrets 表，不给 anon select 权限，
--      校验改走一个 security definer 的 RPC：
--        create function public.check_admin(p_code text, p_key text)
--        returns boolean language sql security definer as $$
--          select exists(select 1 from public.quiz_secrets
--                        where code = p_code and admin_key = p_key);
--        $$;
--      前端改成 await supabase.rpc('check_admin', {p_code, p_key})
--   2) 用 Edge Function 校验 + 代理管理页读数据。
-- ============================================================
