#!/usr/bin/env node
/* ===========================================================
   server.js — 零依赖静态服务器（只用 Node 内置模块）
   -----------------------------------------------------------
   本地：  node server.js               启动并自动开浏览器
           node server.js --no-open     只启动（服务器 / systemd 用这个）
           set PORT=9000 && node server.js

   生产：  PORT=8080 HOST=127.0.0.1 node server.js --no-open
           交给 nginx 反代 + HTTPS，见 deploy/nginx.conf

   后台入口 <ADMIN_PATH>（默认 /manage）会被内部重写成 index.html；
   同时 <ADMIN_PATH>/xxx 会被剥掉前缀，保证深层路径下资源也能加载。
   =========================================================== */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { exec } = require('child_process');

const serverConfig = require('./backend/config');
const { createStore } = require('./backend/store');
const { handleApi } = require('./backend/api');

const ROOT = path.resolve(__dirname);
const START_PORT = Number(process.env.PORT) || 8000;
const HOST = process.env.HOST || '0.0.0.0';
const NO_OPEN = process.argv.includes('--no-open');

let store = null;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.sql': 'text/plain; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff'
};

/* ─────────── 后台路径：始终读 js/config.admin.js ───────────
   故意不提供环境变量覆盖：前端和服务器必须用同一个值，
   否则会在 /manage 打开首页、或在自定义路径 404。 */

function readAdminPath() {
  try {
    const src = fs.readFileSync(path.join(ROOT, 'js/config.admin.js'), 'utf8');
    const m = src.match(/ADMIN_PATH\s*:\s*['"]([^'"]*)['"]/);
    if (m && m[1]) return normalizePath(m[1]);
  } catch (e) { /* 文件不存在就用默认值 */ }
  return '/manage';
}

function normalizePath(value) {
  let p = String(value || '').trim();
  if (!p) return '';
  if (p.charAt(0) !== '/') p = '/' + p;
  return p.replace(/\/+$/, '');
}

const ADMIN_PATH = readAdminPath();

/* ─────────── 响应 ─────────── */

const BASE_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'SAMEORIGIN'
};

function send(res, status, body, headers) {
  res.writeHead(status, Object.assign({
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store'
  }, BASE_HEADERS, headers || {}));
  if (body === null || body === undefined) res.end();
  else res.end(body);
}

function log(req, res, startedAt) {
  const ms = Date.now() - startedAt;
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log(stamp + '  ' + req.method + ' ' + req.url + '  ' + res.statusCode + '  ' + ms + 'ms');
}

function serveFile(file, stat, req, res) {
  const ext = path.extname(file).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  const cache = ext === '.html' || ext === '.htm'
    ? 'no-store'
    : 'public, max-age=300';

  res.writeHead(200, Object.assign({
    'Content-Type': type,
    'Content-Length': stat.size,
    'Cache-Control': cache
  }, BASE_HEADERS));

  if (req.method === 'HEAD') return res.end();

  const stream = fs.createReadStream(file);
  stream.on('error', function () {
    if (!res.headersSent) send(res, 500, '500 Internal Server Error');
    else res.destroy();
  });
  stream.pipe(res);
}

function serveIndex(req, res) {
  const file = path.join(ROOT, 'index.html');
  fs.stat(file, function (err, stat) {
    if (err || !stat.isFile()) return send(res, 500, '500 index.html 不存在');
    serveFile(file, stat, req, res);
  });
}

/* ─────────── 请求处理 ─────────── */

function handle(req, res) {
  const startedAt = Date.now();
  res.on('finish', function () { log(req, res, startedAt); });

  let url;
  try {
    url = new URL(req.url || '/', 'http://localhost');
  } catch (e) {
    return send(res, 400, '400 Bad Request');
  }

  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch (e) {
    return send(res, 400, '400 Bad Request');
  }

  /* ── /api/*：交给后端接口 ── */
  if (pathname.indexOf('/api/') === 0) {
    if (!store) {
      res.writeHead(503, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: 'NOT_READY', message: '数据库还没准备好' }));
    }
    return handleApi(req, res, pathname, url.searchParams, store, serverConfig);
  }

  // 后台目录：/manage 或 /manage/ → index.html
  if (ADMIN_PATH && (pathname === ADMIN_PATH || pathname === ADMIN_PATH + '/')) {
    return serveIndex(req, res);
  }
  // /manage/xxx → 剥掉前缀，按 /xxx 找资源
  if (ADMIN_PATH && pathname.indexOf(ADMIN_PATH + '/') === 0) {
    pathname = pathname.slice(ADMIN_PATH.length);
    if (pathname === '' || pathname === '/') return serveIndex(req, res);
  }

  if (pathname === '/' || pathname === '') pathname = '/index.html';

  // 防目录穿越：解析后必须仍在 ROOT 内
  const target = path.resolve(ROOT, '.' + pathname);
  if (target !== ROOT && target.indexOf(ROOT + path.sep) !== 0) {
    return send(res, 403, '403 Forbidden');
  }

  fs.stat(target, function (err, stat) {
    if (err) return send(res, 404, '404 Not Found: ' + pathname);

    if (stat.isDirectory()) {
      const indexFile = path.join(target, 'index.html');
      return fs.stat(indexFile, function (err2, stat2) {
        if (err2 || !stat2.isFile()) return send(res, 403, '403 Forbidden: 目录不可浏览');
        serveFile(indexFile, stat2, req, res);
      });
    }
    serveFile(target, stat, req, res);
  });
}

function lanAddresses() {
  const out = [];
  const nets = os.networkInterfaces();
  Object.keys(nets).forEach(function (name) {
    (nets[name] || []).forEach(function (net) {
      if (net.family === 'IPv4' && !net.internal) out.push(net.address);
    });
  });
  return out;
}

function openBrowser(url) {
  let cmd;
  if (process.platform === 'win32') cmd = 'start "" "' + url + '"';
  else if (process.platform === 'darwin') cmd = 'open "' + url + '"';
  else cmd = 'xdg-open "' + url + '"';
  exec(cmd, function () { /* 打不开就算了，地址已经打印出来 */ });
}

function listen(port, attemptsLeft) {
  const server = http.createServer(handle);

  server.on('error', function (err) {
    if (err.code === 'EADDRINUSE' && attemptsLeft > 0) {
      server.close();
      listen(port + 1, attemptsLeft - 1);
      return;
    }
    console.error('\n启动失败：' + err.message);
    process.exit(1);
  });

  server.listen(port, HOST, function () {
    const url = 'http://localhost:' + port + '/';
    const driver = (store && store.driver) || 'json';
    console.log('');
    console.log('  你是不是最懂我 · 服务已启动');
    console.log('  ────────────────────────────────────────');
    console.log('  站点：      ' + url);
    console.log('  管理后台：  http://localhost:' + port + ADMIN_PATH);
    console.log('  API：       http://localhost:' + port + '/api/health');
    console.log('  数据库：    ' + driver + (driver === 'json'
      ? '（' + (serverConfig.DB.FILE || '') + '）'
      : '（' + serverConfig.DB.MYSQL.host + '/' + serverConfig.DB.MYSQL.database + '）'));
    if (HOST === '0.0.0.0') {
      lanAddresses().forEach(function (ip) {
        console.log('  局域网：    http://' + ip + ':' + port + '/   （同一 Wi-Fi 可访问）');
      });
    }
    console.log('  项目目录：  ' + ROOT);
    console.log('  停止服务：  按 Ctrl+C 或直接关掉这个窗口');
    console.log('');
    if (!NO_OPEN) openBrowser(url);
  });
}

/* ─────────── 启动：先连数据库，再开端口 ─────────── */

async function main() {
  try {
    store = await createStore(serverConfig);
  } catch (err) {
    console.error('\n[数据库] 初始化失败：' + err.message);
    console.error('提示：json 驱动不需要任何依赖；mysql 驱动需要先 npm i mysql2 并执行 backend/schema.mysql.sql\n');
    process.exit(1);
  }

  listen(START_PORT, 20);

  function shutdown(signal) {
    console.log('\n收到 ' + signal + '，正在关闭…');
    if (store && store.close) {
      Promise.resolve(store.close()).catch(function () {}).then(function () {
        process.exit(0);
      });
      setTimeout(function () { process.exit(0); }, 2000).unref();
    } else {
      process.exit(0);
    }
  }

  process.on('SIGINT', function () { shutdown('SIGINT'); });
  process.on('SIGTERM', function () { shutdown('SIGTERM'); });
}

main();
