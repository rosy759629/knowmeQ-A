# ============================================================
#  upload.ps1 — Windows 上把项目传到服务器（PowerShell，无需 WSL）
# ------------------------------------------------------------
#  用法（在项目根目录执行）：
#    powershell -ExecutionPolicy Bypass -File deploy\upload.ps1 -Server root@1.2.3.4
#    powershell -ExecutionPolicy Bypass -File deploy\upload.ps1 -Server ubuntu@quiz.example.com -RemoteDir /var/www/knowme
#
#  依赖：Windows 10/11 自带的 ssh / scp / tar（OpenSSH 客户端）
#  上传内容不含：node_modules、.git、data、.tmp、tests、.testdata
# ============================================================

param(
  [Parameter(Mandatory = $true)][string]$Server,
  [string]$RemoteDir = "/var/www/knowme",
  [switch]$KeepLocalTarball
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$tarball = Join-Path $env:TEMP ("knowme-" + (Get-Date -Format "yyyyMMddHHmmss") + ".tgz")

if (-not (Get-Command tar -ErrorAction SilentlyContinue)) { throw "找不到 tar，请装 Git for Windows 或升级到 Win10 1803+" }
if (-not (Get-Command scp -ErrorAction SilentlyContinue)) { throw "找不到 scp，请在 Windows 可选功能里装 OpenSSH 客户端" }

Write-Host "→ 打包 $root" -ForegroundColor Cyan
Push-Location $root
try {
  tar -czf $tarball `
    --exclude=node_modules `
    --exclude=.git `
    --exclude=data `
    --exclude=.tmp `
    --exclude=.testdata `
    --exclude=tests `
    --exclude=*.srv.log `
    .
} finally {
  Pop-Location
}

$size = [math]::Round((Get-Item $tarball).Length / 1KB, 1)
Write-Host "  包大小：$size KB" -ForegroundColor DarkGray

Write-Host "→ 上传到 $Server" -ForegroundColor Cyan
scp $tarball "${Server}:/tmp/knowme.tgz"

Write-Host "→ 服务器上解压到 $RemoteDir" -ForegroundColor Cyan
ssh $Server "sudo mkdir -p $RemoteDir && sudo tar -xzf /tmp/knowme.tgz -C $RemoteDir && rm -f /tmp/knowme.tgz && sudo chmod -R a+rX $RemoteDir"

if (-not $KeepLocalTarball) { Remove-Item $tarball -Force -ErrorAction SilentlyContinue }

Write-Host ""
Write-Host "✅ 上传完成" -ForegroundColor Green
Write-Host "   下一步（在服务器上执行）：" -ForegroundColor Yellow
Write-Host "     cd $RemoteDir && sudo bash deploy/install-ubuntu.sh"
Write-Host ""
