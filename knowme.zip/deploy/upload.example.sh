#!/usr/bin/env bash
# ============================================================
#  一键同步到服务器（可选，本地有 rsync / git-bash / WSL 时用）
#
#  用法：
#    ./deploy/upload.example.sh root@1.2.3.4
#    REMOTE_DIR=/srv/knowme ./deploy/upload.example.sh ubuntu@quiz.example.com
#
#  第一次用记得：chmod +x deploy/upload.example.sh
# ============================================================
set -euo pipefail

TARGET="${1:?用法: $0 user@host}"
REMOTE_DIR="${REMOTE_DIR:-/var/www/knowme}"
SERVICE="${SERVICE:-knowme}"

echo "→ 同步到 $TARGET:$REMOTE_DIR"
rsync -avz --delete \
  --exclude '.git' \
  --exclude 'node_modules' \
  --exclude '.tmp' \
  --exclude 'tests' \
  --exclude 'deploy' \
  --exclude '启动.bat' \
  ./ "$TARGET:$REMOTE_DIR/"

echo "→ 修正属主"
ssh "$TARGET" "sudo chown -R www-data:www-data '$REMOTE_DIR'"

echo "→ 重启服务"
ssh "$TARGET" "sudo systemctl restart $SERVICE && sleep 1 && sudo systemctl is-active $SERVICE"

echo "✓ 完成。后台入口： https://你的域名$(grep -o "ADMIN_PATH: *'[^']*'" js/config.admin.js | head -n1 | sed "s/.*'\(.*\)'/\1/")"
