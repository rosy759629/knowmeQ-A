#!/usr/bin/env bash
# ============================================================
#  一键部署到 Ubuntu（systemd + nginx 反代）
#  ------------------------------------------------------------
#  用法：
#    sudo bash deploy/install-ubuntu.sh
#    sudo DOMAIN=quiz.example.com APP_DIR=/var/www/knowme bash deploy/install-ubuntu.sh
#
#  做的事：
#    1. 装 Node.js 20（已有就跳过）
#    2. 装 nginx（已有就跳过）
#    3. 生成随机超级口令，写 /etc/knowme.env（600 权限）
#    4. 注册 systemd 服务 knowme
#    5. 配 nginx 反向代理 → 127.0.0.1:8080
#    6. 自检 /api/health，打印访问地址和口令
#  可以重复执行（幂等）。
# ============================================================
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/knowme}"
DOMAIN="${DOMAIN:-_}"
DB="${DB:-json}"
PORT="${PORT:-8080}"
SUPER_KEY="${SUPER_KEY:-}"

log() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m    %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "请用 root 运行：sudo bash deploy/install-ubuntu.sh"
[[ -f "$APP_DIR/server.js" ]] || die "找不到 $APP_DIR/server.js —— 先把代码传到 $APP_DIR 再跑这个脚本"

# shellcheck disable=SC1091
. /etc/os-release 2>/dev/null || true
log "系统：${PRETTY_NAME:-unknown}"
log "应用目录：$APP_DIR   端口：$PORT   数据库：$DB   server_name：$DOMAIN"

# ── 1. 基础工具 ─────────────────────────────────────────────
if command -v apt-get >/dev/null 2>&1; then
  log "检查系统依赖"
  apt-get update -qq || warn "apt update 失败，继续尝试"
  apt-get install -y -qq curl ca-certificates gnupg >/dev/null
else
  die "这个脚本只支持 Debian/Ubuntu（需要 apt-get）"
fi

# ── 2. Node.js ──────────────────────────────────────────────
if command -v node >/dev/null 2>&1 && [[ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ]]; then
  log "Node 已就绪：$(node -v)"
else
  log "安装 Node.js 20 LTS（需要外网，慢的话可以手动装后重跑本脚本）"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
NODE_BIN="$(command -v node)" || die "node 安装失败"

# ── 3. nginx ────────────────────────────────────────────────
if command -v nginx >/dev/null 2>&1; then
  log "nginx 已安装：$(nginx -v 2>&1)"
else
  log "安装 nginx"
  apt-get install -y nginx
fi

# ── 4. 目录权限 ─────────────────────────────────────────────
log "修正目录权限"
chmod -R a+rX "$APP_DIR"
if [[ "$DB" == "json" ]]; then
  mkdir -p "$APP_DIR/data"
  chown -R www-data:www-data "$APP_DIR/data"
  chmod 750 "$APP_DIR/data"
fi

# ── 5. 环境变量文件（含超级口令） ────────────────────────────
ENV_FILE=/etc/knowme.env
if [[ -z "$SUPER_KEY" ]]; then
  if [[ -f "$ENV_FILE" ]] && grep -q '^KM_SUPER_KEY=' "$ENV_FILE" 2>/dev/null; then
    SUPER_KEY="$(grep '^KM_SUPER_KEY=' "$ENV_FILE" | head -n1 | cut -d= -f2-)"
    log "沿用已有的超级口令（$ENV_FILE）"
  else
    # 先取固定长度再过滤，避免 head 提前关闭管道导致 pipefail 报警
    SUPER_KEY="$(head -c 64 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | cut -c1-24)"
    [[ ${#SUPER_KEY} -ge 16 ]] || SUPER_KEY="km$(date +%s)$RANDOM"
    log "已生成随机超级口令"
  fi
fi

log "写 $ENV_FILE"
cat > "$ENV_FILE" <<EOF
PORT=$PORT
HOST=127.0.0.1
KM_DB=$DB
KM_SUPER_KEY=$SUPER_KEY
EOF
chmod 600 "$ENV_FILE"
chown root:root "$ENV_FILE"

# ── 6. systemd ──────────────────────────────────────────────
log "注册 systemd 服务"
cat > /etc/systemd/system/knowme.service <<EOF
[Unit]
Description=Know Me Quiz (static + REST API)
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=$APP_DIR
ExecStart=$NODE_BIN $APP_DIR/server.js --no-open
EnvironmentFile=-$ENV_FILE
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable knowme >/dev/null 2>&1 || true
systemctl restart knowme

# ── 7. 等服务起来 ───────────────────────────────────────────
log "等待服务应答 /api/health"
ok=0
for _ in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then ok=1; break; fi
  sleep 1
done
if [[ "$ok" -ne 1 ]]; then
  echo "----- journalctl -u knowme -----"
  journalctl -u knowme -n 40 --no-pager || true
  die "服务没起来，看上面的日志"
fi
log "服务正常：$(curl -fsS "http://127.0.0.1:$PORT/api/health")"

# ── 8. nginx ────────────────────────────────────────────────
log "配置 nginx 反向代理"
NGINX_SITE=/etc/nginx/sites-available/knowme
cat > "$NGINX_SITE" <<EOF
# 由 deploy/install-ubuntu.sh 生成
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;

    client_max_body_size 2m;

    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host              \$host;
        proxy_set_header X-Real-IP         \$remote_addr;
        proxy_set_header X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

ln -sf "$NGINX_SITE" /etc/nginx/sites-enabled/knowme

if [[ -f /etc/nginx/sites-enabled/default ]]; then
  if grep -q '/var/www/html' /etc/nginx/sites-enabled/default 2>/dev/null; then
    rm -f /etc/nginx/sites-enabled/default
    warn "已停用 nginx 自带的默认站点（否则访问 IP 会看到欢迎页）"
  else
    warn "检测到自定义的 default 站点，我没动它。若访问 IP 看到别的内容，请自行调整 default_server"
  fi
fi

nginx -t
systemctl reload nginx

# ── 9. 汇总 ─────────────────────────────────────────────────
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
[[ -z "$IP" ]] && IP="你的服务器IP"

echo
echo "──────────────────────────────────────────────────────"
echo " ✅ 部署完成"
echo "──────────────────────────────────────────────────────"
echo " 站点：      http://$IP/"
echo " 管理后台：  http://$IP/manage"
echo " 健康检查：  http://$IP/api/health"
echo " 超级口令：  $SUPER_KEY"
echo "            （存在 /etc/knowme.env，请自己保存一份）"
echo
echo " 服务管理："
echo "   systemctl status knowme"
echo "   systemctl restart knowme"
echo "   journalctl -u knowme -f"
echo
echo " ⚠️ 还有两件事要手动做："
echo "  1. 把 js/config.js 的 STORAGE_MODE 改成 'api'"
echo "     （不改的话，网站还是「数据只存自己浏览器」的演示模式）"
echo "  2. 建议把 js/config.admin.js 的 ADMIN_PATH 改成别人猜不到的路径，"
echo "     改完 sudo systemctl restart knowme"
echo "──────────────────────────────────────────────────────"
echo
