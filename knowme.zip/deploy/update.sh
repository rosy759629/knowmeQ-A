#!/usr/bin/env bash
# ============================================================
#  update.sh — 服务器上拉取新代码并重启（Git 部署用）
#  ------------------------------------------------------------
#  用法：
#    cd /var/www/knowme && sudo bash deploy/update.sh
#    sudo APP_DIR=/var/www/knowme bash deploy/update.sh
#
#  做的事：
#    1. git pull --ff-only（有本地改动会拒绝，不会覆盖你的东西）
#    2. 修正权限（新拉下来的文件通常是 root 的）
#    3. 重启 systemd 服务
#    4. 自检 /api/health
# ============================================================
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/knowme}"
PORT="${PORT:-8080}"

log() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "请用 root 运行：sudo bash deploy/update.sh"
[[ -d "$APP_DIR/.git" ]] || die "$APP_DIR 不是 git 仓库，用 deploy/install-ubuntu.sh 或手动 clone 先"

cd "$APP_DIR"

log "更新前：$(git rev-parse --short HEAD) $(git log -1 --pretty=%s)"

# 有未提交改动就别硬拉，避免把服务器上临时改的东西冲掉
if ! git diff --quiet || ! git diff --cached --quiet; then
  die "工作区有未提交的改动，先处理：git status"
fi

log "拉取 origin"
git pull --ff-only

log "更新后：$(git rev-parse --short HEAD) $(git log -1 --pretty=%s)"

# 权限：新文件默认 644/755，但属主可能是 root，确保 web 进程能读
chmod -R a+rX "$APP_DIR"
if [[ -d "$APP_DIR/data" ]]; then
  chown -R www-data:www-data "$APP_DIR/data"
fi

log "重启服务"
systemctl restart knowme

log "等待 /api/health"
ok=0
for _ in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then ok=1; break; fi
  sleep 1
done
if [[ "$ok" -ne 1 ]]; then
  journalctl -u knowme -n 30 --no-pager || true
  die "重启后服务没起来，看上面的日志"
fi

log "正常：$(curl -fsS "http://127.0.0.1:$PORT/api/health")"
echo
echo "✅ 更新完成。如果改了 ADMIN_PATH，浏览器强刷一下（Ctrl+F5）"
echo
